function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * コンバータ機能を提供するクラス。
       */

      var Converter =
      /** @class */
      function () {
        function Converter() {}
        /**
         * エンティティをホバー可能に変換する。
         */


        Converter.asHoverable = function (e, opts) {
          var hoverableE = e;
          hoverableE.hoverable = true;
          hoverableE.touchable = true;
          hoverableE.hovered = hoverableE.hovered || new g.Trigger();
          hoverableE.unhovered = hoverableE.unhovered || new g.Trigger();

          if (opts) {
            if (opts.cursor) hoverableE.cursor = opts.cursor;
          }

          return hoverableE;
        };
        /**
         * エンティティのホバーを解除する。
         */


        Converter.asUnhoverable = function (e) {
          var hoverableE = e;
          delete hoverableE.hoverable;

          if (hoverableE.hovered && !hoverableE.hovered.destroyed()) {
            hoverableE.hovered.destroy();
            delete hoverableE.hovered;
          }

          if (hoverableE.unhovered && !hoverableE.unhovered.destroyed()) {
            hoverableE.unhovered.fire();
            hoverableE.unhovered.destroy();
            delete hoverableE.unhovered;
          }

          return hoverableE;
        };

        return Converter;
      }();

      exports.Converter = Converter;
    }, {}],
    2: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * ホバー機能を提供するプラグイン。
       */

      var HoverPlugin =
      /** @class */
      function () {
        function HoverPlugin(game, view, option) {
          if (option === void 0) {
            option = {};
          }

          this.game = game;
          this.view = view.view;
          this.beforeHover = null;
          this.operationTrigger = new g.Trigger();
          this._cursor = option.cursor || "pointer";
          this._showTooltip = !!option.showTooltip;
          this._getScale = view.getScale ? function () {
            return view.getScale();
          } : null;
          this._onMouseMove_bound = this._onMouseMove.bind(this);
          this._onMouseOut_bound = this._onMouseOut.bind(this);
        }

        HoverPlugin.isSupported = function () {
          return typeof document !== "undefined" && typeof document.addEventListener === "function";
        };

        HoverPlugin.prototype.start = function () {
          this.view.addEventListener("mousemove", this._onMouseMove_bound, false);
          this.view.addEventListener("mouseout", this._onMouseOut_bound, false);
          return true;
        };

        HoverPlugin.prototype.stop = function () {
          this.view.removeEventListener("mousemove", this._onMouseMove_bound, false);
          this.view.removeEventListener("mouseout", this._onMouseOut_bound, false);
        };

        HoverPlugin.prototype._onMouseMove = function (e) {
          var scene = this.game.scene();
          if (!scene) return;
          var rect = this.view.getBoundingClientRect();
          var positionX = rect.left + window.pageXOffset;
          var positionY = rect.top + window.pageYOffset;
          var offsetX = e.pageX - positionX;
          var offsetY = e.pageY - positionY;
          var scale = {
            x: 1,
            y: 1
          };

          if (this._getScale) {
            scale = this._getScale();
          }

          var point = {
            x: offsetX / scale.x,
            y: offsetY / scale.y
          };
          var target = scene.findPointSourceByPoint(point).target;

          if (target && target.hoverable) {
            if (target !== this.beforeHover) {
              if (this.beforeHover && this.beforeHover.hoverable) {
                this._onUnhovered(target);
              }

              this._onHovered(target);
            }

            this.beforeHover = target;
          } else if (this.beforeHover) {
            this._onUnhovered(this.beforeHover);
          }
        };

        HoverPlugin.prototype._onHovered = function (target) {
          if (target.hoverable) {
            this.view.style.cursor = target.cursor ? target.cursor : this._cursor;

            if (this._showTooltip && target.title) {
              this.view.setAttribute("title", target.title);
            }

            target.hovered.fire();
          }
        };

        HoverPlugin.prototype._onUnhovered = function (target) {
          this.view.style.cursor = "auto";

          if (this.beforeHover && this.beforeHover.unhovered) {
            this.beforeHover.unhovered.fire();

            if (this._showTooltip) {
              this.view.removeAttribute("title");
            }
          }

          this.beforeHover = null;
        };

        HoverPlugin.prototype._onMouseOut = function () {
          if (this.beforeHover) this._onUnhovered(this.beforeHover);
        };

        return HoverPlugin;
      }();

      exports.HoverPlugin = HoverPlugin;
      module.exports = HoverPlugin;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Converter_1 = require("./Converter");

      exports.Converter = Converter_1.Converter;
    }, {
      "./Converter": 1
    }],
    4: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.parse = void 0;
      /**
       * 文字列からルビをパースする。
       * このパーサは、akashic-labelのデフォルトルビ記法のためのパーサである。
       *
       * このパーサを使う場合、ラベルに与える文字列にJSONのオブジェクトを表す文字列を含むことができる。
       * 文字列中のオブジェクトはルビを表す要素として扱われる。
       * オブジェクトのメンバーには、ルビを表す `rt` と、本文を表す `rb` を含む必要がある。
       * これらのメンバー以外に、RubyOptions型が持つメンバーを含むことができる。
       *
       * 入力の例として、
       * 'これは{"rb":"本文","rt":"ルビ", "rubyFontSize": 2}です。'
       * という文字列が与えられた場合、このパーサは
       * ["これは", {rb:"本文", rt: "ルビ", rubyFontSize: 2}, "です。"]
       * という配列を返す。
       * また、 `{` や `}` は `\\` でエスケープする必要がある。
       * 例として、括弧は `\\{` 、 バックスラッシュは `\\` を用いて表現する。
       * 注意すべき点として、オブジェクトのプロパティ名はダブルクォートでくくられている必要がある。
       */

      function parse(text) {
        var pattern = /^((?:[^\\{]|\\+.)*?)({(?:[^\\}]|\\+.)*?})([\s\S]*)/; // ((?:[^\\{]|\\+.)*?) -> オブジェクトリテラルの直前まで
        // ({(?:[^\\}]|\\+.)*?}) -> 最前のオブジェクトリテラル
        // ([\s\S]*) -> オブジェクトリテラル以降の、改行を含む文字列

        var result = [];

        while (text.length > 0) {
          var parsedText = text.match(pattern);

          if (parsedText !== null) {
            var headStr = parsedText[1];
            var rubyStr = parsedText[2];
            text = parsedText[3];

            if (headStr.length > 0) {
              result.push(headStr.replace(/\\{/g, "{").replace(/\\}/g, "}"));
            }

            var parseResult = JSON.parse(rubyStr.replace(/\\/g, "\\\\"));

            if (parseResult.hasOwnProperty("rt") && parseResult.hasOwnProperty("rb")) {
              parseResult.rt = parseResult.rt.replace(/\\{/g, "{").replace(/\\}/g, "}");
              parseResult.rb = parseResult.rb.replace(/\\{/g, "{").replace(/\\}/g, "}");
              parseResult.text = rubyStr;
              result.push(parseResult);
            } else {
              throw g.ExceptionFactory.createTypeMismatchError("parse", "RubyFragment");
            }
          } else {
            result.push(text.replace(/\\{/g, "{").replace(/\\}/g, "}"));
            break;
          }
        }

        return result;
      }

      exports.parse = parse;
    }, {}],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.RubyFragmentDrawInfo = exports.StringDrawInfo = void 0;
      /**
       * 行に含まれる文字列要素。
       */

      var StringDrawInfo =
      /** @class */
      function () {
        function StringDrawInfo(text, width, glyphs) {
          this.text = text;
          this.width = width;
          this.glyphs = glyphs;
        }

        return StringDrawInfo;
      }();

      exports.StringDrawInfo = StringDrawInfo;
      /**
       * 行に含まれるルビ要素。
       */

      var RubyFragmentDrawInfo =
      /** @class */
      function () {
        function RubyFragmentDrawInfo(fragment, width, rbWidth, rtWidth, glyphs, rubyGlyphs) {
          this.text = fragment.text;
          this.fragment = fragment;
          this.width = width;
          this.rbWidth = rbWidth;
          this.rtWidth = rtWidth;
          this.glyphs = glyphs;
          this.rubyGlyphs = rubyGlyphs;
        }

        return RubyFragmentDrawInfo;
      }();

      exports.RubyFragmentDrawInfo = RubyFragmentDrawInfo;
    }, {}],
    6: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics = function extendStatics(d, b) {
          _extendStatics = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics(d, b);
        };

        return function (d, b) {
          _extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      var rp = require("./RubyParser");

      var fr = require("./FragmentDrawInfo");

      var dr = require("./DefaultRubyParser");
      /**
       * 複数行のテキストを描画するエンティティ。
       * 文字列内の"\r\n"、"\n"、"\r"を区切りとして改行を行う。
       * また、自動改行が有効な場合はエンティティの幅に合わせて改行を行う。
       * 本クラスの利用にはg.Fontが必要となる。
       */


      var Label =
      /** @class */
      function (_super) {
        __extends(Label, _super);
        /**
         * 各種パラメータを指定して `Label` のインスタンスを生成する。
         * @param param このエンティティに対するパラメータ
         */


        function Label(param) {
          var _this = _super.call(this, param) || this;

          _this.text = param.text;
          _this.font = param.font;
          _this.fontSize = param.fontSize || param.font.size;
          _this._lineBreakWidth = param.width;
          _this.lineBreak = "lineBreak" in param ? param.lineBreak : true;
          _this.lineGap = param.lineGap || 0;
          _this.textAlign = "textAlign" in param ? param.textAlign : "left";
          _this.textColor = param.textColor;
          _this.trimMarginTop = "trimMarginTop" in param ? param.trimMarginTop : false;
          _this.widthAutoAdjust = "widthAutoAdjust" in param ? param.widthAutoAdjust : false;
          _this.rubyEnabled = "rubyEnabled" in param ? param.rubyEnabled : true;
          _this.fixLineGap = "fixLineGap" in param ? param.fixLineGap : false;
          _this.rubyParser = "rubyParser" in param ? param.rubyParser : dr.parse;
          _this.lineBreakRule = "lineBreakRule" in param ? param.lineBreakRule : undefined;

          if (!param.rubyOptions) {
            param.rubyOptions = {};
          }

          _this.rubyOptions = param.rubyOptions;
          _this.rubyOptions.rubyFontSize = "rubyFontSize" in param.rubyOptions ? param.rubyOptions.rubyFontSize : param.fontSize / 2;
          _this.rubyOptions.rubyFont = "rubyFont" in param.rubyOptions ? param.rubyOptions.rubyFont : _this.font;
          _this.rubyOptions.rubyGap = "rubyGap" in param.rubyOptions ? param.rubyOptions.rubyGap : 0;
          _this.rubyOptions.rubyAlign = "rubyAlign" in param.rubyOptions ? param.rubyOptions.rubyAlign : rp.RubyAlign.SpaceAround;
          _this._lines = [];
          _this._beforeText = undefined;
          _this._beforeTextAlign = undefined;
          _this._beforeFontSize = undefined;
          _this._beforeLineBreak = undefined;
          _this._beforeFont = undefined;
          _this._beforeWidth = undefined;
          _this._beforeRubyEnabled = undefined;
          _this._beforeFixLineGap = undefined;
          _this._beforeTrimMarginTop = undefined;
          _this._beforeWidthAutoAdjust = undefined;
          _this._beforeRubyOptions = {};

          _this._invalidateSelf();

          return _this;
        }
        /**
         * このエンティティの描画キャッシュ無効化をエンジンに通知する。
         * このメソッドを呼び出し後、描画キャッシュの再構築が行われ、各 `g.Renderer` に描画内容の変更が反映される。
         */


        Label.prototype.invalidate = function () {
          this._invalidateSelf();

          _super.prototype.invalidate.call(this);
        };

        Label.prototype.renderCache = function (renderer) {
          if (!this.rubyEnabled && this.fontSize === 0) return;
          renderer.save();
          var currentLineHeight = 0;

          for (var i = 0; i < this._lines.length; ++i) {
            if (this._lines[i].width > 0 && this._lines[i].height > 0) {
              renderer.drawImage(this._lines[i].surface, 0, 0, this._lines[i].width, this._lines[i].height, this._offsetX(this._lines[i].width), currentLineHeight);
            }

            currentLineHeight += this._lines[i].height + this.lineGap;
          }

          if (this.textColor) {
            renderer.setCompositeOperation("source-atop");
            renderer.fillRect(0, 0, this._lineBreakWidth, this.height, this.textColor);
          }

          renderer.restore();
        };
        /**
         * 利用している `g.Surface` を破棄した上で、このエンティティを破棄する。
         * 利用している `g.Font` の破棄は行わないため、 `g.Font` の破棄はコンテンツ製作者が明示的に行う必要がある。
         */


        Label.prototype.destroy = function () {
          this._destroyLines();

          _super.prototype.destroy.call(this);
        };
        /**
         * 禁則処理によって行幅が this.width を超える場合があるため、 `g.CacheableE` のメソッドをオーバーライドする
         */


        Label.prototype.calculateCacheSize = function () {
          // TODO: 最大値の候補に this.width を使用するのは textAlign が "center" か "right" の場合に描画に必要なキャッシュサイズを確保するためであり、
          // 最大行幅に対して this.width が大きい場合、余分なキャッシュ領域を確保することになる。
          // これは g.CacheableE にキャッシュ描画位置を調整する cacheOffsetX を導入することで解決される。
          var maxWidth = Math.ceil(this._lines.reduce(function (width, line) {
            return Math.max(width, line.width);
          }, this.width));
          return {
            width: maxWidth,
            height: this.height
          };
        };

        Object.defineProperty(Label.prototype, "lineCount", {
          /**
           * 描画内容の行数を返す
           */
          get: function get() {
            return this._lines.length;
          },
          enumerable: false,
          configurable: true
        });

        Label.prototype._offsetX = function (width) {
          switch (this.textAlign) {
            case "left":
            case g.TextAlign.Left:
              return 0;

            case "right":
            case g.TextAlign.Right:
              return this._lineBreakWidth - width;

            case "center":
            case g.TextAlign.Center:
              return (this._lineBreakWidth - width) / 2;

            default:
              return 0;
          }
        };

        Label.prototype._destroyLines = function () {
          for (var i = 0; i < this._lines.length; i++) {
            if (this._lines[i].surface && !this._lines[i].surface.destroyed()) {
              this._lines[i].surface.destroy();
            }
          }

          this._lines = undefined;
        };

        Label.prototype._invalidateSelf = function () {
          if (this.fontSize < 0) throw g.ExceptionFactory.createAssertionError("Label#_invalidateSelf: fontSize must not be negative.");
          if (this.lineGap < -1 * this.fontSize) throw g.ExceptionFactory.createAssertionError("Label#_invalidateSelf: lineGap must be greater than -1 * fontSize."); // this.width がユーザから変更された場合、this._lineBreakWidth は this.width に追従する。

          if (this._beforeWidth !== this.width) this._lineBreakWidth = this.width;

          if (this._beforeText !== this.text || this._beforeFontSize !== this.fontSize || this._beforeFont !== this.font || this._beforeLineBreak !== this.lineBreak || this._beforeWidth !== this.width && this._beforeLineBreak === true || this._beforeTextAlign !== this.textAlign || this._beforeRubyEnabled !== this.rubyEnabled || this._beforeFixLineGap !== this.fixLineGap || this._beforeTrimMarginTop !== this.trimMarginTop || this._beforeWidthAutoAdjust !== this.widthAutoAdjust || this._isDifferentRubyOptions(this._beforeRubyOptions, this.rubyOptions)) {
            this._updateLines();
          }

          if (this.widthAutoAdjust) {
            // this.widthAutoAdjust が真の場合、 this.width は描画幅に応じてトリミングされる。
            this.width = Math.ceil(this._lines.reduce(function (width, line) {
              return Math.max(width, line.width);
            }, 0));
          }

          var height = this.lineGap * (this._lines.length - 1);

          for (var i = 0; i < this._lines.length; i++) {
            height += this._lines[i].height;
          }

          this.height = height;
          this._beforeText = this.text;
          this._beforeTextAlign = this.textAlign;
          this._beforeFontSize = this.fontSize;
          this._beforeLineBreak = this.lineBreak;
          this._beforeFont = this.font;
          this._beforeWidth = this.width;
          this._beforeRubyEnabled = this.rubyEnabled;
          this._beforeFixLineGap = this.fixLineGap;
          this._beforeTrimMarginTop = this.trimMarginTop;
          this._beforeWidthAutoAdjust = this.widthAutoAdjust;
          this._beforeRubyOptions.rubyFontSize = this.rubyOptions.rubyFontSize;
          this._beforeRubyOptions.rubyFont = this.rubyOptions.rubyFont;
          this._beforeRubyOptions.rubyGap = this.rubyOptions.rubyGap;
          this._beforeRubyOptions.rubyAlign = this.rubyOptions.rubyAlign;
        };

        Label.prototype._updateLines = function () {
          // ユーザのパーサを適用した後にも揃えるが、渡す前に改行記号を replace して統一する
          var fragments = this.rubyEnabled ? this.rubyParser(this.text.replace(/\r\n|\n/g, "\r")) : [this.text]; // Fragment のうち文字列のものを一文字ずつに分解する

          fragments = rp.flatmap(fragments, function (f) {
            if (typeof f !== "string") return f; // サロゲートペア文字を正しく分割する

            return f.replace(/\r\n|\n/g, "\r").match(/[\uD800-\uDBFF][\uDC00-\uDFFF]|[^\uD800-\uDFFF]/g) || [];
          });

          var undrawnLineInfos = this._divideToLines(fragments);

          var lines = [];
          var hasNotChanged = this._beforeFontSize === this.fontSize && this._beforeFont === this.font && !this._isDifferentRubyOptions(this._beforeRubyOptions, this.rubyOptions);

          for (var i = 0; i < undrawnLineInfos.length; i++) {
            var undrawnLineInfo = undrawnLineInfos[i];
            var line = this._lines[i];

            if (hasNotChanged && line !== undefined && undrawnLineInfo.sourceText === line.sourceText && undrawnLineInfo.width === line.width && undrawnLineInfo.height === line.height) {
              lines.push(line);
            } else {
              if (line && line.surface && !line.surface.destroyed()) {
                line.surface.destroy();
              }

              this._drawLineInfoSurface(undrawnLineInfo);

              lines.push(undrawnLineInfo);
            }
          } // 行数が減った場合、使われない行のSurfaceをdestroyする。


          for (var i = lines.length; i < this._lines.length; i++) {
            var line = this._lines[i];

            if (line.surface && !line.surface.destroyed()) {
              line.surface.destroy();
            }
          }

          this._lines = lines;
        };

        Label.prototype._drawLineInfoSurface = function (lineInfo) {
          var lineDrawInfo = lineInfo.fragmentDrawInfoArray;

          var rhi = this._calcRubyHeightInfo(lineDrawInfo);

          var lineSurface = this.scene.game.resourceFactory.createSurface(Math.ceil(lineInfo.width), Math.ceil(lineInfo.height));
          var lineRenderer = lineSurface.renderer();
          lineRenderer.begin();
          lineRenderer.save();
          var rbOffsetY = rhi.hasRubyFragmentDrawInfo || this.fixLineGap ? this.rubyOptions.rubyGap + rhi.maxRubyGlyphHeightWithOffsetY : 0;
          var minMinusOffsetY = lineInfo.minMinusOffsetY;

          for (var i = 0; i < lineDrawInfo.length; i++) {
            var drawInfo = lineDrawInfo[i];

            if (drawInfo instanceof fr.RubyFragmentDrawInfo) {
              this._drawRubyFragmentDrawInfo(lineRenderer, drawInfo, rbOffsetY - minMinusOffsetY, -rhi.minRubyMinusOffsetY);
            } else if (drawInfo instanceof fr.StringDrawInfo) {
              this._drawStringGlyphs(lineRenderer, this.font, drawInfo.glyphs, this.fontSize, 0, rbOffsetY - minMinusOffsetY, 0);
            }

            lineRenderer.translate(drawInfo.width, 0);
          }

          lineRenderer.restore();
          lineRenderer.end();
          lineInfo.surface = lineSurface;
        }; // 文字列の等幅描画


        Label.prototype._drawStringGlyphs = function (renderer, font, glyphs, fontSize, offsetX, offsetY, margin) {
          if (margin === void 0) {
            margin = 0;
          }

          renderer.save();
          renderer.translate(offsetX, offsetY);

          for (var i = 0; i < glyphs.length; i++) {
            var glyph = glyphs[i];
            var glyphScale = fontSize / font.size;
            var glyphWidth = glyph.advanceWidth * glyphScale;

            if (!glyph.isSurfaceValid) {
              glyph = this._createGlyph(glyph.code, font);
              if (!glyph) continue;
            }

            renderer.save();
            renderer.transform([glyphScale, 0, 0, glyphScale, 0, 0]);

            if (glyph.width > 0 && glyph.height > 0) {
              renderer.drawImage(glyph.surface, glyph.x, glyph.y, glyph.width, glyph.height, glyph.offsetX, glyph.offsetY);
            }

            renderer.restore();
            renderer.translate(glyphWidth + margin, 0);
          }

          renderer.restore();
        }; // ルビベースとルビテキストの描画


        Label.prototype._drawRubyFragmentDrawInfo = function (renderer, rubyDrawInfo, rbOffsetY, rtOffsetY) {
          var f = rubyDrawInfo.fragment;
          var rubyFontSize = "rubyFontSize" in f ? f.rubyFontSize : this.rubyOptions.rubyFontSize;
          var rubyAlign = "rubyAlign" in f ? f.rubyAlign : this.rubyOptions.rubyAlign;
          var rubyFont = "rubyFont" in f ? f.rubyFont : this.rubyOptions.rubyFont;
          var isRtWideThanRb = rubyDrawInfo.rtWidth > rubyDrawInfo.rbWidth;
          var width = rubyDrawInfo.width;
          var rtWidth = rubyDrawInfo.rtWidth;
          var rbWidth = rubyDrawInfo.rbWidth;
          var rtStartPositionX;
          var rbStartPositionX;
          var rtUnitMargin;
          var rbUnitMargin;

          switch (rubyAlign) {
            case rp.RubyAlign.Center:
              rtUnitMargin = 0;
              rbUnitMargin = 0;
              rtStartPositionX = isRtWideThanRb ? 0 : (width - rtWidth) / 2;
              rbStartPositionX = isRtWideThanRb ? (width - rbWidth) / 2 : 0;
              break;

            case rp.RubyAlign.SpaceAround:
              rtUnitMargin = rubyDrawInfo.rubyGlyphs.length > 0 ? (width - rtWidth) / rubyDrawInfo.rubyGlyphs.length : 0;
              rbUnitMargin = 0;
              rtStartPositionX = isRtWideThanRb ? 0 : rtUnitMargin / 2;
              rbStartPositionX = isRtWideThanRb ? (width - rbWidth) / 2 : 0;
              break;

            default:
              throw g.ExceptionFactory.createAssertionError("Label#_drawRubyFragmentDrawInfo: unknown rubyAlign.");
          }

          this._drawStringGlyphs(renderer, this.font, rubyDrawInfo.glyphs, this.fontSize, rbStartPositionX, rbOffsetY, rbUnitMargin);

          this._drawStringGlyphs(renderer, rubyFont, rubyDrawInfo.rubyGlyphs, rubyFontSize, rtStartPositionX, rtOffsetY, rtUnitMargin);
        };

        Label.prototype._calcRubyHeightInfo = function (drawInfoArray) {
          var maxRubyFontSize = this.rubyOptions.rubyFontSize;
          var maxRubyGlyphHeightWithOffsetY = 0;
          var maxRubyGap = this.rubyOptions.rubyGap;
          var hasRubyFragmentDrawInfo = false;
          var maxRealDrawHeight = 0;
          var realOffsetY;

          for (var i = 0; i < drawInfoArray.length; i++) {
            var ri = drawInfoArray[i];

            if (ri instanceof fr.RubyFragmentDrawInfo) {
              var f = ri.fragment;

              if (f.rubyFontSize > maxRubyFontSize) {
                maxRubyFontSize = f.rubyFontSize;
              }

              if (f.rubyGap > maxRubyGap) {
                maxRubyGap = f.rubyGap;
              }

              var rubyGlyphScale = (f.rubyFontSize ? f.rubyFontSize : this.rubyOptions.rubyFontSize) / (f.rubyFont ? f.rubyFont.size : this.rubyOptions.rubyFont.size);
              var currentMaxRubyGlyphHeightWithOffsetY = Math.max.apply(Math, ri.rubyGlyphs.map(function (glyph) {
                return glyph.offsetY > 0 ? glyph.height + glyph.offsetY : glyph.height;
              }));
              var currentMinRubyOffsetY = Math.min.apply(Math, ri.rubyGlyphs.map(function (glyph) {
                return glyph.offsetY > 0 ? glyph.offsetY : 0;
              }));

              if (maxRubyGlyphHeightWithOffsetY < currentMaxRubyGlyphHeightWithOffsetY * rubyGlyphScale) {
                maxRubyGlyphHeightWithOffsetY = currentMaxRubyGlyphHeightWithOffsetY * rubyGlyphScale;
              }

              var rubyFont = f.rubyFont ? f.rubyFont : this.rubyOptions.rubyFont;

              var currentRubyStandardOffsetY = this._calcStandardOffsetY(rubyFont);

              var currentFragmentRealDrawHeight = (currentMaxRubyGlyphHeightWithOffsetY - Math.min(currentMinRubyOffsetY, currentRubyStandardOffsetY)) * rubyGlyphScale;

              if (maxRealDrawHeight < currentFragmentRealDrawHeight) {
                maxRealDrawHeight = currentFragmentRealDrawHeight; // その行で描画されるルビのうち、もっとも実描画高さが高い文字が持つoffsetYを求める

                realOffsetY = Math.min(currentMinRubyOffsetY, currentRubyStandardOffsetY) * rubyGlyphScale;
              }

              hasRubyFragmentDrawInfo = true;
            }
          } // ルビが無い行でもfixLineGapが真の場合ルビの高さを使う


          if (maxRubyGlyphHeightWithOffsetY === 0) {
            maxRubyGlyphHeightWithOffsetY = this.rubyOptions.rubyFontSize;
          }

          var minRubyMinusOffsetY = this.trimMarginTop ? realOffsetY : 0;
          return {
            maxRubyFontSize: maxRubyFontSize,
            maxRubyGlyphHeightWithOffsetY: maxRubyGlyphHeightWithOffsetY,
            minRubyMinusOffsetY: minRubyMinusOffsetY,
            maxRubyGap: maxRubyGap,
            hasRubyFragmentDrawInfo: hasRubyFragmentDrawInfo
          };
        };

        Label.prototype._divideToLines = function (fragmentArray) {
          var state = {
            resultLines: [],
            currentStringDrawInfo: new fr.StringDrawInfo("", 0, []),
            currentLineInfo: {
              sourceText: "",
              fragmentDrawInfoArray: [],
              width: 0,
              height: 0,
              minMinusOffsetY: 0,
              surface: undefined
            },
            reservedLineBreakPosition: null
          };

          for (var i = 0; i < fragmentArray.length; i++) {
            this._addFragmentToState(state, fragmentArray, i);
          }

          this._flushCurrentStringDrawInfo(state);

          this._feedLine(state); // 行末ではないが、状態をflushするため改行処理を呼ぶ


          return state.resultLines;
        };

        Label.prototype._addFragmentToState = function (state, fragments, index) {
          var fragment = fragments[index];

          if (state.reservedLineBreakPosition !== null) {
            state.reservedLineBreakPosition--;
          }

          if (state.reservedLineBreakPosition === 0) {
            this._flushCurrentStringDrawInfo(state);

            this._feedLine(state);

            state.reservedLineBreakPosition = null;
          }

          if (typeof fragment === "string" && fragment === "\r") {
            /*
            // 行末に改行記号が来た場合、禁則処理によって改行すべきかは判断を保留し、一旦禁則処理による改行はしないことにする
            if (this._needFixLineBreakByRule(state)) {
                this._applyLineBreakRule(index, state);
            }
            */
            this._flushCurrentStringDrawInfo(state);

            this._feedLine(state);
          } else if (typeof fragment === "string") {
            var code = g.Util.charCodeAt(fragment, 0);
            if (!code) return;

            var glyph = this._createGlyph(code, this.font);

            if (!glyph) return;
            var glyphScale = this.fontSize / this.font.size;
            var glyphWidth = glyph.advanceWidth * glyphScale;

            if (this._needBreakLine(state, glyphWidth)) {
              this._breakLine(state, fragments, index);
            }

            state.currentStringDrawInfo.width += glyphWidth;
            state.currentStringDrawInfo.glyphs.push(glyph);
            state.currentStringDrawInfo.text += fragment;
          } else {
            var ri = this._createRubyFragmentDrawInfo(fragment);

            if (ri.width <= 0) return;

            this._flushCurrentStringDrawInfo(state);

            if (this._needBreakLine(state, ri.width)) {
              this._breakLine(state, fragments, index);
            }

            state.currentLineInfo.width += ri.width;
            state.currentLineInfo.fragmentDrawInfoArray.push(ri);
            state.currentLineInfo.sourceText += fragment.text;
          }
        };

        Label.prototype._createStringGlyph = function (text, font) {
          var glyphs = [];

          for (var i = 0; i < text.length; i++) {
            var code = g.Util.charCodeAt(text, i);
            if (!code) continue;

            var glyph = this._createGlyph(code, font);

            if (!glyph) continue;
            glyphs.push(glyph);
          }

          return glyphs;
        };

        Label.prototype._createGlyph = function (code, font) {
          var glyph = font.glyphForCharacter(code);

          if (!glyph) {
            var str = code & 0xFFFF0000 ? String.fromCharCode((code & 0xFFFF0000) >>> 16, code & 0xFFFF) : String.fromCharCode(code);
            console.warn("Label#_invalidateSelf(): failed to get a glyph for '" + str + "' " + "(BitmapFont might not have the glyph or DynamicFont might create a glyph larger than its atlas).");
          }

          return glyph;
        };

        Label.prototype._createRubyFragmentDrawInfo = function (fragment) {
          var glyphs = this._createStringGlyph(fragment.rb, this.font);

          var rubyGlyphs = this._createStringGlyph(fragment.rt, this.rubyOptions.rubyFont);

          var rubyFont = "rubyFont" in fragment ? fragment.rubyFont : this.rubyOptions.rubyFont;
          var rubyFontSize = "rubyFontSize" in fragment ? fragment.rubyFontSize : this.rubyOptions.rubyFontSize;
          var glyphScale = this.fontSize / this.font.size;
          var rubyGlyphScale = rubyFontSize / rubyFont.size;
          var rbWidth = glyphs.length > 0 ? glyphs.map(function (glyph) {
            return glyph.advanceWidth;
          }).reduce(function (pre, cu) {
            return pre + cu;
          }) * glyphScale : 0;
          var rtWidth = rubyGlyphs.length > 0 ? rubyGlyphs.map(function (glyph) {
            return glyph.advanceWidth;
          }).reduce(function (pre, cu) {
            return pre + cu;
          }) * rubyGlyphScale : 0;
          var width = rbWidth > rtWidth ? rbWidth : rtWidth;
          return new fr.RubyFragmentDrawInfo(fragment, width, rbWidth, rtWidth, glyphs, rubyGlyphs);
        };

        Label.prototype._flushCurrentStringDrawInfo = function (state) {
          if (state.currentStringDrawInfo.width > 0) {
            state.currentLineInfo.fragmentDrawInfoArray.push(state.currentStringDrawInfo);
            state.currentLineInfo.width += state.currentStringDrawInfo.width;
            state.currentLineInfo.sourceText += state.currentStringDrawInfo.text;
          }

          state.currentStringDrawInfo = new fr.StringDrawInfo("", 0, []);
        };

        Label.prototype._feedLine = function (state) {
          var glyphScale = this.fontSize / this.font.size;
          var minOffsetY = Infinity;
          var minMinusOffsetY = 0;
          var maxGlyphHeightWithOffsetY = 0;
          state.currentLineInfo.fragmentDrawInfoArray.forEach(function (fragmentDrawInfo) {
            fragmentDrawInfo.glyphs.forEach(function (glyph) {
              if (minMinusOffsetY > glyph.offsetY) {
                minMinusOffsetY = glyph.offsetY;
              } // offsetYの一番小さな値を探す


              if (minOffsetY > glyph.offsetY) minOffsetY = glyph.offsetY;
              var heightWithOffsetY = glyph.offsetY > 0 ? glyph.height + glyph.offsetY : glyph.height;

              if (maxGlyphHeightWithOffsetY < heightWithOffsetY) {
                maxGlyphHeightWithOffsetY = heightWithOffsetY;
              }
            });
          });
          minMinusOffsetY = minMinusOffsetY * glyphScale;
          maxGlyphHeightWithOffsetY = state.currentLineInfo.fragmentDrawInfoArray.length > 0 ? maxGlyphHeightWithOffsetY * glyphScale - minMinusOffsetY : this.fontSize;
          maxGlyphHeightWithOffsetY = Math.ceil(maxGlyphHeightWithOffsetY);

          var rhi = this._calcRubyHeightInfo(state.currentLineInfo.fragmentDrawInfoArray);

          state.currentLineInfo.height = rhi.hasRubyFragmentDrawInfo || this.fixLineGap ? maxGlyphHeightWithOffsetY + rhi.maxRubyGlyphHeightWithOffsetY + rhi.maxRubyGap : maxGlyphHeightWithOffsetY;
          state.currentLineInfo.minMinusOffsetY = minMinusOffsetY;

          if (this.trimMarginTop) {
            var minOffsetYInRange = Math.min(minOffsetY, this._calcStandardOffsetY(this.font)) * glyphScale;
            state.currentLineInfo.height -= minOffsetYInRange;
            state.currentLineInfo.minMinusOffsetY += minOffsetYInRange;
          }

          state.resultLines.push(state.currentLineInfo);
          state.currentLineInfo = {
            sourceText: "",
            fragmentDrawInfoArray: [],
            width: 0,
            height: 0,
            minMinusOffsetY: 0,
            surface: undefined
          };
        };

        Label.prototype._needBreakLine = function (state, width) {
          return this.lineBreak && width > 0 && state.reservedLineBreakPosition === null && state.currentLineInfo.width + state.currentStringDrawInfo.width + width > this._lineBreakWidth && state.currentLineInfo.width + state.currentStringDrawInfo.width > 0; // 行頭文字の場合は改行しない
        };

        Label.prototype._isDifferentRubyOptions = function (ro0, ro1) {
          return ro0.rubyFontSize !== ro1.rubyFontSize || ro0.rubyFont !== ro1.rubyFont || ro0.rubyGap !== ro1.rubyGap || ro0.rubyAlign !== ro1.rubyAlign;
        };

        Label.prototype._calcStandardOffsetY = function (font) {
          // 標準的な高さを持つグリフとして `M` を利用するが明確な根拠は無い
          var text = "M";
          var glyphM = font.glyphForCharacter(text.charCodeAt(0));
          return glyphM.offsetY;
        };
        /** stateのcurrent系プロパティを禁則処理的に正しい構造に再構築する */


        Label.prototype._breakLine = function (state, fragments, index) {
          if (!this.lineBreakRule) {
            this._flushCurrentStringDrawInfo(state);

            this._feedLine(state);

            return;
          }

          var correctLineBreakPosition = this.lineBreakRule(fragments, index); // 外部ルールが期待する改行位置

          var diff = correctLineBreakPosition - index;

          if (diff === 0) {
            this._flushCurrentStringDrawInfo(state);

            this._feedLine(state);
          } else if (diff > 0) {
            // 先送り改行
            state.reservedLineBreakPosition = diff;
          } else {
            // 巻き戻し改行
            this._flushCurrentStringDrawInfo(state);

            var droppedFragmentDrawInfoArray = []; // currentLineInfoのfragmentDrawInfoArrayを巻き戻す

            while (diff < 0) {
              var fragmentDrawInfoArray = state.currentLineInfo.fragmentDrawInfoArray;
              var lastDrawInfo = fragmentDrawInfoArray[fragmentDrawInfoArray.length - 1];

              if (lastDrawInfo instanceof fr.RubyFragmentDrawInfo) {
                diff++;
                droppedFragmentDrawInfoArray.push(lastDrawInfo);
                fragmentDrawInfoArray.pop();
              } else {
                if (-diff >= lastDrawInfo.text.length) {
                  diff += lastDrawInfo.text.length;
                  droppedFragmentDrawInfoArray.push(lastDrawInfo);
                  fragmentDrawInfoArray.pop();
                } else {
                  var droppedGlyphs = lastDrawInfo.glyphs.splice(diff);
                  var glyphScale = this.fontSize / this.font.size;
                  var droppedDrawInfoWidth = droppedGlyphs.reduce(function (acc, glyph) {
                    return glyph.advanceWidth * glyphScale + acc;
                  }, 0);
                  lastDrawInfo.width -= droppedDrawInfoWidth;
                  var droppedDrawInfoText = lastDrawInfo.text.substring(lastDrawInfo.text.length + diff);
                  lastDrawInfo.text = lastDrawInfo.text.substring(0, lastDrawInfo.text.length + diff);
                  droppedFragmentDrawInfoArray.push(new fr.StringDrawInfo(droppedDrawInfoText, droppedDrawInfoWidth, droppedGlyphs));
                  diff = 0;
                }
              }
            } // currentLineInfoのその他を更新する


            var droppedWidth = 0;
            var droppedSourceText = "";
            droppedFragmentDrawInfoArray.forEach(function (fragment) {
              droppedWidth += fragment.width;
              droppedSourceText += fragment.text;
            });
            state.currentLineInfo.width -= droppedWidth;
            var sourceText = state.currentLineInfo.sourceText;
            state.currentLineInfo.sourceText = sourceText.substr(0, sourceText.length - droppedSourceText.length);

            this._feedLine(state);

            state.currentLineInfo.fragmentDrawInfoArray = droppedFragmentDrawInfoArray;
            state.currentLineInfo.width = droppedWidth;
            state.currentLineInfo.sourceText = droppedSourceText;
          }
        };

        return Label;
      }(g.CacheableE);

      module.exports = Label;
    }, {
      "./DefaultRubyParser": 4,
      "./FragmentDrawInfo": 5,
      "./RubyParser": 7
    }],
    7: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.flatmap = exports.RubyAlign = void 0;
      var RubyAlign;

      (function (RubyAlign) {
        /**
         * rtの字間は固定で中央に揃える。
         */
        RubyAlign[RubyAlign["Center"] = 0] = "Center";
        /**
         * rb幅に合わせてrtの字間を揃える。
         */

        RubyAlign[RubyAlign["SpaceAround"] = 1] = "SpaceAround";
      })(RubyAlign = exports.RubyAlign || (exports.RubyAlign = {}));

      function flatmap(arr, func) {
        return Array.prototype.concat.apply([], arr.map(func));
      }

      exports.flatmap = flatmap;
    }, {}],
    8: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.defaultRubyParser = exports.RubyAlign = void 0;
      exports.Label = require("./Label");
      exports.FragmentDrawInfo = require("./FragmentDrawInfo");
      exports.RubyParser = require("./RubyParser");
      exports.RubyAlign = exports.RubyParser.RubyAlign; // tslintが誤動作するので一時的に無効化する

      /* tslint:disable: no-unused-variable */

      var DRP = require("./DefaultRubyParser");

      exports.defaultRubyParser = DRP.parse;
      /* tslint:enable: no-unused-variable */
    }, {
      "./DefaultRubyParser": 4,
      "./FragmentDrawInfo": 5,
      "./Label": 6,
      "./RubyParser": 7
    }],
    9: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics2 = function extendStatics(d, b) {
          _extendStatics2 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics2(d, b);
        };

        return function (d, b) {
          _extendStatics2(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();
      /**
       * RPGのマップなどで利用される、マップチップとタイルデータによるパターン描画を行うエンティティ。
       */


      var Tile =
      /** @class */
      function (_super) {
        __extends(Tile, _super);
        /**
         * 各種パラメータを指定して `Tile` のインスタンスを生成する。
         *
         * @param param このエンティティに指定するパラメータ
         */


        function Tile(param) {
          var _this = _super.call(this, param) || this;

          _this.tileWidth = param.tileWidth;
          _this.tileHeight = param.tileHeight;
          _this.tileData = param.tileData;
          _this.tileChips = g.SurfaceUtil.asSurface(param.src);
          _this.height = _this.tileHeight * _this.tileData.length;
          _this.width = _this.tileWidth * _this.tileData[0].length;

          _this._invalidateSelf();

          _this.redrawArea = param.redrawArea;
          _this._drawnTileData = undefined;
          return _this;
        }
        /**
         * このエンティティ自身の描画を行う。
         * このメソッドはエンジンから暗黙に呼び出され、ゲーム開発者が呼び出す必要はない。
         */


        Tile.prototype.renderSelf = function (renderer, camera) {
          if (this._renderedCamera !== camera) {
            this.state &= ~2
            /* Cached */
            ;
            this._renderedCamera = camera;
          }

          if (!(this.state & 2
          /* Cached */
          )) {
            var isNew = !this._cache || this._cache.width < Math.ceil(this.width) || this._cache.height < Math.ceil(this.height);

            if (isNew) {
              if (this._cache && !this._cache.destroyed()) {
                this._cache.destroy();
              }

              this._cache = this.scene.game.resourceFactory.createSurface(Math.ceil(this.width), Math.ceil(this.height));
              this._renderer = this._cache.renderer();
              this._drawnTileData = [];

              for (var y = 0; y < this.tileData.length; ++y) {
                this._drawnTileData[y] = [];

                for (var x = 0; x < this.tileData[y].length; ++x) {
                  this._drawnTileData[y][x] = -1;
                }
              }
            }

            this._renderer.begin(); // `CacheableE#renderSelf()` ではここで `this._renderer.clear()` を呼び出すが、
            // `Tile` は `this._cache` の描画状態を再利用するので `this._renderer.clear()` を呼び出す必要はない。


            this.renderCache(this._renderer);
            this.state |= 2
            /* Cached */
            ;

            this._renderer.end();
          }

          if (this._cache && this.width > 0 && this.height > 0) {
            renderer.drawImage(this._cache, 0, 0, this.width, this.height, 0, 0);
          }

          return this._shouldRenderChildren;
        };

        Tile.prototype.renderCache = function (renderer) {
          if (!this.tileData) throw g.ExceptionFactory.createAssertionError("Tile#_renderCache: don't have a tile data");

          if (this.tileWidth <= 0 || this.tileHeight <= 0) {
            return;
          }

          renderer.save();

          for (var y = 0; y < this.tileData.length; ++y) {
            var row = this.tileData[y];

            for (var x = 0; x < row.length; ++x) {
              var tile = row[x];

              if (tile < 0) {
                continue;
              }

              if (this._drawnTileData[y] !== undefined) {
                if (this._drawnTileData[y][x] === tile) {
                  continue;
                }
              }

              var tileX = this.tileWidth * (tile % this._tilesInRow);
              var tileY = this.tileHeight * Math.floor(tile / this._tilesInRow);
              var dx = this.tileWidth * x;
              var dy = this.tileHeight * y;

              if (this.redrawArea !== undefined) {
                if (dx + this.tileWidth < this.redrawArea.x || dx >= this.redrawArea.x + this.redrawArea.width || dy + this.tileHeight < this.redrawArea.y || dy >= this.redrawArea.y + this.redrawArea.height) {
                  continue;
                }
              }

              renderer.setCompositeOperation("destination-out");
              renderer.fillRect(dx, dy, this.tileWidth, this.tileHeight, "silver"); // DestinationOutなので色はなんでも可

              renderer.setCompositeOperation("source-over");
              renderer.drawImage(this.tileChips, tileX, tileY, this.tileWidth, this.tileHeight, dx, dy);
              this._drawnTileData[y][x] = this.tileData[y][x];
            }
          }

          renderer.restore();
        };

        Tile.prototype.invalidate = function () {
          this._invalidateSelf();

          _super.prototype.invalidate.call(this);
        };
        /**
         * このエンティティを破棄する。
         * デフォルトでは利用しているマップチップの `Surface` `Surface` の破棄は行わない点に注意。
         * @param destroySurface trueを指定した場合、このエンティティが抱えるマップチップの `Surface` も合わせて破棄する
         */


        Tile.prototype.destroy = function (destroySurface) {
          if (destroySurface && this.tileChips && !this.tileChips.destroyed()) {
            this.tileChips.destroy();
          }

          this.tileChips = undefined;

          _super.prototype.destroy.call(this);
        };

        Tile.prototype._invalidateSelf = function () {
          this._tilesInRow = Math.floor(this.tileChips.width / this.tileWidth);
        };

        return Tile;
      }(g.CacheableE);

      module.exports = Tile;
    }, {}],
    10: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Tile = require("./Tile");
    }, {
      "./Tile": 9
    }],
    11: [function (require, module, exports) {
      "use strict";

      var ActionType;

      (function (ActionType) {
        ActionType[ActionType["Wait"] = 0] = "Wait";
        ActionType[ActionType["Call"] = 1] = "Call";
        ActionType[ActionType["TweenTo"] = 2] = "TweenTo";
        ActionType[ActionType["TweenBy"] = 3] = "TweenBy";
        ActionType[ActionType["TweenByMult"] = 4] = "TweenByMult";
        ActionType[ActionType["Cue"] = 5] = "Cue";
        ActionType[ActionType["Every"] = 6] = "Every";
      })(ActionType || (ActionType = {}));

      module.exports = ActionType;
    }, {}],
    12: [function (require, module, exports) {
      "use strict";
      /**
       * Easing関数群。
       * 参考: http://gizma.com/easing/
       */

      var Easing;

      (function (Easing) {
        /**
         * 入力値をlinearした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function linear(t, b, c, d) {
          return c * t / d + b;
        }

        Easing.linear = linear;
        /**
         * 入力値をeaseInQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuad(t, b, c, d) {
          t /= d;
          return c * t * t + b;
        }

        Easing.easeInQuad = easeInQuad;
        /**
         * 入力値をeaseOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuad(t, b, c, d) {
          t /= d;
          return -c * t * (t - 2) + b;
        }

        Easing.easeOutQuad = easeOutQuad;
        /**
         * 入力値をeaseInOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuad(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t + b;
          --t;
          return -c / 2 * (t * (t - 2) - 1) + b;
        }

        Easing.easeInOutQuad = easeInOutQuad;
        /**
         * 入力値をeaseInQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCubic(t, b, c, d) {
          t /= d;
          return c * t * t * t + b;
        }

        Easing.easeInCubic = easeInCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInCubic` を用いるべきである。
         */

        Easing.easeInQubic = easeInCubic;
        /**
         * 入力値をeaseOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCubic(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t + 1) + b;
        }

        Easing.easeOutCubic = easeOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeOutCubic` を用いるべきである。
         */

        Easing.easeOutQubic = easeOutCubic;
        /**
         * 入力値をeaseInOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCubic(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t + 2) + b;
        }

        Easing.easeInOutCubic = easeInOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInOutCubic` を用いるべきである。
         */

        Easing.easeInOutQubic = easeInOutCubic;
        /**
         * 入力値をeaseInQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuart(t, b, c, d) {
          t /= d;
          return c * t * t * t * t + b;
        }

        Easing.easeInQuart = easeInQuart;
        /**
         * 入力値をeaseOutQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuart(t, b, c, d) {
          t /= d;
          --t;
          return -c * (t * t * t * t - 1) + b;
        }

        Easing.easeOutQuart = easeOutQuart;
        /**
         * 入力値をeaseInQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuint(t, b, c, d) {
          t /= d;
          return c * t * t * t * t * t + b;
        }

        Easing.easeInQuint = easeInQuint;
        /**
         * 入力値をeaseOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuint(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t * t * t + 1) + b;
        }

        Easing.easeOutQuint = easeOutQuint;
        /**
         * 入力値をeaseInOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuint(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t * t * t + 2) + b;
        }

        Easing.easeInOutQuint = easeInOutQuint;
        /**
         * 入力値をeaseInSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInSine(t, b, c, d) {
          return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
        }

        Easing.easeInSine = easeInSine;
        /**
         * 入力値をeaseOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutSine(t, b, c, d) {
          return c * Math.sin(t / d * (Math.PI / 2)) + b;
        }

        Easing.easeOutSine = easeOutSine;
        /**
         * 入力値をeaseInOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutSine(t, b, c, d) {
          return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
        }

        Easing.easeInOutSine = easeInOutSine;
        /**
         * 入力値をeaseInExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInExpo(t, b, c, d) {
          return c * Math.pow(2, 10 * (t / d - 1)) + b;
        }

        Easing.easeInExpo = easeInExpo;
        /**
         * 入力値をeaseInOutExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutExpo(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
          --t;
          return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
        }

        Easing.easeInOutExpo = easeInOutExpo;
        /**
         * 入力値をeaseInCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCirc(t, b, c, d) {
          t /= d;
          return -c * (Math.sqrt(1 - t * t) - 1) + b;
        }

        Easing.easeInCirc = easeInCirc;
        /**
         * 入力値をeaseOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCirc(t, b, c, d) {
          t /= d;
          --t;
          return c * Math.sqrt(1 - t * t) + b;
        }

        Easing.easeOutCirc = easeOutCirc;
        /**
         * 入力値をeaseInOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCirc(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
          t -= 2;
          return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
        }

        Easing.easeInOutCirc = easeInOutCirc;
      })(Easing || (Easing = {}));

      module.exports = Easing;
    }, {}],
    13: [function (require, module, exports) {
      "use strict";

      var Tween = require("./Tween");
      /**
       * タイムライン機能を提供するクラス。
       */


      var Timeline =
      /** @class */
      function () {
        /**
         * Timelineを生成する。
         * @param scene タイムラインを実行する `Scene`
         */
        function Timeline(scene) {
          this._scene = scene;
          this._tweens = [];
          this._fps = this._scene.game.fps;
          this.paused = false;
          scene.update.add(this._handler, this);
        }
        /**
         * Timelineに紐付いたTweenを生成する。
         * @param target タイムライン処理の対象にするオブジェクト
         * @param option Tweenの生成オプション。省略された場合、 {modified: target.modified, destroyed: target.destroyed} が与えられた時と同様の処理を行う。
         */


        Timeline.prototype.create = function (target, option) {
          var t = new Tween(target, option);

          this._tweens.push(t);

          return t;
        };
        /**
         * Timelineに紐付いたTweenを削除する。
         * @param tween 削除するTween。
         */


        Timeline.prototype.remove = function (tween) {
          var index = this._tweens.indexOf(tween);

          if (index < 0) {
            return;
          }

          this._tweens.splice(index, 1);
        };
        /**
         * Timelineに紐付いた全Tweenのアクションを完了させる。詳細は `Tween#complete()`の説明を参照。
         */


        Timeline.prototype.completeAll = function () {
          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween.complete();
            }
          }

          this.clear();
        };
        /**
         * Timelineに紐付いた全Tweenのアクションを取り消す。詳細は `Tween#cancel()`の説明を参照。
         * @param revert ターゲットのプロパティをアクション開始前に戻すかどうか (指定しない場合は `false`)
         */


        Timeline.prototype.cancelAll = function (revert) {
          if (revert === void 0) {
            revert = false;
          }

          if (!revert) {
            this.clear();
            return;
          }

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween.cancel(true);
            }
          }

          this.clear();
        };
        /**
         * Timelineに紐付いた全Tweenの紐付けを解除する。
         */


        Timeline.prototype.clear = function () {
          this._tweens.length = 0;
        };
        /**
         * このTimelineを破棄する。
         */


        Timeline.prototype.destroy = function () {
          this._tweens.length = 0;

          if (!this._scene.destroyed()) {
            this._scene.update.remove(this._handler, this);
          }

          this._scene = undefined;
        };
        /**
         * このTimelineが破棄済みであるかを返す。
         */


        Timeline.prototype.destroyed = function () {
          return this._scene === undefined;
        };

        Timeline.prototype._handler = function () {
          if (this._tweens.length === 0 || this.paused) {
            return;
          }

          var tmp = [];

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween._fire(1000 / this._fps);

              tmp.push(tween);
            }
          }

          this._tweens = tmp;
        };

        return Timeline;
      }();

      module.exports = Timeline;
    }, {
      "./Tween": 14
    }],
    14: [function (require, module, exports) {
      "use strict";

      var Easing = require("./Easing");

      var ActionType = require("./ActionType");
      /**
       * オブジェクトの状態を変化させるアクションを定義するクラス。
       * 本クラスのインスタンス生成には`Timeline#create()`を利用する。
       */


      var Tween =
      /** @class */
      function () {
        /**
         * Tweenを生成する。
         * @param target 対象となるオブジェクト
         * @param option オプション
         */
        function Tween(target, option) {
          this._target = target;
          this._stepIndex = 0;
          this._loop = !!option && !!option.loop;
          this._modifiedHandler = undefined;

          if (option && option.modified) {
            this._modifiedHandler = option.modified;
          } else if (target && target.modified) {
            this._modifiedHandler = target.modified;
          }

          this._destroyedHandler = undefined;

          if (option && option.destroyed) {
            this._destroyedHandler = option.destroyed;
          } else if (target && target.destroyed) {
            this._destroyedHandler = target.destroyed;
          }

          this._steps = [];
          this._lastStep = undefined;
          this._pararel = false;
          this._initialProp = {};
          this.paused = false;
        }
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.to = function (props, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: ActionType.TweenTo,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * 変化内容はアクション開始時を基準とした相対値で指定する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         * @param multiply `true`を指定すると`props`の値をアクション開始時の値に掛け合わせた値が終了値となる（指定しない場合は`false`）
         */


        Tween.prototype.by = function (props, duration, easing, multiply) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          if (multiply === void 0) {
            multiply = false;
          }

          var type = multiply ? ActionType.TweenByMult : ActionType.TweenBy;
          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: type,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 次に追加されるアクションを、このメソッド呼び出しの直前に追加されたアクションと並列に実行させる。
         * `Tween#con()`で並列実行を指定されたアクションが全て終了後、次の並列実行を指定されていないアクションを実行する。
         */


        Tween.prototype.con = function () {
          this._pararel = true;
          return this;
        };
        /**
         * オブジェクトの変化を停止するアクションを追加する。
         * @param duration 停止する時間（ミリ秒）
         */


        Tween.prototype.wait = function (duration) {
          var action = {
            duration: duration,
            type: ActionType.Wait,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 関数を即座に実行するアクションを追加する。
         * @param func 実行する関数
         */


        Tween.prototype.call = function (func) {
          var action = {
            func: func,
            type: ActionType.Call,
            duration: 0,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 一時停止するアクションを追加する。
         * 内部的には`Tween#call()`で`Tween#paused`に`true`をセットしている。
         */


        Tween.prototype.pause = function () {
          var _this = this;

          return this.call(function () {
            _this.paused = true;
          });
        };
        /**
         * 待機時間をキーとして実行したい関数を複数指定する。
         * @param actions 待機時間をキーとして実行したい関数を値としたオブジェクト
         */


        Tween.prototype.cue = function (funcs) {
          var keys = Object.keys(funcs);
          keys.sort(function (a, b) {
            return Number(a) > Number(b) ? 1 : -1;
          });
          var q = [];

          for (var i = 0; i < keys.length; ++i) {
            q.push({
              time: Number(keys[i]),
              func: funcs[keys[i]]
            });
          }

          var action = {
            type: ActionType.Cue,
            duration: Number(keys[keys.length - 1]),
            cue: q,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 指定した時間を経過するまで毎フレーム指定した関数を呼び出すアクションを追加する。
         * @param func 毎フレーム呼び出される関数。第一引数は経過時間、第二引数はEasingした結果の変化量（0-1）となる。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.every = function (func, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            func: func,
            type: ActionType.Every,
            easing: easing,
            duration: duration,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * ターゲットをフェードインさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeIn = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 1
          }, duration, easing);
        };
        /**
         * ターゲットをフェードアウトさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeOut = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 0
          }, duration, easing);
        };
        /**
         * ターゲットを指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveTo = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した相対座標に移動するアクションを追加する。相対座標の基準値はアクション開始時の座標となる。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveBy = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットのX座標を指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveX = function (x, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x
          }, duration, easing);
        };
        /**
         * ターゲットのY座標を指定した座標に移動するアクションを追加する。
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveY = function (y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateTo = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットをアクション開始時の角度を基準とした相対角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateBy = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットを指定した倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleTo = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing);
        };
        /**
         * ターゲットのアクション開始時の倍率に指定した倍率を掛け合わせた倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleBy = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing, true);
        };
        /**
         * このTweenに追加されたすべてのアクションを即座に完了する。
         * `Tween#loop`が`true`の場合、ループの終端までのアクションがすべて実行される。
         */


        Tween.prototype.complete = function () {
          for (var i = this._stepIndex; i < this._steps.length; ++i) {
            for (var j = 0; j < this._steps[i].length; ++j) {
              var action = this._steps[i][j];

              if (!action.initialized) {
                this._initAction(action);
              }

              var keys = Object.keys(action.goal);

              for (var k = 0; k < keys.length; ++k) {
                var key = keys[k];
                this._target[key] = action.goal[key];
              }

              if (action.type === ActionType.Call && typeof action.func === "function") {
                action.func.call(this._target);
              } else if (action.type === ActionType.Cue && action.cue) {
                for (var k = 0; k < action.cue.length; ++k) {
                  action.cue[k].func.call(this._target);
                }
              } else if (action.type === ActionType.Every && typeof action.func === "function") {
                action.func.call(this._target, action.duration, 1);
              }
            }
          }

          this._stepIndex = this._steps.length;
          this._loop = false;
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;

          if (this._modifiedHandler) {
            this._modifiedHandler.call(this._target);
          }
        };
        /**
         * このTweenに追加されたすべてのアクションを取り消す。
         * `revert`を`true` にした場合、ターゲットのプロパティをアクション開始前に戻す。
         * ただし`Tween#call()`や`Tween#every()`により変更されたプロパティは戻らない点に注意。
         * @param revert ターゲットのプロパティをアクション開始前に戻すかどうか (指定しない場合は `false`)
         */


        Tween.prototype.cancel = function (revert) {
          if (revert === void 0) {
            revert = false;
          }

          if (revert) {
            var keys = Object.keys(this._initialProp);

            for (var i = 0; i < keys.length; ++i) {
              var key = keys[i];
              this._target[key] = this._initialProp[key];
            }
          }

          this._stepIndex = this._steps.length;
          this._loop = false;
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;

          if (this._modifiedHandler) {
            this._modifiedHandler.call(this._target);
          }
        };
        /**
         * アニメーションが終了しているかどうかを返す。
         * `_target`が破棄された場合又は、全アクションの実行が終了した場合に`true`を返す。
         */


        Tween.prototype.isFinished = function () {
          var ret = false;

          if (this._destroyedHandler) {
            ret = this._destroyedHandler.call(this._target);
          }

          if (!ret) {
            ret = this._stepIndex !== 0 && this._stepIndex >= this._steps.length && !this._loop;
          }

          return ret;
        };
        /**
         * アニメーションを実行する。
         * @param delta 前フレームからの経過時間
         */


        Tween.prototype._fire = function (delta) {
          if (this._steps.length === 0 || this.isFinished() || this.paused) {
            return;
          }

          if (this._stepIndex >= this._steps.length) {
            if (this._loop) {
              this._stepIndex = 0;
            } else {
              return;
            }
          }

          var actions = this._steps[this._stepIndex];
          var remained = false;

          for (var i = 0; i < actions.length; ++i) {
            var action = actions[i];

            if (!action.initialized) {
              this._initAction(action);
            }

            if (action.finished) {
              continue;
            }

            action.elapsed += delta;

            switch (action.type) {
              case ActionType.Call:
                action.func.call(this._target);
                break;

              case ActionType.Every:
                var progress = action.easing(action.elapsed, 0, 1, action.duration);

                if (progress > 1) {
                  progress = 1;
                }

                action.func.call(this._target, action.elapsed, progress);
                break;

              case ActionType.TweenTo:
              case ActionType.TweenBy:
              case ActionType.TweenByMult:
                var keys = Object.keys(action.goal);

                for (var j = 0; j < keys.length; ++j) {
                  var key = keys[j]; // アクションにより undefined が指定されるケースと初期値を区別するため Object.prototype.hasOwnProperty() を利用
                  // (number以外が指定されるケースは存在しないが念の為)

                  if (!this._initialProp.hasOwnProperty(key)) {
                    this._initialProp[key] = this._target[key];
                  }

                  if (action.elapsed >= action.duration) {
                    this._target[key] = action.goal[key];
                  } else {
                    this._target[key] = action.easing(action.elapsed, action.start[key], action.goal[key] - action.start[key], action.duration);
                  }
                }

                break;

              case ActionType.Cue:
                var cueAction = action.cue[action.cueIndex];

                if (cueAction !== undefined && action.elapsed >= cueAction.time) {
                  cueAction.func.call(this._target);
                  ++action.cueIndex;
                }

                break;
            }

            if (this._modifiedHandler) {
              this._modifiedHandler.call(this._target);
            }

            if (action.elapsed >= action.duration) {
              action.finished = true;
            } else {
              remained = true;
            }
          }

          if (!remained) {
            for (var k = 0; k < actions.length; ++k) {
              actions[k].initialized = false;
            }

            ++this._stepIndex;
          }
        };
        /**
         * Tweenの実行状態をシリアライズして返す。
         */


        Tween.prototype.serializeState = function () {
          var tData = {
            _stepIndex: this._stepIndex,
            _initialProp: this._initialProp,
            _steps: []
          };

          for (var i = 0; i < this._steps.length; ++i) {
            tData._steps[i] = [];

            for (var j = 0; j < this._steps[i].length; ++j) {
              tData._steps[i][j] = {
                input: this._steps[i][j].input,
                start: this._steps[i][j].start,
                goal: this._steps[i][j].goal,
                duration: this._steps[i][j].duration,
                elapsed: this._steps[i][j].elapsed,
                type: this._steps[i][j].type,
                cueIndex: this._steps[i][j].cueIndex,
                initialized: this._steps[i][j].initialized,
                finished: this._steps[i][j].finished
              };
            }
          }

          return tData;
        };
        /**
         * Tweenの実行状態を復元する。
         * @param serializedstate 復元に使う情報。
         */


        Tween.prototype.deserializeState = function (serializedState) {
          this._stepIndex = serializedState._stepIndex;
          this._initialProp = serializedState._initialProp;

          for (var i = 0; i < serializedState._steps.length; ++i) {
            for (var j = 0; j < serializedState._steps[i].length; ++j) {
              if (!serializedState._steps[i][j] || !this._steps[i][j]) continue;
              this._steps[i][j].input = serializedState._steps[i][j].input;
              this._steps[i][j].start = serializedState._steps[i][j].start;
              this._steps[i][j].goal = serializedState._steps[i][j].goal;
              this._steps[i][j].duration = serializedState._steps[i][j].duration;
              this._steps[i][j].elapsed = serializedState._steps[i][j].elapsed;
              this._steps[i][j].type = serializedState._steps[i][j].type;
              this._steps[i][j].cueIndex = serializedState._steps[i][j].cueIndex;
              this._steps[i][j].initialized = serializedState._steps[i][j].initialized;
              this._steps[i][j].finished = serializedState._steps[i][j].finished;
            }
          }
        };
        /**
         * `this._pararel`が`false`の場合は新規にステップを作成し、アクションを追加する。
         * `this._pararel`が`true`の場合は最後に作成したステップにアクションを追加する。
         */


        Tween.prototype._push = function (action) {
          if (this._pararel) {
            this._lastStep.push(action);
          } else {
            var index = this._steps.push([action]) - 1;
            this._lastStep = this._steps[index];
          }

          this._pararel = false;
        };

        Tween.prototype._initAction = function (action) {
          action.elapsed = 0;
          action.start = {};
          action.goal = {};
          action.cueIndex = 0;
          action.finished = false;
          action.initialized = true;

          if (action.type !== ActionType.TweenTo && action.type !== ActionType.TweenBy && action.type !== ActionType.TweenByMult) {
            return;
          }

          var keys = Object.keys(action.input);

          for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];

            if (this._target[key] !== undefined) {
              action.start[key] = this._target[key];

              if (action.type === ActionType.TweenTo) {
                action.goal[key] = action.input[key];
              } else if (action.type === ActionType.TweenBy) {
                action.goal[key] = action.start[key] + action.input[key];
              } else if (action.type === ActionType.TweenByMult) {
                action.goal[key] = action.start[key] * action.input[key];
              }
            }
          }
        };

        return Tween;
      }();

      module.exports = Tween;
    }, {
      "./ActionType": 11,
      "./Easing": 12
    }],
    15: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Timeline = require("./Timeline");
      exports.Tween = require("./Tween");
      exports.Easing = require("./Easing");
    }, {
      "./Easing": 12,
      "./Timeline": 13,
      "./Tween": 14
    }],
    16: [function (require, module, exports) {
      "use strict";

      var __assign = this && this.__assign || function () {
        __assign = Object.assign || function (t) {
          for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];

            for (var p in s) {
              if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
          }

          return t;
        };

        return __assign.apply(this, arguments);
      };

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.FallbackDialog = void 0;

      var akashic_hover_plugin_1 = require("@akashic-extension/akashic-hover-plugin");

      var HoverPluginRaw = require("@akashic-extension/akashic-hover-plugin/lib/HoverPlugin"); // Ugh! HoverPlugin が Akashic Engine 向けに中途半端に CommonJS で (module.exports = HoverPlugin と)
      // 定義されている関係で、 import すると TS の型と実体が合わない。無理やり解消する。
      // (import * as ... すると、 JS 的には HoverPlugin の実体が手に入るが、TS 上では namespace と誤認される)
      // さらにおそらく akashic-hover-plugin 側のバグで、型があっていないのでそれも無理やり合わせる。
      // (コンストラクタ第二引数が間違っている。実装上は any キャストして正しく使っている)


      var HoverPlugin = HoverPluginRaw;

      function drawCircle(rendr, centerX, centerY, radius, cssColor) {
        for (var y = centerY - radius | 0; y <= Math.ceil(centerY + radius); ++y) {
          var w = radius * Math.cos(Math.asin((centerY - y) / radius));
          rendr.fillRect(centerX - w, y, 2 * w, 1, cssColor);
        }
      }

      function makeSurface(w, h, drawer) {
        var s = g.game.resourceFactory.createSurface(Math.ceil(w), Math.ceil(h));
        var r = s.renderer();
        r.begin();
        drawer(r);
        r.end();
        return s;
      }

      function animate(e, motions) {
        var onEnd = new g.Trigger();
        var frameTime = 1000 / g.game.fps;
        var step = 0;
        var time = 0;
        var mot = motions[0];
        var ended = false;

        function update(delta) {
          time += delta;

          if (time > mot.duration) {
            ended = ++step >= motions.length;

            if (ended) {
              time = mot.duration;
              e.scene.onUpdate.addOnce(onEnd.fire, onEnd);
            } else {
              time -= mot.duration;
              mot = motions[step];
            }
          }

          var r = Math.min(1, time / mot.duration);
          var scale = mot.scale,
              opacity = mot.opacity;
          if (scale) e.scaleX = e.scaleY = scale[0] + (scale[1] - scale[0]) * r;
          if (opacity) e.opacity = opacity[0] + (opacity[1] - opacity[0]) * r;
          e.modified();
          return ended;
        }

        update(0);
        e.onUpdate.add(function () {
          return update(frameTime);
        });
        return onEnd;
      }

      var FallbackDialog =
      /** @class */
      function () {
        function FallbackDialog(name) {
          var _this = this;

          this.onEnd = new g.Trigger();
          this.isHoverPluginStarted = false;
          this.timer = null;
          if (!FallbackDialog.isSupported()) return;
          var game = g.game;
          var gameWidth = game.width,
              gameHeight = game.height;
          var baseWidth = 1280;
          var ratio = gameWidth / baseWidth;
          var titleFontSize = Math.round(32 * ratio);
          var fontSize = Math.round(28 * ratio);
          var lineMarginRate = 0.3;
          var lineHeightRate = 1 + lineMarginRate;
          var titleTopMargin = 80 * ratio;
          var titleBotMargin = 32 * ratio;
          var buttonTopMargin = 42 * ratio;
          var buttonWidth = 360 * ratio;
          var buttonHeight = 82 * ratio;
          var buttonBotMargin = 72 * ratio;
          var colorBlue = "#4a8de1";
          var colorWhite = "#fff";
          var dialogWidth = 960 * ratio | 0;
          var dialogHeight = titleTopMargin + titleFontSize * lineHeightRate * 2 + titleBotMargin + (fontSize + fontSize * lineHeightRate) + // 一行目のマージンは titleBotMargin に繰り込まれている
          buttonTopMargin + buttonHeight + buttonBotMargin | 0;
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: g.FontFamily.SansSerif,
            size: titleFontSize,
            fontWeight: g.FontWeight.Bold,
            fontColor: "#252525"
          });
          var surfSize = Math.ceil(32 * ratio) & ~1; // 切り上げて偶数に丸める

          var surfHalf = surfSize / 2;
          var dialogBgSurf = makeSurface(surfSize, surfSize, function (r) {
            return drawCircle(r, surfHalf, surfHalf, surfHalf, colorWhite);
          });
          var btnActiveBgSurf = makeSurface(surfSize, surfSize, function (r) {
            return drawCircle(r, surfHalf, surfHalf, surfHalf, colorBlue);
          });
          var btnBgSurf = makeSurface(surfSize, surfSize, function (r) {
            drawCircle(r, surfHalf, surfHalf, surfHalf, colorBlue);
            drawCircle(r, surfHalf, surfHalf, 12 * ratio, colorWhite);
          });

          function makeLabel(param) {
            return new g.Label(__assign({
              scene: scene,
              font: font,
              local: true,
              textAlign: g.TextAlign.Center,
              widthAutoAdjust: false
            }, param));
          }

          var scene = this.scene = game.scene();
          var bg = this.bgRect = new g.FilledRect({
            scene: scene,
            local: true,
            width: gameWidth,
            height: gameHeight,
            cssColor: "rgba(0, 0, 0, 0.5)",
            touchable: true // 後ろの touch を奪って modal にする

          });
          var dialogPane = this.dialogPane = new g.Pane({
            scene: scene,
            local: true,
            width: dialogWidth,
            height: dialogHeight,
            anchorX: 0.5,
            anchorY: 0.5,
            x: game.width / 2 | 0,
            y: game.height / 2 | 0,
            backgroundImage: dialogBgSurf,
            backgroundEffector: new g.NinePatchSurfaceEffector(game, dialogBgSurf.width / 2 - 1),
            parent: bg
          });
          var dialogTextX = 80 * ratio | 0;
          var dialogTextWidth = 800 * ratio | 0;
          var y = 0;
          y += titleTopMargin + titleFontSize * lineMarginRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "このコンテンツは名前を利用します。",
            fontSize: titleFontSize,
            width: dialogTextWidth
          }));
          y += titleFontSize * lineHeightRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "\u3042\u306A\u305F\u306F\u300C" + name + "\u300D\u3067\u3059\u3002",
            fontSize: titleFontSize,
            width: dialogTextWidth
          }));
          y += titleFontSize + titleBotMargin | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "ユーザ名で参加するには、",
            fontSize: fontSize,
            width: dialogTextWidth
          }));
          y += fontSize * lineHeightRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "最新のニコニコ生放送アプリに更新してください。",
            fontSize: fontSize,
            width: dialogTextWidth
          }));
          y += fontSize + buttonTopMargin | 0;
          var buttonPane = new g.Pane({
            scene: scene,
            local: true,
            width: buttonWidth,
            height: buttonHeight,
            x: dialogWidth / 2,
            y: y + buttonHeight / 2,
            anchorX: 0.5,
            anchorY: 0.5,
            backgroundImage: btnBgSurf,
            backgroundEffector: new g.NinePatchSurfaceEffector(game, btnBgSurf.width / 2 - 1),
            parent: scene,
            touchable: true
          });
          dialogPane.append(buttonPane);
          var buttonLabel = this.buttonLabel = makeLabel({
            x: 0,
            y: (buttonHeight - titleFontSize) / 2 - 5 * ratio,
            text: "OK (15)",
            fontSize: titleFontSize,
            width: buttonWidth,
            textColor: colorBlue
          });
          buttonPane.append(buttonLabel);

          var activateButton = function activateButton() {
            buttonPane.backgroundImage = btnActiveBgSurf;
            buttonPane.invalidate();
            buttonLabel.textColor = colorWhite;
            buttonLabel.invalidate();
          };

          var deactivateButton = function deactivateButton() {
            buttonPane.backgroundImage = btnBgSurf;
            buttonPane.invalidate();
            buttonLabel.textColor = colorBlue;
            buttonLabel.invalidate();
          };

          var h = akashic_hover_plugin_1.Converter.asHoverable(buttonPane);
          var animating = false;
          h.hovered.add(function () {
            activateButton();
            if (animating) return;
            animating = true;
            animate(buttonPane, [{
              duration: 16,
              scale: [1.0, 0.9]
            }, {
              duration: 16,
              scale: [0.9, 1.1]
            }, {
              duration: 33,
              scale: [1.1, 1.0]
            }]).add(function () {
              return animating = false;
            });
          });
          h.unhovered.add(deactivateButton);
          buttonPane.onPointDown.add(activateButton);
          buttonPane.onPointUp.add(function () {
            _this.end();
          });
          if (!game.operationPluginManager.plugins[FallbackDialog.HOVER_PLUGIN_OPCODE]) game.operationPluginManager.register(HoverPlugin, FallbackDialog.HOVER_PLUGIN_OPCODE);
        }

        FallbackDialog.isSupported = function () {
          // 縦横比 0.4 について: このダイアログは 16:9 の解像度で画面高さの約 65% (468px) を占有する。
          // すなわち画面高さが画面幅の約 37% 以下の場合画面に収まらない。余裕を見て 40% を下限とする。
          // (詳細な高さは下の dialogHeight の定義を参照せよ)
          return typeof window !== "undefined" && g.game.height / g.game.width >= 0.4 && HoverPlugin.isSupported();
        };

        FallbackDialog.prototype.start = function (remainingSeconds) {
          var _this = this;

          var game = g.game;
          var scene = this.scene;

          if (game.scene() !== scene) {
            // ないはずの異常系だが一応確認
            return;
          } // エッジケース考慮: hoverプラグインは必ず停止したいので、シーンが変わった時点で止めてしまう。
          // (mouseover契機で無駄にエンティティ検索したくない)


          game.onSceneChange.add(this._disablePluginOnSceneChange, this);
          game.operationPluginManager.start(FallbackDialog.HOVER_PLUGIN_OPCODE);
          this.isHoverPluginStarted = true;
          animate(this.dialogPane, [{
            duration: 100,
            scale: [0.5, 1.1],
            opacity: [0.5, 1.0]
          }, {
            duration: 100,
            scale: [1.1, 1.0],
            opacity: [1.0, 1.0]
          }]);
          scene.append(this.bgRect);
          scene.onUpdate.add(this._assureFrontmost, this);
          this.timer = scene.setInterval(function () {
            remainingSeconds -= 1;
            _this.buttonLabel.text = "OK (" + remainingSeconds + ")";

            _this.buttonLabel.invalidate();

            if (remainingSeconds <= 0) {
              _this.end();
            }
          }, 1000);
        };

        FallbackDialog.prototype.end = function () {
          var _this = this;

          if (this.timer) {
            this.scene.clearInterval(this.timer);
            this.timer = null;
          } // 厳密には下のアニメーション終了後に解除する方がよいが、
          // 途中でシーンが破棄されるエッジケースを想定してこの時点で止める。


          this.scene.onUpdate.remove(this._assureFrontmost, this);

          if (this.isHoverPluginStarted) {
            g.game.operationPluginManager.stop(FallbackDialog.HOVER_PLUGIN_OPCODE);
            this.isHoverPluginStarted = false;
          }

          animate(this.dialogPane, [{
            duration: 100,
            opacity: [1, 0],
            scale: [1, 0.8]
          }]);
          var t = animate(this.bgRect, [{
            duration: 100,
            opacity: [1, 0]
          }]);
          t.add(function () {
            var onEnd = _this.onEnd;
            _this.onEnd = null;

            _this.bgRect.destroy();

            _this.bgRect = null;
            _this.dialogPane = null;
            _this.scene = null;
            onEnd.fire();
          });
        };

        FallbackDialog.prototype._disablePluginOnSceneChange = function (scene) {
          if (scene !== this.scene) {
            g.game.operationPluginManager.stop(FallbackDialog.HOVER_PLUGIN_OPCODE);
            return true;
          }
        }; // フレーム終了時に確実に画面最前面に持ってくる


        FallbackDialog.prototype._assureFrontmost = function () {
          g.game._pushPostTickTask(this._doAssureFrontmost, this);
        };

        FallbackDialog.prototype._doAssureFrontmost = function () {
          var scene = this.scene;
          if (scene && g.game.scene() !== scene) return;
          if (scene.children[scene.children.length - 1] === this.bgRect) return;
          this.bgRect.remove();
          scene.append(this.bgRect);
        };

        FallbackDialog.HOVER_PLUGIN_OPCODE = -1000; // TODO: 定数予約

        return FallbackDialog;
      }();

      exports.FallbackDialog = FallbackDialog;
    }, {
      "@akashic-extension/akashic-hover-plugin": 3,
      "@akashic-extension/akashic-hover-plugin/lib/HoverPlugin": 2
    }],
    17: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.resolvePlayerInfo = void 0;

      var FallbackDialog_1 = require("./FallbackDialog");

      var DEFAULT_LIMIT_SECONDS = 15; // resolvePlayerInfo関数が2重で実行されてしまうことを防ぐためのフラグ

      var isCurrentResolvingPlayerInfo = false;
      /**
       * ユーザー情報の取得と通知を行う
       * @param opts ユーザ情報取得時のオプション
       * @param callback 指定された場合、playerInfo が取得成功・失敗した時点の次の local/non-local tick で呼び出される
       */

      exports.resolvePlayerInfo = function (opts, callback) {
        if (isCurrentResolvingPlayerInfo) {
          if (callback) {
            callback(new Error("Last processing has not yet been completed."));
          }

          return;
        }

        var limitSeconds = opts && opts.limitSeconds ? opts.limitSeconds : DEFAULT_LIMIT_SECONDS;

        var cb = function cb(info) {
          if (callback) {
            callback(null, info);
          }

          if (opts && opts.raises && (!info.userData || !info.userData.unnamed)) {
            g.game.raiseEvent(new g.PlayerInfoEvent({
              id: g.game.selfId,
              name: info.name,
              userData: info.userData
            }));
          }
        };

        var rpgAtsumaru = typeof window !== "undefined" ? window.RPGAtsumaru : undefined;

        if (rpgAtsumaru && rpgAtsumaru.user && rpgAtsumaru.user.getSelfInformation) {
          isCurrentResolvingPlayerInfo = true;
          rpgAtsumaru.user.getSelfInformation().then(function (data) {
            cb({
              name: data.name,
              userData: {
                accepted: true,
                premium: data.isPremium
              }
            });
            isCurrentResolvingPlayerInfo = false;
          }).catch(function (err) {
            if (callback) {
              callback(err);
            }

            isCurrentResolvingPlayerInfo = false;
          });
        } else if (g.game.external.coeLimited && g.game.external.coeLimited.startLocalSession && g.game.external.coeLimited.exitLocalSession) {
          isCurrentResolvingPlayerInfo = true;
          var sessionId_1 = g.game.playId + "__player-info-resolver";
          var scene_1 = g.game.scene();
          var timeoutId_1 = scene_1.setTimeout(function () {
            timeoutId_1 = null; // NOTE: スキップ時は既に終了済みのローカルセッション自体が起動せず messageHandler() も呼ばれなるため、
            // ここで cb() を呼ばないとコンテンツ側がコールバックをいつまでも待ってしまう状態になってしまう

            cb({
              name: null,
              userData: {
                accepted: false,
                premium: false
              }
            }); // NOTE: リアルタイム視聴の場合、大半のケースではこちらのパスには到達しないはず (仮に到達しても同一セッションIDの COE#exitSession() が呼ばれるのみ)
            // 追っかけ再生またはタイムシフトによる視聴においては、 player-info-resolver の自発終了よりも先に以下の exitLocalSession() を呼ぶことで
            // 「スキップ中のセッション起動を抑止する」というプラットフォーム側の機能を有効にしている

            g.game.external.coeLimited.exitLocalSession(sessionId_1, {
              needsResult: true
            });
            isCurrentResolvingPlayerInfo = false;
          }, (limitSeconds + 1) * 1000); // NOTE: 読み込みなどを考慮して 1 秒のバッファを取る

          var sessionParameters = {
            type: "start",
            parameters: {
              limitSeconds: limitSeconds
            }
          };
          g.game.external.coeLimited.startLocalSession({
            sessionId: sessionId_1,
            applicationName: "player-info-resolver",
            localEvents: [[32, 0, ":akashic", sessionParameters]],
            messageHandler: function messageHandler(message) {
              // TODO 引数からエラーを取得できるようになったら、異常系の処理も行う
              if (timeoutId_1 === null) {
                return;
              }

              scene_1.clearTimeout(timeoutId_1);
              cb(message.result);
              isCurrentResolvingPlayerInfo = false;
            }
          });
        } else if (FallbackDialog_1.FallbackDialog.isSupported()) {
          var name_1 = "ゲスト" + (Math.random() * 1000 | 0);
          var dialog = new FallbackDialog_1.FallbackDialog(name_1);
          dialog.start(limitSeconds);
          dialog.onEnd.addOnce(function () {
            cb({
              name: name_1,
              userData: {
                accepted: false,
                premium: false
              }
            });
            isCurrentResolvingPlayerInfo = false;
          });
        } else {
          cb({
            name: "",
            userData: {
              accepted: false,
              premium: false,
              unnamed: true
            }
          });
        }
      };
    }, {
      "./FallbackDialog": 16
    }],
    18: [function (require, module, exports) {
      /*
      Breaks a Javascript string into individual user-perceived "characters" 
      called extended grapheme clusters by implementing the Unicode UAX-29 standard, version 10.0.0
      
      Usage:
      var splitter = new GraphemeSplitter();
      //returns an array of strings, one string for each grapheme cluster
      var graphemes = splitter.splitGraphemes(string); 
      
      */
      function GraphemeSplitter() {
        var CR = 0,
            LF = 1,
            Control = 2,
            Extend = 3,
            Regional_Indicator = 4,
            SpacingMark = 5,
            L = 6,
            V = 7,
            T = 8,
            LV = 9,
            LVT = 10,
            Other = 11,
            Prepend = 12,
            E_Base = 13,
            E_Modifier = 14,
            ZWJ = 15,
            Glue_After_Zwj = 16,
            E_Base_GAZ = 17; // BreakTypes

        var NotBreak = 0,
            BreakStart = 1,
            Break = 2,
            BreakLastRegional = 3,
            BreakPenultimateRegional = 4;

        function isSurrogate(str, pos) {
          return 0xd800 <= str.charCodeAt(pos) && str.charCodeAt(pos) <= 0xdbff && 0xdc00 <= str.charCodeAt(pos + 1) && str.charCodeAt(pos + 1) <= 0xdfff;
        } // Private function, gets a Unicode code point from a JavaScript UTF-16 string
        // handling surrogate pairs appropriately


        function codePointAt(str, idx) {
          if (idx === undefined) {
            idx = 0;
          }

          var code = str.charCodeAt(idx); // if a high surrogate

          if (0xD800 <= code && code <= 0xDBFF && idx < str.length - 1) {
            var hi = code;
            var low = str.charCodeAt(idx + 1);

            if (0xDC00 <= low && low <= 0xDFFF) {
              return (hi - 0xD800) * 0x400 + (low - 0xDC00) + 0x10000;
            }

            return hi;
          } // if a low surrogate


          if (0xDC00 <= code && code <= 0xDFFF && idx >= 1) {
            var hi = str.charCodeAt(idx - 1);
            var low = code;

            if (0xD800 <= hi && hi <= 0xDBFF) {
              return (hi - 0xD800) * 0x400 + (low - 0xDC00) + 0x10000;
            }

            return low;
          } //just return the char if an unmatched surrogate half or a 
          //single-char codepoint


          return code;
        } // Private function, returns whether a break is allowed between the 
        // two given grapheme breaking classes


        function shouldBreak(start, mid, end) {
          var all = [start].concat(mid).concat([end]);
          var previous = all[all.length - 2];
          var next = end; // Lookahead termintor for:
          // GB10. (E_Base | EBG) Extend* ?	E_Modifier

          var eModifierIndex = all.lastIndexOf(E_Modifier);

          if (eModifierIndex > 1 && all.slice(1, eModifierIndex).every(function (c) {
            return c == Extend;
          }) && [Extend, E_Base, E_Base_GAZ].indexOf(start) == -1) {
            return Break;
          } // Lookahead termintor for:
          // GB12. ^ (RI RI)* RI	?	RI
          // GB13. [^RI] (RI RI)* RI	?	RI


          var rIIndex = all.lastIndexOf(Regional_Indicator);

          if (rIIndex > 0 && all.slice(1, rIIndex).every(function (c) {
            return c == Regional_Indicator;
          }) && [Prepend, Regional_Indicator].indexOf(previous) == -1) {
            if (all.filter(function (c) {
              return c == Regional_Indicator;
            }).length % 2 == 1) {
              return BreakLastRegional;
            } else {
              return BreakPenultimateRegional;
            }
          } // GB3. CR X LF


          if (previous == CR && next == LF) {
            return NotBreak;
          } // GB4. (Control|CR|LF) ÷
          else if (previous == Control || previous == CR || previous == LF) {
              if (next == E_Modifier && mid.every(function (c) {
                return c == Extend;
              })) {
                return Break;
              } else {
                return BreakStart;
              }
            } // GB5. ÷ (Control|CR|LF)
            else if (next == Control || next == CR || next == LF) {
                return BreakStart;
              } // GB6. L X (L|V|LV|LVT)
              else if (previous == L && (next == L || next == V || next == LV || next == LVT)) {
                  return NotBreak;
                } // GB7. (LV|V) X (V|T)
                else if ((previous == LV || previous == V) && (next == V || next == T)) {
                    return NotBreak;
                  } // GB8. (LVT|T) X (T)
                  else if ((previous == LVT || previous == T) && next == T) {
                      return NotBreak;
                    } // GB9. X (Extend|ZWJ)
                    else if (next == Extend || next == ZWJ) {
                        return NotBreak;
                      } // GB9a. X SpacingMark
                      else if (next == SpacingMark) {
                          return NotBreak;
                        } // GB9b. Prepend X
                        else if (previous == Prepend) {
                            return NotBreak;
                          } // GB10. (E_Base | EBG) Extend* ?	E_Modifier


          var previousNonExtendIndex = all.indexOf(Extend) != -1 ? all.lastIndexOf(Extend) - 1 : all.length - 2;

          if ([E_Base, E_Base_GAZ].indexOf(all[previousNonExtendIndex]) != -1 && all.slice(previousNonExtendIndex + 1, -1).every(function (c) {
            return c == Extend;
          }) && next == E_Modifier) {
            return NotBreak;
          } // GB11. ZWJ ? (Glue_After_Zwj | EBG)


          if (previous == ZWJ && [Glue_After_Zwj, E_Base_GAZ].indexOf(next) != -1) {
            return NotBreak;
          } // GB12. ^ (RI RI)* RI ? RI
          // GB13. [^RI] (RI RI)* RI ? RI


          if (mid.indexOf(Regional_Indicator) != -1) {
            return Break;
          }

          if (previous == Regional_Indicator && next == Regional_Indicator) {
            return NotBreak;
          } // GB999. Any ? Any


          return BreakStart;
        } // Returns the next grapheme break in the string after the given index


        this.nextBreak = function (string, index) {
          if (index === undefined) {
            index = 0;
          }

          if (index < 0) {
            return 0;
          }

          if (index >= string.length - 1) {
            return string.length;
          }

          var prev = getGraphemeBreakProperty(codePointAt(string, index));
          var mid = [];

          for (var i = index + 1; i < string.length; i++) {
            // check for already processed low surrogates
            if (isSurrogate(string, i - 1)) {
              continue;
            }

            var next = getGraphemeBreakProperty(codePointAt(string, i));

            if (shouldBreak(prev, mid, next)) {
              return i;
            }

            mid.push(next);
          }

          return string.length;
        }; // Breaks the given string into an array of grapheme cluster strings


        this.splitGraphemes = function (str) {
          var res = [];
          var index = 0;
          var brk;

          while ((brk = this.nextBreak(str, index)) < str.length) {
            res.push(str.slice(index, brk));
            index = brk;
          }

          if (index < str.length) {
            res.push(str.slice(index));
          }

          return res;
        }; // Returns the iterator of grapheme clusters there are in the given string


        this.iterateGraphemes = function (str) {
          var index = 0;
          var res = {
            next: function () {
              var value;
              var brk;

              if ((brk = this.nextBreak(str, index)) < str.length) {
                value = str.slice(index, brk);
                index = brk;
                return {
                  value: value,
                  done: false
                };
              }

              if (index < str.length) {
                value = str.slice(index);
                index = str.length;
                return {
                  value: value,
                  done: false
                };
              }

              return {
                value: undefined,
                done: true
              };
            }.bind(this)
          }; // ES2015 @@iterator method (iterable) for spread syntax and for...of statement

          if (typeof Symbol !== 'undefined' && Symbol.iterator) {
            res[Symbol.iterator] = function () {
              return res;
            };
          }

          return res;
        }; // Returns the number of grapheme clusters there are in the given string


        this.countGraphemes = function (str) {
          var count = 0;
          var index = 0;
          var brk;

          while ((brk = this.nextBreak(str, index)) < str.length) {
            index = brk;
            count++;
          }

          if (index < str.length) {
            count++;
          }

          return count;
        }; //given a Unicode code point, determines this symbol's grapheme break property


        function getGraphemeBreakProperty(code) {
          //grapheme break property for Unicode 10.0.0, 
          //taken from http://www.unicode.org/Public/10.0.0/ucd/auxiliary/GraphemeBreakProperty.txt
          //and adapted to JavaScript rules
          if (0x0600 <= code && code <= 0x0605 || // Cf   [6] ARABIC NUMBER SIGN..ARABIC NUMBER MARK ABOVE
          0x06DD == code || // Cf       ARABIC END OF AYAH
          0x070F == code || // Cf       SYRIAC ABBREVIATION MARK
          0x08E2 == code || // Cf       ARABIC DISPUTED END OF AYAH
          0x0D4E == code || // Lo       MALAYALAM LETTER DOT REPH
          0x110BD == code || // Cf       KAITHI NUMBER SIGN
          0x111C2 <= code && code <= 0x111C3 || // Lo   [2] SHARADA SIGN JIHVAMULIYA..SHARADA SIGN UPADHMANIYA
          0x11A3A == code || // Lo       ZANABAZAR SQUARE CLUSTER-INITIAL LETTER RA
          0x11A86 <= code && code <= 0x11A89 || // Lo   [4] SOYOMBO CLUSTER-INITIAL LETTER RA..SOYOMBO CLUSTER-INITIAL LETTER SA
          0x11D46 == code // Lo       MASARAM GONDI REPHA
          ) {
              return Prepend;
            }

          if (0x000D == code // Cc       <control-000D>
          ) {
              return CR;
            }

          if (0x000A == code // Cc       <control-000A>
          ) {
              return LF;
            }

          if (0x0000 <= code && code <= 0x0009 || // Cc  [10] <control-0000>..<control-0009>
          0x000B <= code && code <= 0x000C || // Cc   [2] <control-000B>..<control-000C>
          0x000E <= code && code <= 0x001F || // Cc  [18] <control-000E>..<control-001F>
          0x007F <= code && code <= 0x009F || // Cc  [33] <control-007F>..<control-009F>
          0x00AD == code || // Cf       SOFT HYPHEN
          0x061C == code || // Cf       ARABIC LETTER MARK
          0x180E == code || // Cf       MONGOLIAN VOWEL SEPARATOR
          0x200B == code || // Cf       ZERO WIDTH SPACE
          0x200E <= code && code <= 0x200F || // Cf   [2] LEFT-TO-RIGHT MARK..RIGHT-TO-LEFT MARK
          0x2028 == code || // Zl       LINE SEPARATOR
          0x2029 == code || // Zp       PARAGRAPH SEPARATOR
          0x202A <= code && code <= 0x202E || // Cf   [5] LEFT-TO-RIGHT EMBEDDING..RIGHT-TO-LEFT OVERRIDE
          0x2060 <= code && code <= 0x2064 || // Cf   [5] WORD JOINER..INVISIBLE PLUS
          0x2065 == code || // Cn       <reserved-2065>
          0x2066 <= code && code <= 0x206F || // Cf  [10] LEFT-TO-RIGHT ISOLATE..NOMINAL DIGIT SHAPES
          0xD800 <= code && code <= 0xDFFF || // Cs [2048] <surrogate-D800>..<surrogate-DFFF>
          0xFEFF == code || // Cf       ZERO WIDTH NO-BREAK SPACE
          0xFFF0 <= code && code <= 0xFFF8 || // Cn   [9] <reserved-FFF0>..<reserved-FFF8>
          0xFFF9 <= code && code <= 0xFFFB || // Cf   [3] INTERLINEAR ANNOTATION ANCHOR..INTERLINEAR ANNOTATION TERMINATOR
          0x1BCA0 <= code && code <= 0x1BCA3 || // Cf   [4] SHORTHAND FORMAT LETTER OVERLAP..SHORTHAND FORMAT UP STEP
          0x1D173 <= code && code <= 0x1D17A || // Cf   [8] MUSICAL SYMBOL BEGIN BEAM..MUSICAL SYMBOL END PHRASE
          0xE0000 == code || // Cn       <reserved-E0000>
          0xE0001 == code || // Cf       LANGUAGE TAG
          0xE0002 <= code && code <= 0xE001F || // Cn  [30] <reserved-E0002>..<reserved-E001F>
          0xE0080 <= code && code <= 0xE00FF || // Cn [128] <reserved-E0080>..<reserved-E00FF>
          0xE01F0 <= code && code <= 0xE0FFF // Cn [3600] <reserved-E01F0>..<reserved-E0FFF>
          ) {
              return Control;
            }

          if (0x0300 <= code && code <= 0x036F || // Mn [112] COMBINING GRAVE ACCENT..COMBINING LATIN SMALL LETTER X
          0x0483 <= code && code <= 0x0487 || // Mn   [5] COMBINING CYRILLIC TITLO..COMBINING CYRILLIC POKRYTIE
          0x0488 <= code && code <= 0x0489 || // Me   [2] COMBINING CYRILLIC HUNDRED THOUSANDS SIGN..COMBINING CYRILLIC MILLIONS SIGN
          0x0591 <= code && code <= 0x05BD || // Mn  [45] HEBREW ACCENT ETNAHTA..HEBREW POINT METEG
          0x05BF == code || // Mn       HEBREW POINT RAFE
          0x05C1 <= code && code <= 0x05C2 || // Mn   [2] HEBREW POINT SHIN DOT..HEBREW POINT SIN DOT
          0x05C4 <= code && code <= 0x05C5 || // Mn   [2] HEBREW MARK UPPER DOT..HEBREW MARK LOWER DOT
          0x05C7 == code || // Mn       HEBREW POINT QAMATS QATAN
          0x0610 <= code && code <= 0x061A || // Mn  [11] ARABIC SIGN SALLALLAHOU ALAYHE WASSALLAM..ARABIC SMALL KASRA
          0x064B <= code && code <= 0x065F || // Mn  [21] ARABIC FATHATAN..ARABIC WAVY HAMZA BELOW
          0x0670 == code || // Mn       ARABIC LETTER SUPERSCRIPT ALEF
          0x06D6 <= code && code <= 0x06DC || // Mn   [7] ARABIC SMALL HIGH LIGATURE SAD WITH LAM WITH ALEF MAKSURA..ARABIC SMALL HIGH SEEN
          0x06DF <= code && code <= 0x06E4 || // Mn   [6] ARABIC SMALL HIGH ROUNDED ZERO..ARABIC SMALL HIGH MADDA
          0x06E7 <= code && code <= 0x06E8 || // Mn   [2] ARABIC SMALL HIGH YEH..ARABIC SMALL HIGH NOON
          0x06EA <= code && code <= 0x06ED || // Mn   [4] ARABIC EMPTY CENTRE LOW STOP..ARABIC SMALL LOW MEEM
          0x0711 == code || // Mn       SYRIAC LETTER SUPERSCRIPT ALAPH
          0x0730 <= code && code <= 0x074A || // Mn  [27] SYRIAC PTHAHA ABOVE..SYRIAC BARREKH
          0x07A6 <= code && code <= 0x07B0 || // Mn  [11] THAANA ABAFILI..THAANA SUKUN
          0x07EB <= code && code <= 0x07F3 || // Mn   [9] NKO COMBINING SHORT HIGH TONE..NKO COMBINING DOUBLE DOT ABOVE
          0x0816 <= code && code <= 0x0819 || // Mn   [4] SAMARITAN MARK IN..SAMARITAN MARK DAGESH
          0x081B <= code && code <= 0x0823 || // Mn   [9] SAMARITAN MARK EPENTHETIC YUT..SAMARITAN VOWEL SIGN A
          0x0825 <= code && code <= 0x0827 || // Mn   [3] SAMARITAN VOWEL SIGN SHORT A..SAMARITAN VOWEL SIGN U
          0x0829 <= code && code <= 0x082D || // Mn   [5] SAMARITAN VOWEL SIGN LONG I..SAMARITAN MARK NEQUDAA
          0x0859 <= code && code <= 0x085B || // Mn   [3] MANDAIC AFFRICATION MARK..MANDAIC GEMINATION MARK
          0x08D4 <= code && code <= 0x08E1 || // Mn  [14] ARABIC SMALL HIGH WORD AR-RUB..ARABIC SMALL HIGH SIGN SAFHA
          0x08E3 <= code && code <= 0x0902 || // Mn  [32] ARABIC TURNED DAMMA BELOW..DEVANAGARI SIGN ANUSVARA
          0x093A == code || // Mn       DEVANAGARI VOWEL SIGN OE
          0x093C == code || // Mn       DEVANAGARI SIGN NUKTA
          0x0941 <= code && code <= 0x0948 || // Mn   [8] DEVANAGARI VOWEL SIGN U..DEVANAGARI VOWEL SIGN AI
          0x094D == code || // Mn       DEVANAGARI SIGN VIRAMA
          0x0951 <= code && code <= 0x0957 || // Mn   [7] DEVANAGARI STRESS SIGN UDATTA..DEVANAGARI VOWEL SIGN UUE
          0x0962 <= code && code <= 0x0963 || // Mn   [2] DEVANAGARI VOWEL SIGN VOCALIC L..DEVANAGARI VOWEL SIGN VOCALIC LL
          0x0981 == code || // Mn       BENGALI SIGN CANDRABINDU
          0x09BC == code || // Mn       BENGALI SIGN NUKTA
          0x09BE == code || // Mc       BENGALI VOWEL SIGN AA
          0x09C1 <= code && code <= 0x09C4 || // Mn   [4] BENGALI VOWEL SIGN U..BENGALI VOWEL SIGN VOCALIC RR
          0x09CD == code || // Mn       BENGALI SIGN VIRAMA
          0x09D7 == code || // Mc       BENGALI AU LENGTH MARK
          0x09E2 <= code && code <= 0x09E3 || // Mn   [2] BENGALI VOWEL SIGN VOCALIC L..BENGALI VOWEL SIGN VOCALIC LL
          0x0A01 <= code && code <= 0x0A02 || // Mn   [2] GURMUKHI SIGN ADAK BINDI..GURMUKHI SIGN BINDI
          0x0A3C == code || // Mn       GURMUKHI SIGN NUKTA
          0x0A41 <= code && code <= 0x0A42 || // Mn   [2] GURMUKHI VOWEL SIGN U..GURMUKHI VOWEL SIGN UU
          0x0A47 <= code && code <= 0x0A48 || // Mn   [2] GURMUKHI VOWEL SIGN EE..GURMUKHI VOWEL SIGN AI
          0x0A4B <= code && code <= 0x0A4D || // Mn   [3] GURMUKHI VOWEL SIGN OO..GURMUKHI SIGN VIRAMA
          0x0A51 == code || // Mn       GURMUKHI SIGN UDAAT
          0x0A70 <= code && code <= 0x0A71 || // Mn   [2] GURMUKHI TIPPI..GURMUKHI ADDAK
          0x0A75 == code || // Mn       GURMUKHI SIGN YAKASH
          0x0A81 <= code && code <= 0x0A82 || // Mn   [2] GUJARATI SIGN CANDRABINDU..GUJARATI SIGN ANUSVARA
          0x0ABC == code || // Mn       GUJARATI SIGN NUKTA
          0x0AC1 <= code && code <= 0x0AC5 || // Mn   [5] GUJARATI VOWEL SIGN U..GUJARATI VOWEL SIGN CANDRA E
          0x0AC7 <= code && code <= 0x0AC8 || // Mn   [2] GUJARATI VOWEL SIGN E..GUJARATI VOWEL SIGN AI
          0x0ACD == code || // Mn       GUJARATI SIGN VIRAMA
          0x0AE2 <= code && code <= 0x0AE3 || // Mn   [2] GUJARATI VOWEL SIGN VOCALIC L..GUJARATI VOWEL SIGN VOCALIC LL
          0x0AFA <= code && code <= 0x0AFF || // Mn   [6] GUJARATI SIGN SUKUN..GUJARATI SIGN TWO-CIRCLE NUKTA ABOVE
          0x0B01 == code || // Mn       ORIYA SIGN CANDRABINDU
          0x0B3C == code || // Mn       ORIYA SIGN NUKTA
          0x0B3E == code || // Mc       ORIYA VOWEL SIGN AA
          0x0B3F == code || // Mn       ORIYA VOWEL SIGN I
          0x0B41 <= code && code <= 0x0B44 || // Mn   [4] ORIYA VOWEL SIGN U..ORIYA VOWEL SIGN VOCALIC RR
          0x0B4D == code || // Mn       ORIYA SIGN VIRAMA
          0x0B56 == code || // Mn       ORIYA AI LENGTH MARK
          0x0B57 == code || // Mc       ORIYA AU LENGTH MARK
          0x0B62 <= code && code <= 0x0B63 || // Mn   [2] ORIYA VOWEL SIGN VOCALIC L..ORIYA VOWEL SIGN VOCALIC LL
          0x0B82 == code || // Mn       TAMIL SIGN ANUSVARA
          0x0BBE == code || // Mc       TAMIL VOWEL SIGN AA
          0x0BC0 == code || // Mn       TAMIL VOWEL SIGN II
          0x0BCD == code || // Mn       TAMIL SIGN VIRAMA
          0x0BD7 == code || // Mc       TAMIL AU LENGTH MARK
          0x0C00 == code || // Mn       TELUGU SIGN COMBINING CANDRABINDU ABOVE
          0x0C3E <= code && code <= 0x0C40 || // Mn   [3] TELUGU VOWEL SIGN AA..TELUGU VOWEL SIGN II
          0x0C46 <= code && code <= 0x0C48 || // Mn   [3] TELUGU VOWEL SIGN E..TELUGU VOWEL SIGN AI
          0x0C4A <= code && code <= 0x0C4D || // Mn   [4] TELUGU VOWEL SIGN O..TELUGU SIGN VIRAMA
          0x0C55 <= code && code <= 0x0C56 || // Mn   [2] TELUGU LENGTH MARK..TELUGU AI LENGTH MARK
          0x0C62 <= code && code <= 0x0C63 || // Mn   [2] TELUGU VOWEL SIGN VOCALIC L..TELUGU VOWEL SIGN VOCALIC LL
          0x0C81 == code || // Mn       KANNADA SIGN CANDRABINDU
          0x0CBC == code || // Mn       KANNADA SIGN NUKTA
          0x0CBF == code || // Mn       KANNADA VOWEL SIGN I
          0x0CC2 == code || // Mc       KANNADA VOWEL SIGN UU
          0x0CC6 == code || // Mn       KANNADA VOWEL SIGN E
          0x0CCC <= code && code <= 0x0CCD || // Mn   [2] KANNADA VOWEL SIGN AU..KANNADA SIGN VIRAMA
          0x0CD5 <= code && code <= 0x0CD6 || // Mc   [2] KANNADA LENGTH MARK..KANNADA AI LENGTH MARK
          0x0CE2 <= code && code <= 0x0CE3 || // Mn   [2] KANNADA VOWEL SIGN VOCALIC L..KANNADA VOWEL SIGN VOCALIC LL
          0x0D00 <= code && code <= 0x0D01 || // Mn   [2] MALAYALAM SIGN COMBINING ANUSVARA ABOVE..MALAYALAM SIGN CANDRABINDU
          0x0D3B <= code && code <= 0x0D3C || // Mn   [2] MALAYALAM SIGN VERTICAL BAR VIRAMA..MALAYALAM SIGN CIRCULAR VIRAMA
          0x0D3E == code || // Mc       MALAYALAM VOWEL SIGN AA
          0x0D41 <= code && code <= 0x0D44 || // Mn   [4] MALAYALAM VOWEL SIGN U..MALAYALAM VOWEL SIGN VOCALIC RR
          0x0D4D == code || // Mn       MALAYALAM SIGN VIRAMA
          0x0D57 == code || // Mc       MALAYALAM AU LENGTH MARK
          0x0D62 <= code && code <= 0x0D63 || // Mn   [2] MALAYALAM VOWEL SIGN VOCALIC L..MALAYALAM VOWEL SIGN VOCALIC LL
          0x0DCA == code || // Mn       SINHALA SIGN AL-LAKUNA
          0x0DCF == code || // Mc       SINHALA VOWEL SIGN AELA-PILLA
          0x0DD2 <= code && code <= 0x0DD4 || // Mn   [3] SINHALA VOWEL SIGN KETTI IS-PILLA..SINHALA VOWEL SIGN KETTI PAA-PILLA
          0x0DD6 == code || // Mn       SINHALA VOWEL SIGN DIGA PAA-PILLA
          0x0DDF == code || // Mc       SINHALA VOWEL SIGN GAYANUKITTA
          0x0E31 == code || // Mn       THAI CHARACTER MAI HAN-AKAT
          0x0E34 <= code && code <= 0x0E3A || // Mn   [7] THAI CHARACTER SARA I..THAI CHARACTER PHINTHU
          0x0E47 <= code && code <= 0x0E4E || // Mn   [8] THAI CHARACTER MAITAIKHU..THAI CHARACTER YAMAKKAN
          0x0EB1 == code || // Mn       LAO VOWEL SIGN MAI KAN
          0x0EB4 <= code && code <= 0x0EB9 || // Mn   [6] LAO VOWEL SIGN I..LAO VOWEL SIGN UU
          0x0EBB <= code && code <= 0x0EBC || // Mn   [2] LAO VOWEL SIGN MAI KON..LAO SEMIVOWEL SIGN LO
          0x0EC8 <= code && code <= 0x0ECD || // Mn   [6] LAO TONE MAI EK..LAO NIGGAHITA
          0x0F18 <= code && code <= 0x0F19 || // Mn   [2] TIBETAN ASTROLOGICAL SIGN -KHYUD PA..TIBETAN ASTROLOGICAL SIGN SDONG TSHUGS
          0x0F35 == code || // Mn       TIBETAN MARK NGAS BZUNG NYI ZLA
          0x0F37 == code || // Mn       TIBETAN MARK NGAS BZUNG SGOR RTAGS
          0x0F39 == code || // Mn       TIBETAN MARK TSA -PHRU
          0x0F71 <= code && code <= 0x0F7E || // Mn  [14] TIBETAN VOWEL SIGN AA..TIBETAN SIGN RJES SU NGA RO
          0x0F80 <= code && code <= 0x0F84 || // Mn   [5] TIBETAN VOWEL SIGN REVERSED I..TIBETAN MARK HALANTA
          0x0F86 <= code && code <= 0x0F87 || // Mn   [2] TIBETAN SIGN LCI RTAGS..TIBETAN SIGN YANG RTAGS
          0x0F8D <= code && code <= 0x0F97 || // Mn  [11] TIBETAN SUBJOINED SIGN LCE TSA CAN..TIBETAN SUBJOINED LETTER JA
          0x0F99 <= code && code <= 0x0FBC || // Mn  [36] TIBETAN SUBJOINED LETTER NYA..TIBETAN SUBJOINED LETTER FIXED-FORM RA
          0x0FC6 == code || // Mn       TIBETAN SYMBOL PADMA GDAN
          0x102D <= code && code <= 0x1030 || // Mn   [4] MYANMAR VOWEL SIGN I..MYANMAR VOWEL SIGN UU
          0x1032 <= code && code <= 0x1037 || // Mn   [6] MYANMAR VOWEL SIGN AI..MYANMAR SIGN DOT BELOW
          0x1039 <= code && code <= 0x103A || // Mn   [2] MYANMAR SIGN VIRAMA..MYANMAR SIGN ASAT
          0x103D <= code && code <= 0x103E || // Mn   [2] MYANMAR CONSONANT SIGN MEDIAL WA..MYANMAR CONSONANT SIGN MEDIAL HA
          0x1058 <= code && code <= 0x1059 || // Mn   [2] MYANMAR VOWEL SIGN VOCALIC L..MYANMAR VOWEL SIGN VOCALIC LL
          0x105E <= code && code <= 0x1060 || // Mn   [3] MYANMAR CONSONANT SIGN MON MEDIAL NA..MYANMAR CONSONANT SIGN MON MEDIAL LA
          0x1071 <= code && code <= 0x1074 || // Mn   [4] MYANMAR VOWEL SIGN GEBA KAREN I..MYANMAR VOWEL SIGN KAYAH EE
          0x1082 == code || // Mn       MYANMAR CONSONANT SIGN SHAN MEDIAL WA
          0x1085 <= code && code <= 0x1086 || // Mn   [2] MYANMAR VOWEL SIGN SHAN E ABOVE..MYANMAR VOWEL SIGN SHAN FINAL Y
          0x108D == code || // Mn       MYANMAR SIGN SHAN COUNCIL EMPHATIC TONE
          0x109D == code || // Mn       MYANMAR VOWEL SIGN AITON AI
          0x135D <= code && code <= 0x135F || // Mn   [3] ETHIOPIC COMBINING GEMINATION AND VOWEL LENGTH MARK..ETHIOPIC COMBINING GEMINATION MARK
          0x1712 <= code && code <= 0x1714 || // Mn   [3] TAGALOG VOWEL SIGN I..TAGALOG SIGN VIRAMA
          0x1732 <= code && code <= 0x1734 || // Mn   [3] HANUNOO VOWEL SIGN I..HANUNOO SIGN PAMUDPOD
          0x1752 <= code && code <= 0x1753 || // Mn   [2] BUHID VOWEL SIGN I..BUHID VOWEL SIGN U
          0x1772 <= code && code <= 0x1773 || // Mn   [2] TAGBANWA VOWEL SIGN I..TAGBANWA VOWEL SIGN U
          0x17B4 <= code && code <= 0x17B5 || // Mn   [2] KHMER VOWEL INHERENT AQ..KHMER VOWEL INHERENT AA
          0x17B7 <= code && code <= 0x17BD || // Mn   [7] KHMER VOWEL SIGN I..KHMER VOWEL SIGN UA
          0x17C6 == code || // Mn       KHMER SIGN NIKAHIT
          0x17C9 <= code && code <= 0x17D3 || // Mn  [11] KHMER SIGN MUUSIKATOAN..KHMER SIGN BATHAMASAT
          0x17DD == code || // Mn       KHMER SIGN ATTHACAN
          0x180B <= code && code <= 0x180D || // Mn   [3] MONGOLIAN FREE VARIATION SELECTOR ONE..MONGOLIAN FREE VARIATION SELECTOR THREE
          0x1885 <= code && code <= 0x1886 || // Mn   [2] MONGOLIAN LETTER ALI GALI BALUDA..MONGOLIAN LETTER ALI GALI THREE BALUDA
          0x18A9 == code || // Mn       MONGOLIAN LETTER ALI GALI DAGALGA
          0x1920 <= code && code <= 0x1922 || // Mn   [3] LIMBU VOWEL SIGN A..LIMBU VOWEL SIGN U
          0x1927 <= code && code <= 0x1928 || // Mn   [2] LIMBU VOWEL SIGN E..LIMBU VOWEL SIGN O
          0x1932 == code || // Mn       LIMBU SMALL LETTER ANUSVARA
          0x1939 <= code && code <= 0x193B || // Mn   [3] LIMBU SIGN MUKPHRENG..LIMBU SIGN SA-I
          0x1A17 <= code && code <= 0x1A18 || // Mn   [2] BUGINESE VOWEL SIGN I..BUGINESE VOWEL SIGN U
          0x1A1B == code || // Mn       BUGINESE VOWEL SIGN AE
          0x1A56 == code || // Mn       TAI THAM CONSONANT SIGN MEDIAL LA
          0x1A58 <= code && code <= 0x1A5E || // Mn   [7] TAI THAM SIGN MAI KANG LAI..TAI THAM CONSONANT SIGN SA
          0x1A60 == code || // Mn       TAI THAM SIGN SAKOT
          0x1A62 == code || // Mn       TAI THAM VOWEL SIGN MAI SAT
          0x1A65 <= code && code <= 0x1A6C || // Mn   [8] TAI THAM VOWEL SIGN I..TAI THAM VOWEL SIGN OA BELOW
          0x1A73 <= code && code <= 0x1A7C || // Mn  [10] TAI THAM VOWEL SIGN OA ABOVE..TAI THAM SIGN KHUEN-LUE KARAN
          0x1A7F == code || // Mn       TAI THAM COMBINING CRYPTOGRAMMIC DOT
          0x1AB0 <= code && code <= 0x1ABD || // Mn  [14] COMBINING DOUBLED CIRCUMFLEX ACCENT..COMBINING PARENTHESES BELOW
          0x1ABE == code || // Me       COMBINING PARENTHESES OVERLAY
          0x1B00 <= code && code <= 0x1B03 || // Mn   [4] BALINESE SIGN ULU RICEM..BALINESE SIGN SURANG
          0x1B34 == code || // Mn       BALINESE SIGN REREKAN
          0x1B36 <= code && code <= 0x1B3A || // Mn   [5] BALINESE VOWEL SIGN ULU..BALINESE VOWEL SIGN RA REPA
          0x1B3C == code || // Mn       BALINESE VOWEL SIGN LA LENGA
          0x1B42 == code || // Mn       BALINESE VOWEL SIGN PEPET
          0x1B6B <= code && code <= 0x1B73 || // Mn   [9] BALINESE MUSICAL SYMBOL COMBINING TEGEH..BALINESE MUSICAL SYMBOL COMBINING GONG
          0x1B80 <= code && code <= 0x1B81 || // Mn   [2] SUNDANESE SIGN PANYECEK..SUNDANESE SIGN PANGLAYAR
          0x1BA2 <= code && code <= 0x1BA5 || // Mn   [4] SUNDANESE CONSONANT SIGN PANYAKRA..SUNDANESE VOWEL SIGN PANYUKU
          0x1BA8 <= code && code <= 0x1BA9 || // Mn   [2] SUNDANESE VOWEL SIGN PAMEPET..SUNDANESE VOWEL SIGN PANEULEUNG
          0x1BAB <= code && code <= 0x1BAD || // Mn   [3] SUNDANESE SIGN VIRAMA..SUNDANESE CONSONANT SIGN PASANGAN WA
          0x1BE6 == code || // Mn       BATAK SIGN TOMPI
          0x1BE8 <= code && code <= 0x1BE9 || // Mn   [2] BATAK VOWEL SIGN PAKPAK E..BATAK VOWEL SIGN EE
          0x1BED == code || // Mn       BATAK VOWEL SIGN KARO O
          0x1BEF <= code && code <= 0x1BF1 || // Mn   [3] BATAK VOWEL SIGN U FOR SIMALUNGUN SA..BATAK CONSONANT SIGN H
          0x1C2C <= code && code <= 0x1C33 || // Mn   [8] LEPCHA VOWEL SIGN E..LEPCHA CONSONANT SIGN T
          0x1C36 <= code && code <= 0x1C37 || // Mn   [2] LEPCHA SIGN RAN..LEPCHA SIGN NUKTA
          0x1CD0 <= code && code <= 0x1CD2 || // Mn   [3] VEDIC TONE KARSHANA..VEDIC TONE PRENKHA
          0x1CD4 <= code && code <= 0x1CE0 || // Mn  [13] VEDIC SIGN YAJURVEDIC MIDLINE SVARITA..VEDIC TONE RIGVEDIC KASHMIRI INDEPENDENT SVARITA
          0x1CE2 <= code && code <= 0x1CE8 || // Mn   [7] VEDIC SIGN VISARGA SVARITA..VEDIC SIGN VISARGA ANUDATTA WITH TAIL
          0x1CED == code || // Mn       VEDIC SIGN TIRYAK
          0x1CF4 == code || // Mn       VEDIC TONE CANDRA ABOVE
          0x1CF8 <= code && code <= 0x1CF9 || // Mn   [2] VEDIC TONE RING ABOVE..VEDIC TONE DOUBLE RING ABOVE
          0x1DC0 <= code && code <= 0x1DF9 || // Mn  [58] COMBINING DOTTED GRAVE ACCENT..COMBINING WIDE INVERTED BRIDGE BELOW
          0x1DFB <= code && code <= 0x1DFF || // Mn   [5] COMBINING DELETION MARK..COMBINING RIGHT ARROWHEAD AND DOWN ARROWHEAD BELOW
          0x200C == code || // Cf       ZERO WIDTH NON-JOINER
          0x20D0 <= code && code <= 0x20DC || // Mn  [13] COMBINING LEFT HARPOON ABOVE..COMBINING FOUR DOTS ABOVE
          0x20DD <= code && code <= 0x20E0 || // Me   [4] COMBINING ENCLOSING CIRCLE..COMBINING ENCLOSING CIRCLE BACKSLASH
          0x20E1 == code || // Mn       COMBINING LEFT RIGHT ARROW ABOVE
          0x20E2 <= code && code <= 0x20E4 || // Me   [3] COMBINING ENCLOSING SCREEN..COMBINING ENCLOSING UPWARD POINTING TRIANGLE
          0x20E5 <= code && code <= 0x20F0 || // Mn  [12] COMBINING REVERSE SOLIDUS OVERLAY..COMBINING ASTERISK ABOVE
          0x2CEF <= code && code <= 0x2CF1 || // Mn   [3] COPTIC COMBINING NI ABOVE..COPTIC COMBINING SPIRITUS LENIS
          0x2D7F == code || // Mn       TIFINAGH CONSONANT JOINER
          0x2DE0 <= code && code <= 0x2DFF || // Mn  [32] COMBINING CYRILLIC LETTER BE..COMBINING CYRILLIC LETTER IOTIFIED BIG YUS
          0x302A <= code && code <= 0x302D || // Mn   [4] IDEOGRAPHIC LEVEL TONE MARK..IDEOGRAPHIC ENTERING TONE MARK
          0x302E <= code && code <= 0x302F || // Mc   [2] HANGUL SINGLE DOT TONE MARK..HANGUL DOUBLE DOT TONE MARK
          0x3099 <= code && code <= 0x309A || // Mn   [2] COMBINING KATAKANA-HIRAGANA VOICED SOUND MARK..COMBINING KATAKANA-HIRAGANA SEMI-VOICED SOUND MARK
          0xA66F == code || // Mn       COMBINING CYRILLIC VZMET
          0xA670 <= code && code <= 0xA672 || // Me   [3] COMBINING CYRILLIC TEN MILLIONS SIGN..COMBINING CYRILLIC THOUSAND MILLIONS SIGN
          0xA674 <= code && code <= 0xA67D || // Mn  [10] COMBINING CYRILLIC LETTER UKRAINIAN IE..COMBINING CYRILLIC PAYEROK
          0xA69E <= code && code <= 0xA69F || // Mn   [2] COMBINING CYRILLIC LETTER EF..COMBINING CYRILLIC LETTER IOTIFIED E
          0xA6F0 <= code && code <= 0xA6F1 || // Mn   [2] BAMUM COMBINING MARK KOQNDON..BAMUM COMBINING MARK TUKWENTIS
          0xA802 == code || // Mn       SYLOTI NAGRI SIGN DVISVARA
          0xA806 == code || // Mn       SYLOTI NAGRI SIGN HASANTA
          0xA80B == code || // Mn       SYLOTI NAGRI SIGN ANUSVARA
          0xA825 <= code && code <= 0xA826 || // Mn   [2] SYLOTI NAGRI VOWEL SIGN U..SYLOTI NAGRI VOWEL SIGN E
          0xA8C4 <= code && code <= 0xA8C5 || // Mn   [2] SAURASHTRA SIGN VIRAMA..SAURASHTRA SIGN CANDRABINDU
          0xA8E0 <= code && code <= 0xA8F1 || // Mn  [18] COMBINING DEVANAGARI DIGIT ZERO..COMBINING DEVANAGARI SIGN AVAGRAHA
          0xA926 <= code && code <= 0xA92D || // Mn   [8] KAYAH LI VOWEL UE..KAYAH LI TONE CALYA PLOPHU
          0xA947 <= code && code <= 0xA951 || // Mn  [11] REJANG VOWEL SIGN I..REJANG CONSONANT SIGN R
          0xA980 <= code && code <= 0xA982 || // Mn   [3] JAVANESE SIGN PANYANGGA..JAVANESE SIGN LAYAR
          0xA9B3 == code || // Mn       JAVANESE SIGN CECAK TELU
          0xA9B6 <= code && code <= 0xA9B9 || // Mn   [4] JAVANESE VOWEL SIGN WULU..JAVANESE VOWEL SIGN SUKU MENDUT
          0xA9BC == code || // Mn       JAVANESE VOWEL SIGN PEPET
          0xA9E5 == code || // Mn       MYANMAR SIGN SHAN SAW
          0xAA29 <= code && code <= 0xAA2E || // Mn   [6] CHAM VOWEL SIGN AA..CHAM VOWEL SIGN OE
          0xAA31 <= code && code <= 0xAA32 || // Mn   [2] CHAM VOWEL SIGN AU..CHAM VOWEL SIGN UE
          0xAA35 <= code && code <= 0xAA36 || // Mn   [2] CHAM CONSONANT SIGN LA..CHAM CONSONANT SIGN WA
          0xAA43 == code || // Mn       CHAM CONSONANT SIGN FINAL NG
          0xAA4C == code || // Mn       CHAM CONSONANT SIGN FINAL M
          0xAA7C == code || // Mn       MYANMAR SIGN TAI LAING TONE-2
          0xAAB0 == code || // Mn       TAI VIET MAI KANG
          0xAAB2 <= code && code <= 0xAAB4 || // Mn   [3] TAI VIET VOWEL I..TAI VIET VOWEL U
          0xAAB7 <= code && code <= 0xAAB8 || // Mn   [2] TAI VIET MAI KHIT..TAI VIET VOWEL IA
          0xAABE <= code && code <= 0xAABF || // Mn   [2] TAI VIET VOWEL AM..TAI VIET TONE MAI EK
          0xAAC1 == code || // Mn       TAI VIET TONE MAI THO
          0xAAEC <= code && code <= 0xAAED || // Mn   [2] MEETEI MAYEK VOWEL SIGN UU..MEETEI MAYEK VOWEL SIGN AAI
          0xAAF6 == code || // Mn       MEETEI MAYEK VIRAMA
          0xABE5 == code || // Mn       MEETEI MAYEK VOWEL SIGN ANAP
          0xABE8 == code || // Mn       MEETEI MAYEK VOWEL SIGN UNAP
          0xABED == code || // Mn       MEETEI MAYEK APUN IYEK
          0xFB1E == code || // Mn       HEBREW POINT JUDEO-SPANISH VARIKA
          0xFE00 <= code && code <= 0xFE0F || // Mn  [16] VARIATION SELECTOR-1..VARIATION SELECTOR-16
          0xFE20 <= code && code <= 0xFE2F || // Mn  [16] COMBINING LIGATURE LEFT HALF..COMBINING CYRILLIC TITLO RIGHT HALF
          0xFF9E <= code && code <= 0xFF9F || // Lm   [2] HALFWIDTH KATAKANA VOICED SOUND MARK..HALFWIDTH KATAKANA SEMI-VOICED SOUND MARK
          0x101FD == code || // Mn       PHAISTOS DISC SIGN COMBINING OBLIQUE STROKE
          0x102E0 == code || // Mn       COPTIC EPACT THOUSANDS MARK
          0x10376 <= code && code <= 0x1037A || // Mn   [5] COMBINING OLD PERMIC LETTER AN..COMBINING OLD PERMIC LETTER SII
          0x10A01 <= code && code <= 0x10A03 || // Mn   [3] KHAROSHTHI VOWEL SIGN I..KHAROSHTHI VOWEL SIGN VOCALIC R
          0x10A05 <= code && code <= 0x10A06 || // Mn   [2] KHAROSHTHI VOWEL SIGN E..KHAROSHTHI VOWEL SIGN O
          0x10A0C <= code && code <= 0x10A0F || // Mn   [4] KHAROSHTHI VOWEL LENGTH MARK..KHAROSHTHI SIGN VISARGA
          0x10A38 <= code && code <= 0x10A3A || // Mn   [3] KHAROSHTHI SIGN BAR ABOVE..KHAROSHTHI SIGN DOT BELOW
          0x10A3F == code || // Mn       KHAROSHTHI VIRAMA
          0x10AE5 <= code && code <= 0x10AE6 || // Mn   [2] MANICHAEAN ABBREVIATION MARK ABOVE..MANICHAEAN ABBREVIATION MARK BELOW
          0x11001 == code || // Mn       BRAHMI SIGN ANUSVARA
          0x11038 <= code && code <= 0x11046 || // Mn  [15] BRAHMI VOWEL SIGN AA..BRAHMI VIRAMA
          0x1107F <= code && code <= 0x11081 || // Mn   [3] BRAHMI NUMBER JOINER..KAITHI SIGN ANUSVARA
          0x110B3 <= code && code <= 0x110B6 || // Mn   [4] KAITHI VOWEL SIGN U..KAITHI VOWEL SIGN AI
          0x110B9 <= code && code <= 0x110BA || // Mn   [2] KAITHI SIGN VIRAMA..KAITHI SIGN NUKTA
          0x11100 <= code && code <= 0x11102 || // Mn   [3] CHAKMA SIGN CANDRABINDU..CHAKMA SIGN VISARGA
          0x11127 <= code && code <= 0x1112B || // Mn   [5] CHAKMA VOWEL SIGN A..CHAKMA VOWEL SIGN UU
          0x1112D <= code && code <= 0x11134 || // Mn   [8] CHAKMA VOWEL SIGN AI..CHAKMA MAAYYAA
          0x11173 == code || // Mn       MAHAJANI SIGN NUKTA
          0x11180 <= code && code <= 0x11181 || // Mn   [2] SHARADA SIGN CANDRABINDU..SHARADA SIGN ANUSVARA
          0x111B6 <= code && code <= 0x111BE || // Mn   [9] SHARADA VOWEL SIGN U..SHARADA VOWEL SIGN O
          0x111CA <= code && code <= 0x111CC || // Mn   [3] SHARADA SIGN NUKTA..SHARADA EXTRA SHORT VOWEL MARK
          0x1122F <= code && code <= 0x11231 || // Mn   [3] KHOJKI VOWEL SIGN U..KHOJKI VOWEL SIGN AI
          0x11234 == code || // Mn       KHOJKI SIGN ANUSVARA
          0x11236 <= code && code <= 0x11237 || // Mn   [2] KHOJKI SIGN NUKTA..KHOJKI SIGN SHADDA
          0x1123E == code || // Mn       KHOJKI SIGN SUKUN
          0x112DF == code || // Mn       KHUDAWADI SIGN ANUSVARA
          0x112E3 <= code && code <= 0x112EA || // Mn   [8] KHUDAWADI VOWEL SIGN U..KHUDAWADI SIGN VIRAMA
          0x11300 <= code && code <= 0x11301 || // Mn   [2] GRANTHA SIGN COMBINING ANUSVARA ABOVE..GRANTHA SIGN CANDRABINDU
          0x1133C == code || // Mn       GRANTHA SIGN NUKTA
          0x1133E == code || // Mc       GRANTHA VOWEL SIGN AA
          0x11340 == code || // Mn       GRANTHA VOWEL SIGN II
          0x11357 == code || // Mc       GRANTHA AU LENGTH MARK
          0x11366 <= code && code <= 0x1136C || // Mn   [7] COMBINING GRANTHA DIGIT ZERO..COMBINING GRANTHA DIGIT SIX
          0x11370 <= code && code <= 0x11374 || // Mn   [5] COMBINING GRANTHA LETTER A..COMBINING GRANTHA LETTER PA
          0x11438 <= code && code <= 0x1143F || // Mn   [8] NEWA VOWEL SIGN U..NEWA VOWEL SIGN AI
          0x11442 <= code && code <= 0x11444 || // Mn   [3] NEWA SIGN VIRAMA..NEWA SIGN ANUSVARA
          0x11446 == code || // Mn       NEWA SIGN NUKTA
          0x114B0 == code || // Mc       TIRHUTA VOWEL SIGN AA
          0x114B3 <= code && code <= 0x114B8 || // Mn   [6] TIRHUTA VOWEL SIGN U..TIRHUTA VOWEL SIGN VOCALIC LL
          0x114BA == code || // Mn       TIRHUTA VOWEL SIGN SHORT E
          0x114BD == code || // Mc       TIRHUTA VOWEL SIGN SHORT O
          0x114BF <= code && code <= 0x114C0 || // Mn   [2] TIRHUTA SIGN CANDRABINDU..TIRHUTA SIGN ANUSVARA
          0x114C2 <= code && code <= 0x114C3 || // Mn   [2] TIRHUTA SIGN VIRAMA..TIRHUTA SIGN NUKTA
          0x115AF == code || // Mc       SIDDHAM VOWEL SIGN AA
          0x115B2 <= code && code <= 0x115B5 || // Mn   [4] SIDDHAM VOWEL SIGN U..SIDDHAM VOWEL SIGN VOCALIC RR
          0x115BC <= code && code <= 0x115BD || // Mn   [2] SIDDHAM SIGN CANDRABINDU..SIDDHAM SIGN ANUSVARA
          0x115BF <= code && code <= 0x115C0 || // Mn   [2] SIDDHAM SIGN VIRAMA..SIDDHAM SIGN NUKTA
          0x115DC <= code && code <= 0x115DD || // Mn   [2] SIDDHAM VOWEL SIGN ALTERNATE U..SIDDHAM VOWEL SIGN ALTERNATE UU
          0x11633 <= code && code <= 0x1163A || // Mn   [8] MODI VOWEL SIGN U..MODI VOWEL SIGN AI
          0x1163D == code || // Mn       MODI SIGN ANUSVARA
          0x1163F <= code && code <= 0x11640 || // Mn   [2] MODI SIGN VIRAMA..MODI SIGN ARDHACANDRA
          0x116AB == code || // Mn       TAKRI SIGN ANUSVARA
          0x116AD == code || // Mn       TAKRI VOWEL SIGN AA
          0x116B0 <= code && code <= 0x116B5 || // Mn   [6] TAKRI VOWEL SIGN U..TAKRI VOWEL SIGN AU
          0x116B7 == code || // Mn       TAKRI SIGN NUKTA
          0x1171D <= code && code <= 0x1171F || // Mn   [3] AHOM CONSONANT SIGN MEDIAL LA..AHOM CONSONANT SIGN MEDIAL LIGATING RA
          0x11722 <= code && code <= 0x11725 || // Mn   [4] AHOM VOWEL SIGN I..AHOM VOWEL SIGN UU
          0x11727 <= code && code <= 0x1172B || // Mn   [5] AHOM VOWEL SIGN AW..AHOM SIGN KILLER
          0x11A01 <= code && code <= 0x11A06 || // Mn   [6] ZANABAZAR SQUARE VOWEL SIGN I..ZANABAZAR SQUARE VOWEL SIGN O
          0x11A09 <= code && code <= 0x11A0A || // Mn   [2] ZANABAZAR SQUARE VOWEL SIGN REVERSED I..ZANABAZAR SQUARE VOWEL LENGTH MARK
          0x11A33 <= code && code <= 0x11A38 || // Mn   [6] ZANABAZAR SQUARE FINAL CONSONANT MARK..ZANABAZAR SQUARE SIGN ANUSVARA
          0x11A3B <= code && code <= 0x11A3E || // Mn   [4] ZANABAZAR SQUARE CLUSTER-FINAL LETTER YA..ZANABAZAR SQUARE CLUSTER-FINAL LETTER VA
          0x11A47 == code || // Mn       ZANABAZAR SQUARE SUBJOINER
          0x11A51 <= code && code <= 0x11A56 || // Mn   [6] SOYOMBO VOWEL SIGN I..SOYOMBO VOWEL SIGN OE
          0x11A59 <= code && code <= 0x11A5B || // Mn   [3] SOYOMBO VOWEL SIGN VOCALIC R..SOYOMBO VOWEL LENGTH MARK
          0x11A8A <= code && code <= 0x11A96 || // Mn  [13] SOYOMBO FINAL CONSONANT SIGN G..SOYOMBO SIGN ANUSVARA
          0x11A98 <= code && code <= 0x11A99 || // Mn   [2] SOYOMBO GEMINATION MARK..SOYOMBO SUBJOINER
          0x11C30 <= code && code <= 0x11C36 || // Mn   [7] BHAIKSUKI VOWEL SIGN I..BHAIKSUKI VOWEL SIGN VOCALIC L
          0x11C38 <= code && code <= 0x11C3D || // Mn   [6] BHAIKSUKI VOWEL SIGN E..BHAIKSUKI SIGN ANUSVARA
          0x11C3F == code || // Mn       BHAIKSUKI SIGN VIRAMA
          0x11C92 <= code && code <= 0x11CA7 || // Mn  [22] MARCHEN SUBJOINED LETTER KA..MARCHEN SUBJOINED LETTER ZA
          0x11CAA <= code && code <= 0x11CB0 || // Mn   [7] MARCHEN SUBJOINED LETTER RA..MARCHEN VOWEL SIGN AA
          0x11CB2 <= code && code <= 0x11CB3 || // Mn   [2] MARCHEN VOWEL SIGN U..MARCHEN VOWEL SIGN E
          0x11CB5 <= code && code <= 0x11CB6 || // Mn   [2] MARCHEN SIGN ANUSVARA..MARCHEN SIGN CANDRABINDU
          0x11D31 <= code && code <= 0x11D36 || // Mn   [6] MASARAM GONDI VOWEL SIGN AA..MASARAM GONDI VOWEL SIGN VOCALIC R
          0x11D3A == code || // Mn       MASARAM GONDI VOWEL SIGN E
          0x11D3C <= code && code <= 0x11D3D || // Mn   [2] MASARAM GONDI VOWEL SIGN AI..MASARAM GONDI VOWEL SIGN O
          0x11D3F <= code && code <= 0x11D45 || // Mn   [7] MASARAM GONDI VOWEL SIGN AU..MASARAM GONDI VIRAMA
          0x11D47 == code || // Mn       MASARAM GONDI RA-KARA
          0x16AF0 <= code && code <= 0x16AF4 || // Mn   [5] BASSA VAH COMBINING HIGH TONE..BASSA VAH COMBINING HIGH-LOW TONE
          0x16B30 <= code && code <= 0x16B36 || // Mn   [7] PAHAWH HMONG MARK CIM TUB..PAHAWH HMONG MARK CIM TAUM
          0x16F8F <= code && code <= 0x16F92 || // Mn   [4] MIAO TONE RIGHT..MIAO TONE BELOW
          0x1BC9D <= code && code <= 0x1BC9E || // Mn   [2] DUPLOYAN THICK LETTER SELECTOR..DUPLOYAN DOUBLE MARK
          0x1D165 == code || // Mc       MUSICAL SYMBOL COMBINING STEM
          0x1D167 <= code && code <= 0x1D169 || // Mn   [3] MUSICAL SYMBOL COMBINING TREMOLO-1..MUSICAL SYMBOL COMBINING TREMOLO-3
          0x1D16E <= code && code <= 0x1D172 || // Mc   [5] MUSICAL SYMBOL COMBINING FLAG-1..MUSICAL SYMBOL COMBINING FLAG-5
          0x1D17B <= code && code <= 0x1D182 || // Mn   [8] MUSICAL SYMBOL COMBINING ACCENT..MUSICAL SYMBOL COMBINING LOURE
          0x1D185 <= code && code <= 0x1D18B || // Mn   [7] MUSICAL SYMBOL COMBINING DOIT..MUSICAL SYMBOL COMBINING TRIPLE TONGUE
          0x1D1AA <= code && code <= 0x1D1AD || // Mn   [4] MUSICAL SYMBOL COMBINING DOWN BOW..MUSICAL SYMBOL COMBINING SNAP PIZZICATO
          0x1D242 <= code && code <= 0x1D244 || // Mn   [3] COMBINING GREEK MUSICAL TRISEME..COMBINING GREEK MUSICAL PENTASEME
          0x1DA00 <= code && code <= 0x1DA36 || // Mn  [55] SIGNWRITING HEAD RIM..SIGNWRITING AIR SUCKING IN
          0x1DA3B <= code && code <= 0x1DA6C || // Mn  [50] SIGNWRITING MOUTH CLOSED NEUTRAL..SIGNWRITING EXCITEMENT
          0x1DA75 == code || // Mn       SIGNWRITING UPPER BODY TILTING FROM HIP JOINTS
          0x1DA84 == code || // Mn       SIGNWRITING LOCATION HEAD NECK
          0x1DA9B <= code && code <= 0x1DA9F || // Mn   [5] SIGNWRITING FILL MODIFIER-2..SIGNWRITING FILL MODIFIER-6
          0x1DAA1 <= code && code <= 0x1DAAF || // Mn  [15] SIGNWRITING ROTATION MODIFIER-2..SIGNWRITING ROTATION MODIFIER-16
          0x1E000 <= code && code <= 0x1E006 || // Mn   [7] COMBINING GLAGOLITIC LETTER AZU..COMBINING GLAGOLITIC LETTER ZHIVETE
          0x1E008 <= code && code <= 0x1E018 || // Mn  [17] COMBINING GLAGOLITIC LETTER ZEMLJA..COMBINING GLAGOLITIC LETTER HERU
          0x1E01B <= code && code <= 0x1E021 || // Mn   [7] COMBINING GLAGOLITIC LETTER SHTA..COMBINING GLAGOLITIC LETTER YATI
          0x1E023 <= code && code <= 0x1E024 || // Mn   [2] COMBINING GLAGOLITIC LETTER YU..COMBINING GLAGOLITIC LETTER SMALL YUS
          0x1E026 <= code && code <= 0x1E02A || // Mn   [5] COMBINING GLAGOLITIC LETTER YO..COMBINING GLAGOLITIC LETTER FITA
          0x1E8D0 <= code && code <= 0x1E8D6 || // Mn   [7] MENDE KIKAKUI COMBINING NUMBER TEENS..MENDE KIKAKUI COMBINING NUMBER MILLIONS
          0x1E944 <= code && code <= 0x1E94A || // Mn   [7] ADLAM ALIF LENGTHENER..ADLAM NUKTA
          0xE0020 <= code && code <= 0xE007F || // Cf  [96] TAG SPACE..CANCEL TAG
          0xE0100 <= code && code <= 0xE01EF // Mn [240] VARIATION SELECTOR-17..VARIATION SELECTOR-256
          ) {
              return Extend;
            }

          if (0x1F1E6 <= code && code <= 0x1F1FF) // So  [26] REGIONAL INDICATOR SYMBOL LETTER A..REGIONAL INDICATOR SYMBOL LETTER Z
            {
              return Regional_Indicator;
            }

          if (0x0903 == code || // Mc       DEVANAGARI SIGN VISARGA
          0x093B == code || // Mc       DEVANAGARI VOWEL SIGN OOE
          0x093E <= code && code <= 0x0940 || // Mc   [3] DEVANAGARI VOWEL SIGN AA..DEVANAGARI VOWEL SIGN II
          0x0949 <= code && code <= 0x094C || // Mc   [4] DEVANAGARI VOWEL SIGN CANDRA O..DEVANAGARI VOWEL SIGN AU
          0x094E <= code && code <= 0x094F || // Mc   [2] DEVANAGARI VOWEL SIGN PRISHTHAMATRA E..DEVANAGARI VOWEL SIGN AW
          0x0982 <= code && code <= 0x0983 || // Mc   [2] BENGALI SIGN ANUSVARA..BENGALI SIGN VISARGA
          0x09BF <= code && code <= 0x09C0 || // Mc   [2] BENGALI VOWEL SIGN I..BENGALI VOWEL SIGN II
          0x09C7 <= code && code <= 0x09C8 || // Mc   [2] BENGALI VOWEL SIGN E..BENGALI VOWEL SIGN AI
          0x09CB <= code && code <= 0x09CC || // Mc   [2] BENGALI VOWEL SIGN O..BENGALI VOWEL SIGN AU
          0x0A03 == code || // Mc       GURMUKHI SIGN VISARGA
          0x0A3E <= code && code <= 0x0A40 || // Mc   [3] GURMUKHI VOWEL SIGN AA..GURMUKHI VOWEL SIGN II
          0x0A83 == code || // Mc       GUJARATI SIGN VISARGA
          0x0ABE <= code && code <= 0x0AC0 || // Mc   [3] GUJARATI VOWEL SIGN AA..GUJARATI VOWEL SIGN II
          0x0AC9 == code || // Mc       GUJARATI VOWEL SIGN CANDRA O
          0x0ACB <= code && code <= 0x0ACC || // Mc   [2] GUJARATI VOWEL SIGN O..GUJARATI VOWEL SIGN AU
          0x0B02 <= code && code <= 0x0B03 || // Mc   [2] ORIYA SIGN ANUSVARA..ORIYA SIGN VISARGA
          0x0B40 == code || // Mc       ORIYA VOWEL SIGN II
          0x0B47 <= code && code <= 0x0B48 || // Mc   [2] ORIYA VOWEL SIGN E..ORIYA VOWEL SIGN AI
          0x0B4B <= code && code <= 0x0B4C || // Mc   [2] ORIYA VOWEL SIGN O..ORIYA VOWEL SIGN AU
          0x0BBF == code || // Mc       TAMIL VOWEL SIGN I
          0x0BC1 <= code && code <= 0x0BC2 || // Mc   [2] TAMIL VOWEL SIGN U..TAMIL VOWEL SIGN UU
          0x0BC6 <= code && code <= 0x0BC8 || // Mc   [3] TAMIL VOWEL SIGN E..TAMIL VOWEL SIGN AI
          0x0BCA <= code && code <= 0x0BCC || // Mc   [3] TAMIL VOWEL SIGN O..TAMIL VOWEL SIGN AU
          0x0C01 <= code && code <= 0x0C03 || // Mc   [3] TELUGU SIGN CANDRABINDU..TELUGU SIGN VISARGA
          0x0C41 <= code && code <= 0x0C44 || // Mc   [4] TELUGU VOWEL SIGN U..TELUGU VOWEL SIGN VOCALIC RR
          0x0C82 <= code && code <= 0x0C83 || // Mc   [2] KANNADA SIGN ANUSVARA..KANNADA SIGN VISARGA
          0x0CBE == code || // Mc       KANNADA VOWEL SIGN AA
          0x0CC0 <= code && code <= 0x0CC1 || // Mc   [2] KANNADA VOWEL SIGN II..KANNADA VOWEL SIGN U
          0x0CC3 <= code && code <= 0x0CC4 || // Mc   [2] KANNADA VOWEL SIGN VOCALIC R..KANNADA VOWEL SIGN VOCALIC RR
          0x0CC7 <= code && code <= 0x0CC8 || // Mc   [2] KANNADA VOWEL SIGN EE..KANNADA VOWEL SIGN AI
          0x0CCA <= code && code <= 0x0CCB || // Mc   [2] KANNADA VOWEL SIGN O..KANNADA VOWEL SIGN OO
          0x0D02 <= code && code <= 0x0D03 || // Mc   [2] MALAYALAM SIGN ANUSVARA..MALAYALAM SIGN VISARGA
          0x0D3F <= code && code <= 0x0D40 || // Mc   [2] MALAYALAM VOWEL SIGN I..MALAYALAM VOWEL SIGN II
          0x0D46 <= code && code <= 0x0D48 || // Mc   [3] MALAYALAM VOWEL SIGN E..MALAYALAM VOWEL SIGN AI
          0x0D4A <= code && code <= 0x0D4C || // Mc   [3] MALAYALAM VOWEL SIGN O..MALAYALAM VOWEL SIGN AU
          0x0D82 <= code && code <= 0x0D83 || // Mc   [2] SINHALA SIGN ANUSVARAYA..SINHALA SIGN VISARGAYA
          0x0DD0 <= code && code <= 0x0DD1 || // Mc   [2] SINHALA VOWEL SIGN KETTI AEDA-PILLA..SINHALA VOWEL SIGN DIGA AEDA-PILLA
          0x0DD8 <= code && code <= 0x0DDE || // Mc   [7] SINHALA VOWEL SIGN GAETTA-PILLA..SINHALA VOWEL SIGN KOMBUVA HAA GAYANUKITTA
          0x0DF2 <= code && code <= 0x0DF3 || // Mc   [2] SINHALA VOWEL SIGN DIGA GAETTA-PILLA..SINHALA VOWEL SIGN DIGA GAYANUKITTA
          0x0E33 == code || // Lo       THAI CHARACTER SARA AM
          0x0EB3 == code || // Lo       LAO VOWEL SIGN AM
          0x0F3E <= code && code <= 0x0F3F || // Mc   [2] TIBETAN SIGN YAR TSHES..TIBETAN SIGN MAR TSHES
          0x0F7F == code || // Mc       TIBETAN SIGN RNAM BCAD
          0x1031 == code || // Mc       MYANMAR VOWEL SIGN E
          0x103B <= code && code <= 0x103C || // Mc   [2] MYANMAR CONSONANT SIGN MEDIAL YA..MYANMAR CONSONANT SIGN MEDIAL RA
          0x1056 <= code && code <= 0x1057 || // Mc   [2] MYANMAR VOWEL SIGN VOCALIC R..MYANMAR VOWEL SIGN VOCALIC RR
          0x1084 == code || // Mc       MYANMAR VOWEL SIGN SHAN E
          0x17B6 == code || // Mc       KHMER VOWEL SIGN AA
          0x17BE <= code && code <= 0x17C5 || // Mc   [8] KHMER VOWEL SIGN OE..KHMER VOWEL SIGN AU
          0x17C7 <= code && code <= 0x17C8 || // Mc   [2] KHMER SIGN REAHMUK..KHMER SIGN YUUKALEAPINTU
          0x1923 <= code && code <= 0x1926 || // Mc   [4] LIMBU VOWEL SIGN EE..LIMBU VOWEL SIGN AU
          0x1929 <= code && code <= 0x192B || // Mc   [3] LIMBU SUBJOINED LETTER YA..LIMBU SUBJOINED LETTER WA
          0x1930 <= code && code <= 0x1931 || // Mc   [2] LIMBU SMALL LETTER KA..LIMBU SMALL LETTER NGA
          0x1933 <= code && code <= 0x1938 || // Mc   [6] LIMBU SMALL LETTER TA..LIMBU SMALL LETTER LA
          0x1A19 <= code && code <= 0x1A1A || // Mc   [2] BUGINESE VOWEL SIGN E..BUGINESE VOWEL SIGN O
          0x1A55 == code || // Mc       TAI THAM CONSONANT SIGN MEDIAL RA
          0x1A57 == code || // Mc       TAI THAM CONSONANT SIGN LA TANG LAI
          0x1A6D <= code && code <= 0x1A72 || // Mc   [6] TAI THAM VOWEL SIGN OY..TAI THAM VOWEL SIGN THAM AI
          0x1B04 == code || // Mc       BALINESE SIGN BISAH
          0x1B35 == code || // Mc       BALINESE VOWEL SIGN TEDUNG
          0x1B3B == code || // Mc       BALINESE VOWEL SIGN RA REPA TEDUNG
          0x1B3D <= code && code <= 0x1B41 || // Mc   [5] BALINESE VOWEL SIGN LA LENGA TEDUNG..BALINESE VOWEL SIGN TALING REPA TEDUNG
          0x1B43 <= code && code <= 0x1B44 || // Mc   [2] BALINESE VOWEL SIGN PEPET TEDUNG..BALINESE ADEG ADEG
          0x1B82 == code || // Mc       SUNDANESE SIGN PANGWISAD
          0x1BA1 == code || // Mc       SUNDANESE CONSONANT SIGN PAMINGKAL
          0x1BA6 <= code && code <= 0x1BA7 || // Mc   [2] SUNDANESE VOWEL SIGN PANAELAENG..SUNDANESE VOWEL SIGN PANOLONG
          0x1BAA == code || // Mc       SUNDANESE SIGN PAMAAEH
          0x1BE7 == code || // Mc       BATAK VOWEL SIGN E
          0x1BEA <= code && code <= 0x1BEC || // Mc   [3] BATAK VOWEL SIGN I..BATAK VOWEL SIGN O
          0x1BEE == code || // Mc       BATAK VOWEL SIGN U
          0x1BF2 <= code && code <= 0x1BF3 || // Mc   [2] BATAK PANGOLAT..BATAK PANONGONAN
          0x1C24 <= code && code <= 0x1C2B || // Mc   [8] LEPCHA SUBJOINED LETTER YA..LEPCHA VOWEL SIGN UU
          0x1C34 <= code && code <= 0x1C35 || // Mc   [2] LEPCHA CONSONANT SIGN NYIN-DO..LEPCHA CONSONANT SIGN KANG
          0x1CE1 == code || // Mc       VEDIC TONE ATHARVAVEDIC INDEPENDENT SVARITA
          0x1CF2 <= code && code <= 0x1CF3 || // Mc   [2] VEDIC SIGN ARDHAVISARGA..VEDIC SIGN ROTATED ARDHAVISARGA
          0x1CF7 == code || // Mc       VEDIC SIGN ATIKRAMA
          0xA823 <= code && code <= 0xA824 || // Mc   [2] SYLOTI NAGRI VOWEL SIGN A..SYLOTI NAGRI VOWEL SIGN I
          0xA827 == code || // Mc       SYLOTI NAGRI VOWEL SIGN OO
          0xA880 <= code && code <= 0xA881 || // Mc   [2] SAURASHTRA SIGN ANUSVARA..SAURASHTRA SIGN VISARGA
          0xA8B4 <= code && code <= 0xA8C3 || // Mc  [16] SAURASHTRA CONSONANT SIGN HAARU..SAURASHTRA VOWEL SIGN AU
          0xA952 <= code && code <= 0xA953 || // Mc   [2] REJANG CONSONANT SIGN H..REJANG VIRAMA
          0xA983 == code || // Mc       JAVANESE SIGN WIGNYAN
          0xA9B4 <= code && code <= 0xA9B5 || // Mc   [2] JAVANESE VOWEL SIGN TARUNG..JAVANESE VOWEL SIGN TOLONG
          0xA9BA <= code && code <= 0xA9BB || // Mc   [2] JAVANESE VOWEL SIGN TALING..JAVANESE VOWEL SIGN DIRGA MURE
          0xA9BD <= code && code <= 0xA9C0 || // Mc   [4] JAVANESE CONSONANT SIGN KERET..JAVANESE PANGKON
          0xAA2F <= code && code <= 0xAA30 || // Mc   [2] CHAM VOWEL SIGN O..CHAM VOWEL SIGN AI
          0xAA33 <= code && code <= 0xAA34 || // Mc   [2] CHAM CONSONANT SIGN YA..CHAM CONSONANT SIGN RA
          0xAA4D == code || // Mc       CHAM CONSONANT SIGN FINAL H
          0xAAEB == code || // Mc       MEETEI MAYEK VOWEL SIGN II
          0xAAEE <= code && code <= 0xAAEF || // Mc   [2] MEETEI MAYEK VOWEL SIGN AU..MEETEI MAYEK VOWEL SIGN AAU
          0xAAF5 == code || // Mc       MEETEI MAYEK VOWEL SIGN VISARGA
          0xABE3 <= code && code <= 0xABE4 || // Mc   [2] MEETEI MAYEK VOWEL SIGN ONAP..MEETEI MAYEK VOWEL SIGN INAP
          0xABE6 <= code && code <= 0xABE7 || // Mc   [2] MEETEI MAYEK VOWEL SIGN YENAP..MEETEI MAYEK VOWEL SIGN SOUNAP
          0xABE9 <= code && code <= 0xABEA || // Mc   [2] MEETEI MAYEK VOWEL SIGN CHEINAP..MEETEI MAYEK VOWEL SIGN NUNG
          0xABEC == code || // Mc       MEETEI MAYEK LUM IYEK
          0x11000 == code || // Mc       BRAHMI SIGN CANDRABINDU
          0x11002 == code || // Mc       BRAHMI SIGN VISARGA
          0x11082 == code || // Mc       KAITHI SIGN VISARGA
          0x110B0 <= code && code <= 0x110B2 || // Mc   [3] KAITHI VOWEL SIGN AA..KAITHI VOWEL SIGN II
          0x110B7 <= code && code <= 0x110B8 || // Mc   [2] KAITHI VOWEL SIGN O..KAITHI VOWEL SIGN AU
          0x1112C == code || // Mc       CHAKMA VOWEL SIGN E
          0x11182 == code || // Mc       SHARADA SIGN VISARGA
          0x111B3 <= code && code <= 0x111B5 || // Mc   [3] SHARADA VOWEL SIGN AA..SHARADA VOWEL SIGN II
          0x111BF <= code && code <= 0x111C0 || // Mc   [2] SHARADA VOWEL SIGN AU..SHARADA SIGN VIRAMA
          0x1122C <= code && code <= 0x1122E || // Mc   [3] KHOJKI VOWEL SIGN AA..KHOJKI VOWEL SIGN II
          0x11232 <= code && code <= 0x11233 || // Mc   [2] KHOJKI VOWEL SIGN O..KHOJKI VOWEL SIGN AU
          0x11235 == code || // Mc       KHOJKI SIGN VIRAMA
          0x112E0 <= code && code <= 0x112E2 || // Mc   [3] KHUDAWADI VOWEL SIGN AA..KHUDAWADI VOWEL SIGN II
          0x11302 <= code && code <= 0x11303 || // Mc   [2] GRANTHA SIGN ANUSVARA..GRANTHA SIGN VISARGA
          0x1133F == code || // Mc       GRANTHA VOWEL SIGN I
          0x11341 <= code && code <= 0x11344 || // Mc   [4] GRANTHA VOWEL SIGN U..GRANTHA VOWEL SIGN VOCALIC RR
          0x11347 <= code && code <= 0x11348 || // Mc   [2] GRANTHA VOWEL SIGN EE..GRANTHA VOWEL SIGN AI
          0x1134B <= code && code <= 0x1134D || // Mc   [3] GRANTHA VOWEL SIGN OO..GRANTHA SIGN VIRAMA
          0x11362 <= code && code <= 0x11363 || // Mc   [2] GRANTHA VOWEL SIGN VOCALIC L..GRANTHA VOWEL SIGN VOCALIC LL
          0x11435 <= code && code <= 0x11437 || // Mc   [3] NEWA VOWEL SIGN AA..NEWA VOWEL SIGN II
          0x11440 <= code && code <= 0x11441 || // Mc   [2] NEWA VOWEL SIGN O..NEWA VOWEL SIGN AU
          0x11445 == code || // Mc       NEWA SIGN VISARGA
          0x114B1 <= code && code <= 0x114B2 || // Mc   [2] TIRHUTA VOWEL SIGN I..TIRHUTA VOWEL SIGN II
          0x114B9 == code || // Mc       TIRHUTA VOWEL SIGN E
          0x114BB <= code && code <= 0x114BC || // Mc   [2] TIRHUTA VOWEL SIGN AI..TIRHUTA VOWEL SIGN O
          0x114BE == code || // Mc       TIRHUTA VOWEL SIGN AU
          0x114C1 == code || // Mc       TIRHUTA SIGN VISARGA
          0x115B0 <= code && code <= 0x115B1 || // Mc   [2] SIDDHAM VOWEL SIGN I..SIDDHAM VOWEL SIGN II
          0x115B8 <= code && code <= 0x115BB || // Mc   [4] SIDDHAM VOWEL SIGN E..SIDDHAM VOWEL SIGN AU
          0x115BE == code || // Mc       SIDDHAM SIGN VISARGA
          0x11630 <= code && code <= 0x11632 || // Mc   [3] MODI VOWEL SIGN AA..MODI VOWEL SIGN II
          0x1163B <= code && code <= 0x1163C || // Mc   [2] MODI VOWEL SIGN O..MODI VOWEL SIGN AU
          0x1163E == code || // Mc       MODI SIGN VISARGA
          0x116AC == code || // Mc       TAKRI SIGN VISARGA
          0x116AE <= code && code <= 0x116AF || // Mc   [2] TAKRI VOWEL SIGN I..TAKRI VOWEL SIGN II
          0x116B6 == code || // Mc       TAKRI SIGN VIRAMA
          0x11720 <= code && code <= 0x11721 || // Mc   [2] AHOM VOWEL SIGN A..AHOM VOWEL SIGN AA
          0x11726 == code || // Mc       AHOM VOWEL SIGN E
          0x11A07 <= code && code <= 0x11A08 || // Mc   [2] ZANABAZAR SQUARE VOWEL SIGN AI..ZANABAZAR SQUARE VOWEL SIGN AU
          0x11A39 == code || // Mc       ZANABAZAR SQUARE SIGN VISARGA
          0x11A57 <= code && code <= 0x11A58 || // Mc   [2] SOYOMBO VOWEL SIGN AI..SOYOMBO VOWEL SIGN AU
          0x11A97 == code || // Mc       SOYOMBO SIGN VISARGA
          0x11C2F == code || // Mc       BHAIKSUKI VOWEL SIGN AA
          0x11C3E == code || // Mc       BHAIKSUKI SIGN VISARGA
          0x11CA9 == code || // Mc       MARCHEN SUBJOINED LETTER YA
          0x11CB1 == code || // Mc       MARCHEN VOWEL SIGN I
          0x11CB4 == code || // Mc       MARCHEN VOWEL SIGN O
          0x16F51 <= code && code <= 0x16F7E || // Mc  [46] MIAO SIGN ASPIRATION..MIAO VOWEL SIGN NG
          0x1D166 == code || // Mc       MUSICAL SYMBOL COMBINING SPRECHGESANG STEM
          0x1D16D == code // Mc       MUSICAL SYMBOL COMBINING AUGMENTATION DOT
          ) {
              return SpacingMark;
            }

          if (0x1100 <= code && code <= 0x115F || // Lo  [96] HANGUL CHOSEONG KIYEOK..HANGUL CHOSEONG FILLER
          0xA960 <= code && code <= 0xA97C // Lo  [29] HANGUL CHOSEONG TIKEUT-MIEUM..HANGUL CHOSEONG SSANGYEORINHIEUH
          ) {
              return L;
            }

          if (0x1160 <= code && code <= 0x11A7 || // Lo  [72] HANGUL JUNGSEONG FILLER..HANGUL JUNGSEONG O-YAE
          0xD7B0 <= code && code <= 0xD7C6 // Lo  [23] HANGUL JUNGSEONG O-YEO..HANGUL JUNGSEONG ARAEA-E
          ) {
              return V;
            }

          if (0x11A8 <= code && code <= 0x11FF || // Lo  [88] HANGUL JONGSEONG KIYEOK..HANGUL JONGSEONG SSANGNIEUN
          0xD7CB <= code && code <= 0xD7FB // Lo  [49] HANGUL JONGSEONG NIEUN-RIEUL..HANGUL JONGSEONG PHIEUPH-THIEUTH
          ) {
              return T;
            }

          if (0xAC00 == code || // Lo       HANGUL SYLLABLE GA
          0xAC1C == code || // Lo       HANGUL SYLLABLE GAE
          0xAC38 == code || // Lo       HANGUL SYLLABLE GYA
          0xAC54 == code || // Lo       HANGUL SYLLABLE GYAE
          0xAC70 == code || // Lo       HANGUL SYLLABLE GEO
          0xAC8C == code || // Lo       HANGUL SYLLABLE GE
          0xACA8 == code || // Lo       HANGUL SYLLABLE GYEO
          0xACC4 == code || // Lo       HANGUL SYLLABLE GYE
          0xACE0 == code || // Lo       HANGUL SYLLABLE GO
          0xACFC == code || // Lo       HANGUL SYLLABLE GWA
          0xAD18 == code || // Lo       HANGUL SYLLABLE GWAE
          0xAD34 == code || // Lo       HANGUL SYLLABLE GOE
          0xAD50 == code || // Lo       HANGUL SYLLABLE GYO
          0xAD6C == code || // Lo       HANGUL SYLLABLE GU
          0xAD88 == code || // Lo       HANGUL SYLLABLE GWEO
          0xADA4 == code || // Lo       HANGUL SYLLABLE GWE
          0xADC0 == code || // Lo       HANGUL SYLLABLE GWI
          0xADDC == code || // Lo       HANGUL SYLLABLE GYU
          0xADF8 == code || // Lo       HANGUL SYLLABLE GEU
          0xAE14 == code || // Lo       HANGUL SYLLABLE GYI
          0xAE30 == code || // Lo       HANGUL SYLLABLE GI
          0xAE4C == code || // Lo       HANGUL SYLLABLE GGA
          0xAE68 == code || // Lo       HANGUL SYLLABLE GGAE
          0xAE84 == code || // Lo       HANGUL SYLLABLE GGYA
          0xAEA0 == code || // Lo       HANGUL SYLLABLE GGYAE
          0xAEBC == code || // Lo       HANGUL SYLLABLE GGEO
          0xAED8 == code || // Lo       HANGUL SYLLABLE GGE
          0xAEF4 == code || // Lo       HANGUL SYLLABLE GGYEO
          0xAF10 == code || // Lo       HANGUL SYLLABLE GGYE
          0xAF2C == code || // Lo       HANGUL SYLLABLE GGO
          0xAF48 == code || // Lo       HANGUL SYLLABLE GGWA
          0xAF64 == code || // Lo       HANGUL SYLLABLE GGWAE
          0xAF80 == code || // Lo       HANGUL SYLLABLE GGOE
          0xAF9C == code || // Lo       HANGUL SYLLABLE GGYO
          0xAFB8 == code || // Lo       HANGUL SYLLABLE GGU
          0xAFD4 == code || // Lo       HANGUL SYLLABLE GGWEO
          0xAFF0 == code || // Lo       HANGUL SYLLABLE GGWE
          0xB00C == code || // Lo       HANGUL SYLLABLE GGWI
          0xB028 == code || // Lo       HANGUL SYLLABLE GGYU
          0xB044 == code || // Lo       HANGUL SYLLABLE GGEU
          0xB060 == code || // Lo       HANGUL SYLLABLE GGYI
          0xB07C == code || // Lo       HANGUL SYLLABLE GGI
          0xB098 == code || // Lo       HANGUL SYLLABLE NA
          0xB0B4 == code || // Lo       HANGUL SYLLABLE NAE
          0xB0D0 == code || // Lo       HANGUL SYLLABLE NYA
          0xB0EC == code || // Lo       HANGUL SYLLABLE NYAE
          0xB108 == code || // Lo       HANGUL SYLLABLE NEO
          0xB124 == code || // Lo       HANGUL SYLLABLE NE
          0xB140 == code || // Lo       HANGUL SYLLABLE NYEO
          0xB15C == code || // Lo       HANGUL SYLLABLE NYE
          0xB178 == code || // Lo       HANGUL SYLLABLE NO
          0xB194 == code || // Lo       HANGUL SYLLABLE NWA
          0xB1B0 == code || // Lo       HANGUL SYLLABLE NWAE
          0xB1CC == code || // Lo       HANGUL SYLLABLE NOE
          0xB1E8 == code || // Lo       HANGUL SYLLABLE NYO
          0xB204 == code || // Lo       HANGUL SYLLABLE NU
          0xB220 == code || // Lo       HANGUL SYLLABLE NWEO
          0xB23C == code || // Lo       HANGUL SYLLABLE NWE
          0xB258 == code || // Lo       HANGUL SYLLABLE NWI
          0xB274 == code || // Lo       HANGUL SYLLABLE NYU
          0xB290 == code || // Lo       HANGUL SYLLABLE NEU
          0xB2AC == code || // Lo       HANGUL SYLLABLE NYI
          0xB2C8 == code || // Lo       HANGUL SYLLABLE NI
          0xB2E4 == code || // Lo       HANGUL SYLLABLE DA
          0xB300 == code || // Lo       HANGUL SYLLABLE DAE
          0xB31C == code || // Lo       HANGUL SYLLABLE DYA
          0xB338 == code || // Lo       HANGUL SYLLABLE DYAE
          0xB354 == code || // Lo       HANGUL SYLLABLE DEO
          0xB370 == code || // Lo       HANGUL SYLLABLE DE
          0xB38C == code || // Lo       HANGUL SYLLABLE DYEO
          0xB3A8 == code || // Lo       HANGUL SYLLABLE DYE
          0xB3C4 == code || // Lo       HANGUL SYLLABLE DO
          0xB3E0 == code || // Lo       HANGUL SYLLABLE DWA
          0xB3FC == code || // Lo       HANGUL SYLLABLE DWAE
          0xB418 == code || // Lo       HANGUL SYLLABLE DOE
          0xB434 == code || // Lo       HANGUL SYLLABLE DYO
          0xB450 == code || // Lo       HANGUL SYLLABLE DU
          0xB46C == code || // Lo       HANGUL SYLLABLE DWEO
          0xB488 == code || // Lo       HANGUL SYLLABLE DWE
          0xB4A4 == code || // Lo       HANGUL SYLLABLE DWI
          0xB4C0 == code || // Lo       HANGUL SYLLABLE DYU
          0xB4DC == code || // Lo       HANGUL SYLLABLE DEU
          0xB4F8 == code || // Lo       HANGUL SYLLABLE DYI
          0xB514 == code || // Lo       HANGUL SYLLABLE DI
          0xB530 == code || // Lo       HANGUL SYLLABLE DDA
          0xB54C == code || // Lo       HANGUL SYLLABLE DDAE
          0xB568 == code || // Lo       HANGUL SYLLABLE DDYA
          0xB584 == code || // Lo       HANGUL SYLLABLE DDYAE
          0xB5A0 == code || // Lo       HANGUL SYLLABLE DDEO
          0xB5BC == code || // Lo       HANGUL SYLLABLE DDE
          0xB5D8 == code || // Lo       HANGUL SYLLABLE DDYEO
          0xB5F4 == code || // Lo       HANGUL SYLLABLE DDYE
          0xB610 == code || // Lo       HANGUL SYLLABLE DDO
          0xB62C == code || // Lo       HANGUL SYLLABLE DDWA
          0xB648 == code || // Lo       HANGUL SYLLABLE DDWAE
          0xB664 == code || // Lo       HANGUL SYLLABLE DDOE
          0xB680 == code || // Lo       HANGUL SYLLABLE DDYO
          0xB69C == code || // Lo       HANGUL SYLLABLE DDU
          0xB6B8 == code || // Lo       HANGUL SYLLABLE DDWEO
          0xB6D4 == code || // Lo       HANGUL SYLLABLE DDWE
          0xB6F0 == code || // Lo       HANGUL SYLLABLE DDWI
          0xB70C == code || // Lo       HANGUL SYLLABLE DDYU
          0xB728 == code || // Lo       HANGUL SYLLABLE DDEU
          0xB744 == code || // Lo       HANGUL SYLLABLE DDYI
          0xB760 == code || // Lo       HANGUL SYLLABLE DDI
          0xB77C == code || // Lo       HANGUL SYLLABLE RA
          0xB798 == code || // Lo       HANGUL SYLLABLE RAE
          0xB7B4 == code || // Lo       HANGUL SYLLABLE RYA
          0xB7D0 == code || // Lo       HANGUL SYLLABLE RYAE
          0xB7EC == code || // Lo       HANGUL SYLLABLE REO
          0xB808 == code || // Lo       HANGUL SYLLABLE RE
          0xB824 == code || // Lo       HANGUL SYLLABLE RYEO
          0xB840 == code || // Lo       HANGUL SYLLABLE RYE
          0xB85C == code || // Lo       HANGUL SYLLABLE RO
          0xB878 == code || // Lo       HANGUL SYLLABLE RWA
          0xB894 == code || // Lo       HANGUL SYLLABLE RWAE
          0xB8B0 == code || // Lo       HANGUL SYLLABLE ROE
          0xB8CC == code || // Lo       HANGUL SYLLABLE RYO
          0xB8E8 == code || // Lo       HANGUL SYLLABLE RU
          0xB904 == code || // Lo       HANGUL SYLLABLE RWEO
          0xB920 == code || // Lo       HANGUL SYLLABLE RWE
          0xB93C == code || // Lo       HANGUL SYLLABLE RWI
          0xB958 == code || // Lo       HANGUL SYLLABLE RYU
          0xB974 == code || // Lo       HANGUL SYLLABLE REU
          0xB990 == code || // Lo       HANGUL SYLLABLE RYI
          0xB9AC == code || // Lo       HANGUL SYLLABLE RI
          0xB9C8 == code || // Lo       HANGUL SYLLABLE MA
          0xB9E4 == code || // Lo       HANGUL SYLLABLE MAE
          0xBA00 == code || // Lo       HANGUL SYLLABLE MYA
          0xBA1C == code || // Lo       HANGUL SYLLABLE MYAE
          0xBA38 == code || // Lo       HANGUL SYLLABLE MEO
          0xBA54 == code || // Lo       HANGUL SYLLABLE ME
          0xBA70 == code || // Lo       HANGUL SYLLABLE MYEO
          0xBA8C == code || // Lo       HANGUL SYLLABLE MYE
          0xBAA8 == code || // Lo       HANGUL SYLLABLE MO
          0xBAC4 == code || // Lo       HANGUL SYLLABLE MWA
          0xBAE0 == code || // Lo       HANGUL SYLLABLE MWAE
          0xBAFC == code || // Lo       HANGUL SYLLABLE MOE
          0xBB18 == code || // Lo       HANGUL SYLLABLE MYO
          0xBB34 == code || // Lo       HANGUL SYLLABLE MU
          0xBB50 == code || // Lo       HANGUL SYLLABLE MWEO
          0xBB6C == code || // Lo       HANGUL SYLLABLE MWE
          0xBB88 == code || // Lo       HANGUL SYLLABLE MWI
          0xBBA4 == code || // Lo       HANGUL SYLLABLE MYU
          0xBBC0 == code || // Lo       HANGUL SYLLABLE MEU
          0xBBDC == code || // Lo       HANGUL SYLLABLE MYI
          0xBBF8 == code || // Lo       HANGUL SYLLABLE MI
          0xBC14 == code || // Lo       HANGUL SYLLABLE BA
          0xBC30 == code || // Lo       HANGUL SYLLABLE BAE
          0xBC4C == code || // Lo       HANGUL SYLLABLE BYA
          0xBC68 == code || // Lo       HANGUL SYLLABLE BYAE
          0xBC84 == code || // Lo       HANGUL SYLLABLE BEO
          0xBCA0 == code || // Lo       HANGUL SYLLABLE BE
          0xBCBC == code || // Lo       HANGUL SYLLABLE BYEO
          0xBCD8 == code || // Lo       HANGUL SYLLABLE BYE
          0xBCF4 == code || // Lo       HANGUL SYLLABLE BO
          0xBD10 == code || // Lo       HANGUL SYLLABLE BWA
          0xBD2C == code || // Lo       HANGUL SYLLABLE BWAE
          0xBD48 == code || // Lo       HANGUL SYLLABLE BOE
          0xBD64 == code || // Lo       HANGUL SYLLABLE BYO
          0xBD80 == code || // Lo       HANGUL SYLLABLE BU
          0xBD9C == code || // Lo       HANGUL SYLLABLE BWEO
          0xBDB8 == code || // Lo       HANGUL SYLLABLE BWE
          0xBDD4 == code || // Lo       HANGUL SYLLABLE BWI
          0xBDF0 == code || // Lo       HANGUL SYLLABLE BYU
          0xBE0C == code || // Lo       HANGUL SYLLABLE BEU
          0xBE28 == code || // Lo       HANGUL SYLLABLE BYI
          0xBE44 == code || // Lo       HANGUL SYLLABLE BI
          0xBE60 == code || // Lo       HANGUL SYLLABLE BBA
          0xBE7C == code || // Lo       HANGUL SYLLABLE BBAE
          0xBE98 == code || // Lo       HANGUL SYLLABLE BBYA
          0xBEB4 == code || // Lo       HANGUL SYLLABLE BBYAE
          0xBED0 == code || // Lo       HANGUL SYLLABLE BBEO
          0xBEEC == code || // Lo       HANGUL SYLLABLE BBE
          0xBF08 == code || // Lo       HANGUL SYLLABLE BBYEO
          0xBF24 == code || // Lo       HANGUL SYLLABLE BBYE
          0xBF40 == code || // Lo       HANGUL SYLLABLE BBO
          0xBF5C == code || // Lo       HANGUL SYLLABLE BBWA
          0xBF78 == code || // Lo       HANGUL SYLLABLE BBWAE
          0xBF94 == code || // Lo       HANGUL SYLLABLE BBOE
          0xBFB0 == code || // Lo       HANGUL SYLLABLE BBYO
          0xBFCC == code || // Lo       HANGUL SYLLABLE BBU
          0xBFE8 == code || // Lo       HANGUL SYLLABLE BBWEO
          0xC004 == code || // Lo       HANGUL SYLLABLE BBWE
          0xC020 == code || // Lo       HANGUL SYLLABLE BBWI
          0xC03C == code || // Lo       HANGUL SYLLABLE BBYU
          0xC058 == code || // Lo       HANGUL SYLLABLE BBEU
          0xC074 == code || // Lo       HANGUL SYLLABLE BBYI
          0xC090 == code || // Lo       HANGUL SYLLABLE BBI
          0xC0AC == code || // Lo       HANGUL SYLLABLE SA
          0xC0C8 == code || // Lo       HANGUL SYLLABLE SAE
          0xC0E4 == code || // Lo       HANGUL SYLLABLE SYA
          0xC100 == code || // Lo       HANGUL SYLLABLE SYAE
          0xC11C == code || // Lo       HANGUL SYLLABLE SEO
          0xC138 == code || // Lo       HANGUL SYLLABLE SE
          0xC154 == code || // Lo       HANGUL SYLLABLE SYEO
          0xC170 == code || // Lo       HANGUL SYLLABLE SYE
          0xC18C == code || // Lo       HANGUL SYLLABLE SO
          0xC1A8 == code || // Lo       HANGUL SYLLABLE SWA
          0xC1C4 == code || // Lo       HANGUL SYLLABLE SWAE
          0xC1E0 == code || // Lo       HANGUL SYLLABLE SOE
          0xC1FC == code || // Lo       HANGUL SYLLABLE SYO
          0xC218 == code || // Lo       HANGUL SYLLABLE SU
          0xC234 == code || // Lo       HANGUL SYLLABLE SWEO
          0xC250 == code || // Lo       HANGUL SYLLABLE SWE
          0xC26C == code || // Lo       HANGUL SYLLABLE SWI
          0xC288 == code || // Lo       HANGUL SYLLABLE SYU
          0xC2A4 == code || // Lo       HANGUL SYLLABLE SEU
          0xC2C0 == code || // Lo       HANGUL SYLLABLE SYI
          0xC2DC == code || // Lo       HANGUL SYLLABLE SI
          0xC2F8 == code || // Lo       HANGUL SYLLABLE SSA
          0xC314 == code || // Lo       HANGUL SYLLABLE SSAE
          0xC330 == code || // Lo       HANGUL SYLLABLE SSYA
          0xC34C == code || // Lo       HANGUL SYLLABLE SSYAE
          0xC368 == code || // Lo       HANGUL SYLLABLE SSEO
          0xC384 == code || // Lo       HANGUL SYLLABLE SSE
          0xC3A0 == code || // Lo       HANGUL SYLLABLE SSYEO
          0xC3BC == code || // Lo       HANGUL SYLLABLE SSYE
          0xC3D8 == code || // Lo       HANGUL SYLLABLE SSO
          0xC3F4 == code || // Lo       HANGUL SYLLABLE SSWA
          0xC410 == code || // Lo       HANGUL SYLLABLE SSWAE
          0xC42C == code || // Lo       HANGUL SYLLABLE SSOE
          0xC448 == code || // Lo       HANGUL SYLLABLE SSYO
          0xC464 == code || // Lo       HANGUL SYLLABLE SSU
          0xC480 == code || // Lo       HANGUL SYLLABLE SSWEO
          0xC49C == code || // Lo       HANGUL SYLLABLE SSWE
          0xC4B8 == code || // Lo       HANGUL SYLLABLE SSWI
          0xC4D4 == code || // Lo       HANGUL SYLLABLE SSYU
          0xC4F0 == code || // Lo       HANGUL SYLLABLE SSEU
          0xC50C == code || // Lo       HANGUL SYLLABLE SSYI
          0xC528 == code || // Lo       HANGUL SYLLABLE SSI
          0xC544 == code || // Lo       HANGUL SYLLABLE A
          0xC560 == code || // Lo       HANGUL SYLLABLE AE
          0xC57C == code || // Lo       HANGUL SYLLABLE YA
          0xC598 == code || // Lo       HANGUL SYLLABLE YAE
          0xC5B4 == code || // Lo       HANGUL SYLLABLE EO
          0xC5D0 == code || // Lo       HANGUL SYLLABLE E
          0xC5EC == code || // Lo       HANGUL SYLLABLE YEO
          0xC608 == code || // Lo       HANGUL SYLLABLE YE
          0xC624 == code || // Lo       HANGUL SYLLABLE O
          0xC640 == code || // Lo       HANGUL SYLLABLE WA
          0xC65C == code || // Lo       HANGUL SYLLABLE WAE
          0xC678 == code || // Lo       HANGUL SYLLABLE OE
          0xC694 == code || // Lo       HANGUL SYLLABLE YO
          0xC6B0 == code || // Lo       HANGUL SYLLABLE U
          0xC6CC == code || // Lo       HANGUL SYLLABLE WEO
          0xC6E8 == code || // Lo       HANGUL SYLLABLE WE
          0xC704 == code || // Lo       HANGUL SYLLABLE WI
          0xC720 == code || // Lo       HANGUL SYLLABLE YU
          0xC73C == code || // Lo       HANGUL SYLLABLE EU
          0xC758 == code || // Lo       HANGUL SYLLABLE YI
          0xC774 == code || // Lo       HANGUL SYLLABLE I
          0xC790 == code || // Lo       HANGUL SYLLABLE JA
          0xC7AC == code || // Lo       HANGUL SYLLABLE JAE
          0xC7C8 == code || // Lo       HANGUL SYLLABLE JYA
          0xC7E4 == code || // Lo       HANGUL SYLLABLE JYAE
          0xC800 == code || // Lo       HANGUL SYLLABLE JEO
          0xC81C == code || // Lo       HANGUL SYLLABLE JE
          0xC838 == code || // Lo       HANGUL SYLLABLE JYEO
          0xC854 == code || // Lo       HANGUL SYLLABLE JYE
          0xC870 == code || // Lo       HANGUL SYLLABLE JO
          0xC88C == code || // Lo       HANGUL SYLLABLE JWA
          0xC8A8 == code || // Lo       HANGUL SYLLABLE JWAE
          0xC8C4 == code || // Lo       HANGUL SYLLABLE JOE
          0xC8E0 == code || // Lo       HANGUL SYLLABLE JYO
          0xC8FC == code || // Lo       HANGUL SYLLABLE JU
          0xC918 == code || // Lo       HANGUL SYLLABLE JWEO
          0xC934 == code || // Lo       HANGUL SYLLABLE JWE
          0xC950 == code || // Lo       HANGUL SYLLABLE JWI
          0xC96C == code || // Lo       HANGUL SYLLABLE JYU
          0xC988 == code || // Lo       HANGUL SYLLABLE JEU
          0xC9A4 == code || // Lo       HANGUL SYLLABLE JYI
          0xC9C0 == code || // Lo       HANGUL SYLLABLE JI
          0xC9DC == code || // Lo       HANGUL SYLLABLE JJA
          0xC9F8 == code || // Lo       HANGUL SYLLABLE JJAE
          0xCA14 == code || // Lo       HANGUL SYLLABLE JJYA
          0xCA30 == code || // Lo       HANGUL SYLLABLE JJYAE
          0xCA4C == code || // Lo       HANGUL SYLLABLE JJEO
          0xCA68 == code || // Lo       HANGUL SYLLABLE JJE
          0xCA84 == code || // Lo       HANGUL SYLLABLE JJYEO
          0xCAA0 == code || // Lo       HANGUL SYLLABLE JJYE
          0xCABC == code || // Lo       HANGUL SYLLABLE JJO
          0xCAD8 == code || // Lo       HANGUL SYLLABLE JJWA
          0xCAF4 == code || // Lo       HANGUL SYLLABLE JJWAE
          0xCB10 == code || // Lo       HANGUL SYLLABLE JJOE
          0xCB2C == code || // Lo       HANGUL SYLLABLE JJYO
          0xCB48 == code || // Lo       HANGUL SYLLABLE JJU
          0xCB64 == code || // Lo       HANGUL SYLLABLE JJWEO
          0xCB80 == code || // Lo       HANGUL SYLLABLE JJWE
          0xCB9C == code || // Lo       HANGUL SYLLABLE JJWI
          0xCBB8 == code || // Lo       HANGUL SYLLABLE JJYU
          0xCBD4 == code || // Lo       HANGUL SYLLABLE JJEU
          0xCBF0 == code || // Lo       HANGUL SYLLABLE JJYI
          0xCC0C == code || // Lo       HANGUL SYLLABLE JJI
          0xCC28 == code || // Lo       HANGUL SYLLABLE CA
          0xCC44 == code || // Lo       HANGUL SYLLABLE CAE
          0xCC60 == code || // Lo       HANGUL SYLLABLE CYA
          0xCC7C == code || // Lo       HANGUL SYLLABLE CYAE
          0xCC98 == code || // Lo       HANGUL SYLLABLE CEO
          0xCCB4 == code || // Lo       HANGUL SYLLABLE CE
          0xCCD0 == code || // Lo       HANGUL SYLLABLE CYEO
          0xCCEC == code || // Lo       HANGUL SYLLABLE CYE
          0xCD08 == code || // Lo       HANGUL SYLLABLE CO
          0xCD24 == code || // Lo       HANGUL SYLLABLE CWA
          0xCD40 == code || // Lo       HANGUL SYLLABLE CWAE
          0xCD5C == code || // Lo       HANGUL SYLLABLE COE
          0xCD78 == code || // Lo       HANGUL SYLLABLE CYO
          0xCD94 == code || // Lo       HANGUL SYLLABLE CU
          0xCDB0 == code || // Lo       HANGUL SYLLABLE CWEO
          0xCDCC == code || // Lo       HANGUL SYLLABLE CWE
          0xCDE8 == code || // Lo       HANGUL SYLLABLE CWI
          0xCE04 == code || // Lo       HANGUL SYLLABLE CYU
          0xCE20 == code || // Lo       HANGUL SYLLABLE CEU
          0xCE3C == code || // Lo       HANGUL SYLLABLE CYI
          0xCE58 == code || // Lo       HANGUL SYLLABLE CI
          0xCE74 == code || // Lo       HANGUL SYLLABLE KA
          0xCE90 == code || // Lo       HANGUL SYLLABLE KAE
          0xCEAC == code || // Lo       HANGUL SYLLABLE KYA
          0xCEC8 == code || // Lo       HANGUL SYLLABLE KYAE
          0xCEE4 == code || // Lo       HANGUL SYLLABLE KEO
          0xCF00 == code || // Lo       HANGUL SYLLABLE KE
          0xCF1C == code || // Lo       HANGUL SYLLABLE KYEO
          0xCF38 == code || // Lo       HANGUL SYLLABLE KYE
          0xCF54 == code || // Lo       HANGUL SYLLABLE KO
          0xCF70 == code || // Lo       HANGUL SYLLABLE KWA
          0xCF8C == code || // Lo       HANGUL SYLLABLE KWAE
          0xCFA8 == code || // Lo       HANGUL SYLLABLE KOE
          0xCFC4 == code || // Lo       HANGUL SYLLABLE KYO
          0xCFE0 == code || // Lo       HANGUL SYLLABLE KU
          0xCFFC == code || // Lo       HANGUL SYLLABLE KWEO
          0xD018 == code || // Lo       HANGUL SYLLABLE KWE
          0xD034 == code || // Lo       HANGUL SYLLABLE KWI
          0xD050 == code || // Lo       HANGUL SYLLABLE KYU
          0xD06C == code || // Lo       HANGUL SYLLABLE KEU
          0xD088 == code || // Lo       HANGUL SYLLABLE KYI
          0xD0A4 == code || // Lo       HANGUL SYLLABLE KI
          0xD0C0 == code || // Lo       HANGUL SYLLABLE TA
          0xD0DC == code || // Lo       HANGUL SYLLABLE TAE
          0xD0F8 == code || // Lo       HANGUL SYLLABLE TYA
          0xD114 == code || // Lo       HANGUL SYLLABLE TYAE
          0xD130 == code || // Lo       HANGUL SYLLABLE TEO
          0xD14C == code || // Lo       HANGUL SYLLABLE TE
          0xD168 == code || // Lo       HANGUL SYLLABLE TYEO
          0xD184 == code || // Lo       HANGUL SYLLABLE TYE
          0xD1A0 == code || // Lo       HANGUL SYLLABLE TO
          0xD1BC == code || // Lo       HANGUL SYLLABLE TWA
          0xD1D8 == code || // Lo       HANGUL SYLLABLE TWAE
          0xD1F4 == code || // Lo       HANGUL SYLLABLE TOE
          0xD210 == code || // Lo       HANGUL SYLLABLE TYO
          0xD22C == code || // Lo       HANGUL SYLLABLE TU
          0xD248 == code || // Lo       HANGUL SYLLABLE TWEO
          0xD264 == code || // Lo       HANGUL SYLLABLE TWE
          0xD280 == code || // Lo       HANGUL SYLLABLE TWI
          0xD29C == code || // Lo       HANGUL SYLLABLE TYU
          0xD2B8 == code || // Lo       HANGUL SYLLABLE TEU
          0xD2D4 == code || // Lo       HANGUL SYLLABLE TYI
          0xD2F0 == code || // Lo       HANGUL SYLLABLE TI
          0xD30C == code || // Lo       HANGUL SYLLABLE PA
          0xD328 == code || // Lo       HANGUL SYLLABLE PAE
          0xD344 == code || // Lo       HANGUL SYLLABLE PYA
          0xD360 == code || // Lo       HANGUL SYLLABLE PYAE
          0xD37C == code || // Lo       HANGUL SYLLABLE PEO
          0xD398 == code || // Lo       HANGUL SYLLABLE PE
          0xD3B4 == code || // Lo       HANGUL SYLLABLE PYEO
          0xD3D0 == code || // Lo       HANGUL SYLLABLE PYE
          0xD3EC == code || // Lo       HANGUL SYLLABLE PO
          0xD408 == code || // Lo       HANGUL SYLLABLE PWA
          0xD424 == code || // Lo       HANGUL SYLLABLE PWAE
          0xD440 == code || // Lo       HANGUL SYLLABLE POE
          0xD45C == code || // Lo       HANGUL SYLLABLE PYO
          0xD478 == code || // Lo       HANGUL SYLLABLE PU
          0xD494 == code || // Lo       HANGUL SYLLABLE PWEO
          0xD4B0 == code || // Lo       HANGUL SYLLABLE PWE
          0xD4CC == code || // Lo       HANGUL SYLLABLE PWI
          0xD4E8 == code || // Lo       HANGUL SYLLABLE PYU
          0xD504 == code || // Lo       HANGUL SYLLABLE PEU
          0xD520 == code || // Lo       HANGUL SYLLABLE PYI
          0xD53C == code || // Lo       HANGUL SYLLABLE PI
          0xD558 == code || // Lo       HANGUL SYLLABLE HA
          0xD574 == code || // Lo       HANGUL SYLLABLE HAE
          0xD590 == code || // Lo       HANGUL SYLLABLE HYA
          0xD5AC == code || // Lo       HANGUL SYLLABLE HYAE
          0xD5C8 == code || // Lo       HANGUL SYLLABLE HEO
          0xD5E4 == code || // Lo       HANGUL SYLLABLE HE
          0xD600 == code || // Lo       HANGUL SYLLABLE HYEO
          0xD61C == code || // Lo       HANGUL SYLLABLE HYE
          0xD638 == code || // Lo       HANGUL SYLLABLE HO
          0xD654 == code || // Lo       HANGUL SYLLABLE HWA
          0xD670 == code || // Lo       HANGUL SYLLABLE HWAE
          0xD68C == code || // Lo       HANGUL SYLLABLE HOE
          0xD6A8 == code || // Lo       HANGUL SYLLABLE HYO
          0xD6C4 == code || // Lo       HANGUL SYLLABLE HU
          0xD6E0 == code || // Lo       HANGUL SYLLABLE HWEO
          0xD6FC == code || // Lo       HANGUL SYLLABLE HWE
          0xD718 == code || // Lo       HANGUL SYLLABLE HWI
          0xD734 == code || // Lo       HANGUL SYLLABLE HYU
          0xD750 == code || // Lo       HANGUL SYLLABLE HEU
          0xD76C == code || // Lo       HANGUL SYLLABLE HYI
          0xD788 == code // Lo       HANGUL SYLLABLE HI
          ) {
              return LV;
            }

          if (0xAC01 <= code && code <= 0xAC1B || // Lo  [27] HANGUL SYLLABLE GAG..HANGUL SYLLABLE GAH
          0xAC1D <= code && code <= 0xAC37 || // Lo  [27] HANGUL SYLLABLE GAEG..HANGUL SYLLABLE GAEH
          0xAC39 <= code && code <= 0xAC53 || // Lo  [27] HANGUL SYLLABLE GYAG..HANGUL SYLLABLE GYAH
          0xAC55 <= code && code <= 0xAC6F || // Lo  [27] HANGUL SYLLABLE GYAEG..HANGUL SYLLABLE GYAEH
          0xAC71 <= code && code <= 0xAC8B || // Lo  [27] HANGUL SYLLABLE GEOG..HANGUL SYLLABLE GEOH
          0xAC8D <= code && code <= 0xACA7 || // Lo  [27] HANGUL SYLLABLE GEG..HANGUL SYLLABLE GEH
          0xACA9 <= code && code <= 0xACC3 || // Lo  [27] HANGUL SYLLABLE GYEOG..HANGUL SYLLABLE GYEOH
          0xACC5 <= code && code <= 0xACDF || // Lo  [27] HANGUL SYLLABLE GYEG..HANGUL SYLLABLE GYEH
          0xACE1 <= code && code <= 0xACFB || // Lo  [27] HANGUL SYLLABLE GOG..HANGUL SYLLABLE GOH
          0xACFD <= code && code <= 0xAD17 || // Lo  [27] HANGUL SYLLABLE GWAG..HANGUL SYLLABLE GWAH
          0xAD19 <= code && code <= 0xAD33 || // Lo  [27] HANGUL SYLLABLE GWAEG..HANGUL SYLLABLE GWAEH
          0xAD35 <= code && code <= 0xAD4F || // Lo  [27] HANGUL SYLLABLE GOEG..HANGUL SYLLABLE GOEH
          0xAD51 <= code && code <= 0xAD6B || // Lo  [27] HANGUL SYLLABLE GYOG..HANGUL SYLLABLE GYOH
          0xAD6D <= code && code <= 0xAD87 || // Lo  [27] HANGUL SYLLABLE GUG..HANGUL SYLLABLE GUH
          0xAD89 <= code && code <= 0xADA3 || // Lo  [27] HANGUL SYLLABLE GWEOG..HANGUL SYLLABLE GWEOH
          0xADA5 <= code && code <= 0xADBF || // Lo  [27] HANGUL SYLLABLE GWEG..HANGUL SYLLABLE GWEH
          0xADC1 <= code && code <= 0xADDB || // Lo  [27] HANGUL SYLLABLE GWIG..HANGUL SYLLABLE GWIH
          0xADDD <= code && code <= 0xADF7 || // Lo  [27] HANGUL SYLLABLE GYUG..HANGUL SYLLABLE GYUH
          0xADF9 <= code && code <= 0xAE13 || // Lo  [27] HANGUL SYLLABLE GEUG..HANGUL SYLLABLE GEUH
          0xAE15 <= code && code <= 0xAE2F || // Lo  [27] HANGUL SYLLABLE GYIG..HANGUL SYLLABLE GYIH
          0xAE31 <= code && code <= 0xAE4B || // Lo  [27] HANGUL SYLLABLE GIG..HANGUL SYLLABLE GIH
          0xAE4D <= code && code <= 0xAE67 || // Lo  [27] HANGUL SYLLABLE GGAG..HANGUL SYLLABLE GGAH
          0xAE69 <= code && code <= 0xAE83 || // Lo  [27] HANGUL SYLLABLE GGAEG..HANGUL SYLLABLE GGAEH
          0xAE85 <= code && code <= 0xAE9F || // Lo  [27] HANGUL SYLLABLE GGYAG..HANGUL SYLLABLE GGYAH
          0xAEA1 <= code && code <= 0xAEBB || // Lo  [27] HANGUL SYLLABLE GGYAEG..HANGUL SYLLABLE GGYAEH
          0xAEBD <= code && code <= 0xAED7 || // Lo  [27] HANGUL SYLLABLE GGEOG..HANGUL SYLLABLE GGEOH
          0xAED9 <= code && code <= 0xAEF3 || // Lo  [27] HANGUL SYLLABLE GGEG..HANGUL SYLLABLE GGEH
          0xAEF5 <= code && code <= 0xAF0F || // Lo  [27] HANGUL SYLLABLE GGYEOG..HANGUL SYLLABLE GGYEOH
          0xAF11 <= code && code <= 0xAF2B || // Lo  [27] HANGUL SYLLABLE GGYEG..HANGUL SYLLABLE GGYEH
          0xAF2D <= code && code <= 0xAF47 || // Lo  [27] HANGUL SYLLABLE GGOG..HANGUL SYLLABLE GGOH
          0xAF49 <= code && code <= 0xAF63 || // Lo  [27] HANGUL SYLLABLE GGWAG..HANGUL SYLLABLE GGWAH
          0xAF65 <= code && code <= 0xAF7F || // Lo  [27] HANGUL SYLLABLE GGWAEG..HANGUL SYLLABLE GGWAEH
          0xAF81 <= code && code <= 0xAF9B || // Lo  [27] HANGUL SYLLABLE GGOEG..HANGUL SYLLABLE GGOEH
          0xAF9D <= code && code <= 0xAFB7 || // Lo  [27] HANGUL SYLLABLE GGYOG..HANGUL SYLLABLE GGYOH
          0xAFB9 <= code && code <= 0xAFD3 || // Lo  [27] HANGUL SYLLABLE GGUG..HANGUL SYLLABLE GGUH
          0xAFD5 <= code && code <= 0xAFEF || // Lo  [27] HANGUL SYLLABLE GGWEOG..HANGUL SYLLABLE GGWEOH
          0xAFF1 <= code && code <= 0xB00B || // Lo  [27] HANGUL SYLLABLE GGWEG..HANGUL SYLLABLE GGWEH
          0xB00D <= code && code <= 0xB027 || // Lo  [27] HANGUL SYLLABLE GGWIG..HANGUL SYLLABLE GGWIH
          0xB029 <= code && code <= 0xB043 || // Lo  [27] HANGUL SYLLABLE GGYUG..HANGUL SYLLABLE GGYUH
          0xB045 <= code && code <= 0xB05F || // Lo  [27] HANGUL SYLLABLE GGEUG..HANGUL SYLLABLE GGEUH
          0xB061 <= code && code <= 0xB07B || // Lo  [27] HANGUL SYLLABLE GGYIG..HANGUL SYLLABLE GGYIH
          0xB07D <= code && code <= 0xB097 || // Lo  [27] HANGUL SYLLABLE GGIG..HANGUL SYLLABLE GGIH
          0xB099 <= code && code <= 0xB0B3 || // Lo  [27] HANGUL SYLLABLE NAG..HANGUL SYLLABLE NAH
          0xB0B5 <= code && code <= 0xB0CF || // Lo  [27] HANGUL SYLLABLE NAEG..HANGUL SYLLABLE NAEH
          0xB0D1 <= code && code <= 0xB0EB || // Lo  [27] HANGUL SYLLABLE NYAG..HANGUL SYLLABLE NYAH
          0xB0ED <= code && code <= 0xB107 || // Lo  [27] HANGUL SYLLABLE NYAEG..HANGUL SYLLABLE NYAEH
          0xB109 <= code && code <= 0xB123 || // Lo  [27] HANGUL SYLLABLE NEOG..HANGUL SYLLABLE NEOH
          0xB125 <= code && code <= 0xB13F || // Lo  [27] HANGUL SYLLABLE NEG..HANGUL SYLLABLE NEH
          0xB141 <= code && code <= 0xB15B || // Lo  [27] HANGUL SYLLABLE NYEOG..HANGUL SYLLABLE NYEOH
          0xB15D <= code && code <= 0xB177 || // Lo  [27] HANGUL SYLLABLE NYEG..HANGUL SYLLABLE NYEH
          0xB179 <= code && code <= 0xB193 || // Lo  [27] HANGUL SYLLABLE NOG..HANGUL SYLLABLE NOH
          0xB195 <= code && code <= 0xB1AF || // Lo  [27] HANGUL SYLLABLE NWAG..HANGUL SYLLABLE NWAH
          0xB1B1 <= code && code <= 0xB1CB || // Lo  [27] HANGUL SYLLABLE NWAEG..HANGUL SYLLABLE NWAEH
          0xB1CD <= code && code <= 0xB1E7 || // Lo  [27] HANGUL SYLLABLE NOEG..HANGUL SYLLABLE NOEH
          0xB1E9 <= code && code <= 0xB203 || // Lo  [27] HANGUL SYLLABLE NYOG..HANGUL SYLLABLE NYOH
          0xB205 <= code && code <= 0xB21F || // Lo  [27] HANGUL SYLLABLE NUG..HANGUL SYLLABLE NUH
          0xB221 <= code && code <= 0xB23B || // Lo  [27] HANGUL SYLLABLE NWEOG..HANGUL SYLLABLE NWEOH
          0xB23D <= code && code <= 0xB257 || // Lo  [27] HANGUL SYLLABLE NWEG..HANGUL SYLLABLE NWEH
          0xB259 <= code && code <= 0xB273 || // Lo  [27] HANGUL SYLLABLE NWIG..HANGUL SYLLABLE NWIH
          0xB275 <= code && code <= 0xB28F || // Lo  [27] HANGUL SYLLABLE NYUG..HANGUL SYLLABLE NYUH
          0xB291 <= code && code <= 0xB2AB || // Lo  [27] HANGUL SYLLABLE NEUG..HANGUL SYLLABLE NEUH
          0xB2AD <= code && code <= 0xB2C7 || // Lo  [27] HANGUL SYLLABLE NYIG..HANGUL SYLLABLE NYIH
          0xB2C9 <= code && code <= 0xB2E3 || // Lo  [27] HANGUL SYLLABLE NIG..HANGUL SYLLABLE NIH
          0xB2E5 <= code && code <= 0xB2FF || // Lo  [27] HANGUL SYLLABLE DAG..HANGUL SYLLABLE DAH
          0xB301 <= code && code <= 0xB31B || // Lo  [27] HANGUL SYLLABLE DAEG..HANGUL SYLLABLE DAEH
          0xB31D <= code && code <= 0xB337 || // Lo  [27] HANGUL SYLLABLE DYAG..HANGUL SYLLABLE DYAH
          0xB339 <= code && code <= 0xB353 || // Lo  [27] HANGUL SYLLABLE DYAEG..HANGUL SYLLABLE DYAEH
          0xB355 <= code && code <= 0xB36F || // Lo  [27] HANGUL SYLLABLE DEOG..HANGUL SYLLABLE DEOH
          0xB371 <= code && code <= 0xB38B || // Lo  [27] HANGUL SYLLABLE DEG..HANGUL SYLLABLE DEH
          0xB38D <= code && code <= 0xB3A7 || // Lo  [27] HANGUL SYLLABLE DYEOG..HANGUL SYLLABLE DYEOH
          0xB3A9 <= code && code <= 0xB3C3 || // Lo  [27] HANGUL SYLLABLE DYEG..HANGUL SYLLABLE DYEH
          0xB3C5 <= code && code <= 0xB3DF || // Lo  [27] HANGUL SYLLABLE DOG..HANGUL SYLLABLE DOH
          0xB3E1 <= code && code <= 0xB3FB || // Lo  [27] HANGUL SYLLABLE DWAG..HANGUL SYLLABLE DWAH
          0xB3FD <= code && code <= 0xB417 || // Lo  [27] HANGUL SYLLABLE DWAEG..HANGUL SYLLABLE DWAEH
          0xB419 <= code && code <= 0xB433 || // Lo  [27] HANGUL SYLLABLE DOEG..HANGUL SYLLABLE DOEH
          0xB435 <= code && code <= 0xB44F || // Lo  [27] HANGUL SYLLABLE DYOG..HANGUL SYLLABLE DYOH
          0xB451 <= code && code <= 0xB46B || // Lo  [27] HANGUL SYLLABLE DUG..HANGUL SYLLABLE DUH
          0xB46D <= code && code <= 0xB487 || // Lo  [27] HANGUL SYLLABLE DWEOG..HANGUL SYLLABLE DWEOH
          0xB489 <= code && code <= 0xB4A3 || // Lo  [27] HANGUL SYLLABLE DWEG..HANGUL SYLLABLE DWEH
          0xB4A5 <= code && code <= 0xB4BF || // Lo  [27] HANGUL SYLLABLE DWIG..HANGUL SYLLABLE DWIH
          0xB4C1 <= code && code <= 0xB4DB || // Lo  [27] HANGUL SYLLABLE DYUG..HANGUL SYLLABLE DYUH
          0xB4DD <= code && code <= 0xB4F7 || // Lo  [27] HANGUL SYLLABLE DEUG..HANGUL SYLLABLE DEUH
          0xB4F9 <= code && code <= 0xB513 || // Lo  [27] HANGUL SYLLABLE DYIG..HANGUL SYLLABLE DYIH
          0xB515 <= code && code <= 0xB52F || // Lo  [27] HANGUL SYLLABLE DIG..HANGUL SYLLABLE DIH
          0xB531 <= code && code <= 0xB54B || // Lo  [27] HANGUL SYLLABLE DDAG..HANGUL SYLLABLE DDAH
          0xB54D <= code && code <= 0xB567 || // Lo  [27] HANGUL SYLLABLE DDAEG..HANGUL SYLLABLE DDAEH
          0xB569 <= code && code <= 0xB583 || // Lo  [27] HANGUL SYLLABLE DDYAG..HANGUL SYLLABLE DDYAH
          0xB585 <= code && code <= 0xB59F || // Lo  [27] HANGUL SYLLABLE DDYAEG..HANGUL SYLLABLE DDYAEH
          0xB5A1 <= code && code <= 0xB5BB || // Lo  [27] HANGUL SYLLABLE DDEOG..HANGUL SYLLABLE DDEOH
          0xB5BD <= code && code <= 0xB5D7 || // Lo  [27] HANGUL SYLLABLE DDEG..HANGUL SYLLABLE DDEH
          0xB5D9 <= code && code <= 0xB5F3 || // Lo  [27] HANGUL SYLLABLE DDYEOG..HANGUL SYLLABLE DDYEOH
          0xB5F5 <= code && code <= 0xB60F || // Lo  [27] HANGUL SYLLABLE DDYEG..HANGUL SYLLABLE DDYEH
          0xB611 <= code && code <= 0xB62B || // Lo  [27] HANGUL SYLLABLE DDOG..HANGUL SYLLABLE DDOH
          0xB62D <= code && code <= 0xB647 || // Lo  [27] HANGUL SYLLABLE DDWAG..HANGUL SYLLABLE DDWAH
          0xB649 <= code && code <= 0xB663 || // Lo  [27] HANGUL SYLLABLE DDWAEG..HANGUL SYLLABLE DDWAEH
          0xB665 <= code && code <= 0xB67F || // Lo  [27] HANGUL SYLLABLE DDOEG..HANGUL SYLLABLE DDOEH
          0xB681 <= code && code <= 0xB69B || // Lo  [27] HANGUL SYLLABLE DDYOG..HANGUL SYLLABLE DDYOH
          0xB69D <= code && code <= 0xB6B7 || // Lo  [27] HANGUL SYLLABLE DDUG..HANGUL SYLLABLE DDUH
          0xB6B9 <= code && code <= 0xB6D3 || // Lo  [27] HANGUL SYLLABLE DDWEOG..HANGUL SYLLABLE DDWEOH
          0xB6D5 <= code && code <= 0xB6EF || // Lo  [27] HANGUL SYLLABLE DDWEG..HANGUL SYLLABLE DDWEH
          0xB6F1 <= code && code <= 0xB70B || // Lo  [27] HANGUL SYLLABLE DDWIG..HANGUL SYLLABLE DDWIH
          0xB70D <= code && code <= 0xB727 || // Lo  [27] HANGUL SYLLABLE DDYUG..HANGUL SYLLABLE DDYUH
          0xB729 <= code && code <= 0xB743 || // Lo  [27] HANGUL SYLLABLE DDEUG..HANGUL SYLLABLE DDEUH
          0xB745 <= code && code <= 0xB75F || // Lo  [27] HANGUL SYLLABLE DDYIG..HANGUL SYLLABLE DDYIH
          0xB761 <= code && code <= 0xB77B || // Lo  [27] HANGUL SYLLABLE DDIG..HANGUL SYLLABLE DDIH
          0xB77D <= code && code <= 0xB797 || // Lo  [27] HANGUL SYLLABLE RAG..HANGUL SYLLABLE RAH
          0xB799 <= code && code <= 0xB7B3 || // Lo  [27] HANGUL SYLLABLE RAEG..HANGUL SYLLABLE RAEH
          0xB7B5 <= code && code <= 0xB7CF || // Lo  [27] HANGUL SYLLABLE RYAG..HANGUL SYLLABLE RYAH
          0xB7D1 <= code && code <= 0xB7EB || // Lo  [27] HANGUL SYLLABLE RYAEG..HANGUL SYLLABLE RYAEH
          0xB7ED <= code && code <= 0xB807 || // Lo  [27] HANGUL SYLLABLE REOG..HANGUL SYLLABLE REOH
          0xB809 <= code && code <= 0xB823 || // Lo  [27] HANGUL SYLLABLE REG..HANGUL SYLLABLE REH
          0xB825 <= code && code <= 0xB83F || // Lo  [27] HANGUL SYLLABLE RYEOG..HANGUL SYLLABLE RYEOH
          0xB841 <= code && code <= 0xB85B || // Lo  [27] HANGUL SYLLABLE RYEG..HANGUL SYLLABLE RYEH
          0xB85D <= code && code <= 0xB877 || // Lo  [27] HANGUL SYLLABLE ROG..HANGUL SYLLABLE ROH
          0xB879 <= code && code <= 0xB893 || // Lo  [27] HANGUL SYLLABLE RWAG..HANGUL SYLLABLE RWAH
          0xB895 <= code && code <= 0xB8AF || // Lo  [27] HANGUL SYLLABLE RWAEG..HANGUL SYLLABLE RWAEH
          0xB8B1 <= code && code <= 0xB8CB || // Lo  [27] HANGUL SYLLABLE ROEG..HANGUL SYLLABLE ROEH
          0xB8CD <= code && code <= 0xB8E7 || // Lo  [27] HANGUL SYLLABLE RYOG..HANGUL SYLLABLE RYOH
          0xB8E9 <= code && code <= 0xB903 || // Lo  [27] HANGUL SYLLABLE RUG..HANGUL SYLLABLE RUH
          0xB905 <= code && code <= 0xB91F || // Lo  [27] HANGUL SYLLABLE RWEOG..HANGUL SYLLABLE RWEOH
          0xB921 <= code && code <= 0xB93B || // Lo  [27] HANGUL SYLLABLE RWEG..HANGUL SYLLABLE RWEH
          0xB93D <= code && code <= 0xB957 || // Lo  [27] HANGUL SYLLABLE RWIG..HANGUL SYLLABLE RWIH
          0xB959 <= code && code <= 0xB973 || // Lo  [27] HANGUL SYLLABLE RYUG..HANGUL SYLLABLE RYUH
          0xB975 <= code && code <= 0xB98F || // Lo  [27] HANGUL SYLLABLE REUG..HANGUL SYLLABLE REUH
          0xB991 <= code && code <= 0xB9AB || // Lo  [27] HANGUL SYLLABLE RYIG..HANGUL SYLLABLE RYIH
          0xB9AD <= code && code <= 0xB9C7 || // Lo  [27] HANGUL SYLLABLE RIG..HANGUL SYLLABLE RIH
          0xB9C9 <= code && code <= 0xB9E3 || // Lo  [27] HANGUL SYLLABLE MAG..HANGUL SYLLABLE MAH
          0xB9E5 <= code && code <= 0xB9FF || // Lo  [27] HANGUL SYLLABLE MAEG..HANGUL SYLLABLE MAEH
          0xBA01 <= code && code <= 0xBA1B || // Lo  [27] HANGUL SYLLABLE MYAG..HANGUL SYLLABLE MYAH
          0xBA1D <= code && code <= 0xBA37 || // Lo  [27] HANGUL SYLLABLE MYAEG..HANGUL SYLLABLE MYAEH
          0xBA39 <= code && code <= 0xBA53 || // Lo  [27] HANGUL SYLLABLE MEOG..HANGUL SYLLABLE MEOH
          0xBA55 <= code && code <= 0xBA6F || // Lo  [27] HANGUL SYLLABLE MEG..HANGUL SYLLABLE MEH
          0xBA71 <= code && code <= 0xBA8B || // Lo  [27] HANGUL SYLLABLE MYEOG..HANGUL SYLLABLE MYEOH
          0xBA8D <= code && code <= 0xBAA7 || // Lo  [27] HANGUL SYLLABLE MYEG..HANGUL SYLLABLE MYEH
          0xBAA9 <= code && code <= 0xBAC3 || // Lo  [27] HANGUL SYLLABLE MOG..HANGUL SYLLABLE MOH
          0xBAC5 <= code && code <= 0xBADF || // Lo  [27] HANGUL SYLLABLE MWAG..HANGUL SYLLABLE MWAH
          0xBAE1 <= code && code <= 0xBAFB || // Lo  [27] HANGUL SYLLABLE MWAEG..HANGUL SYLLABLE MWAEH
          0xBAFD <= code && code <= 0xBB17 || // Lo  [27] HANGUL SYLLABLE MOEG..HANGUL SYLLABLE MOEH
          0xBB19 <= code && code <= 0xBB33 || // Lo  [27] HANGUL SYLLABLE MYOG..HANGUL SYLLABLE MYOH
          0xBB35 <= code && code <= 0xBB4F || // Lo  [27] HANGUL SYLLABLE MUG..HANGUL SYLLABLE MUH
          0xBB51 <= code && code <= 0xBB6B || // Lo  [27] HANGUL SYLLABLE MWEOG..HANGUL SYLLABLE MWEOH
          0xBB6D <= code && code <= 0xBB87 || // Lo  [27] HANGUL SYLLABLE MWEG..HANGUL SYLLABLE MWEH
          0xBB89 <= code && code <= 0xBBA3 || // Lo  [27] HANGUL SYLLABLE MWIG..HANGUL SYLLABLE MWIH
          0xBBA5 <= code && code <= 0xBBBF || // Lo  [27] HANGUL SYLLABLE MYUG..HANGUL SYLLABLE MYUH
          0xBBC1 <= code && code <= 0xBBDB || // Lo  [27] HANGUL SYLLABLE MEUG..HANGUL SYLLABLE MEUH
          0xBBDD <= code && code <= 0xBBF7 || // Lo  [27] HANGUL SYLLABLE MYIG..HANGUL SYLLABLE MYIH
          0xBBF9 <= code && code <= 0xBC13 || // Lo  [27] HANGUL SYLLABLE MIG..HANGUL SYLLABLE MIH
          0xBC15 <= code && code <= 0xBC2F || // Lo  [27] HANGUL SYLLABLE BAG..HANGUL SYLLABLE BAH
          0xBC31 <= code && code <= 0xBC4B || // Lo  [27] HANGUL SYLLABLE BAEG..HANGUL SYLLABLE BAEH
          0xBC4D <= code && code <= 0xBC67 || // Lo  [27] HANGUL SYLLABLE BYAG..HANGUL SYLLABLE BYAH
          0xBC69 <= code && code <= 0xBC83 || // Lo  [27] HANGUL SYLLABLE BYAEG..HANGUL SYLLABLE BYAEH
          0xBC85 <= code && code <= 0xBC9F || // Lo  [27] HANGUL SYLLABLE BEOG..HANGUL SYLLABLE BEOH
          0xBCA1 <= code && code <= 0xBCBB || // Lo  [27] HANGUL SYLLABLE BEG..HANGUL SYLLABLE BEH
          0xBCBD <= code && code <= 0xBCD7 || // Lo  [27] HANGUL SYLLABLE BYEOG..HANGUL SYLLABLE BYEOH
          0xBCD9 <= code && code <= 0xBCF3 || // Lo  [27] HANGUL SYLLABLE BYEG..HANGUL SYLLABLE BYEH
          0xBCF5 <= code && code <= 0xBD0F || // Lo  [27] HANGUL SYLLABLE BOG..HANGUL SYLLABLE BOH
          0xBD11 <= code && code <= 0xBD2B || // Lo  [27] HANGUL SYLLABLE BWAG..HANGUL SYLLABLE BWAH
          0xBD2D <= code && code <= 0xBD47 || // Lo  [27] HANGUL SYLLABLE BWAEG..HANGUL SYLLABLE BWAEH
          0xBD49 <= code && code <= 0xBD63 || // Lo  [27] HANGUL SYLLABLE BOEG..HANGUL SYLLABLE BOEH
          0xBD65 <= code && code <= 0xBD7F || // Lo  [27] HANGUL SYLLABLE BYOG..HANGUL SYLLABLE BYOH
          0xBD81 <= code && code <= 0xBD9B || // Lo  [27] HANGUL SYLLABLE BUG..HANGUL SYLLABLE BUH
          0xBD9D <= code && code <= 0xBDB7 || // Lo  [27] HANGUL SYLLABLE BWEOG..HANGUL SYLLABLE BWEOH
          0xBDB9 <= code && code <= 0xBDD3 || // Lo  [27] HANGUL SYLLABLE BWEG..HANGUL SYLLABLE BWEH
          0xBDD5 <= code && code <= 0xBDEF || // Lo  [27] HANGUL SYLLABLE BWIG..HANGUL SYLLABLE BWIH
          0xBDF1 <= code && code <= 0xBE0B || // Lo  [27] HANGUL SYLLABLE BYUG..HANGUL SYLLABLE BYUH
          0xBE0D <= code && code <= 0xBE27 || // Lo  [27] HANGUL SYLLABLE BEUG..HANGUL SYLLABLE BEUH
          0xBE29 <= code && code <= 0xBE43 || // Lo  [27] HANGUL SYLLABLE BYIG..HANGUL SYLLABLE BYIH
          0xBE45 <= code && code <= 0xBE5F || // Lo  [27] HANGUL SYLLABLE BIG..HANGUL SYLLABLE BIH
          0xBE61 <= code && code <= 0xBE7B || // Lo  [27] HANGUL SYLLABLE BBAG..HANGUL SYLLABLE BBAH
          0xBE7D <= code && code <= 0xBE97 || // Lo  [27] HANGUL SYLLABLE BBAEG..HANGUL SYLLABLE BBAEH
          0xBE99 <= code && code <= 0xBEB3 || // Lo  [27] HANGUL SYLLABLE BBYAG..HANGUL SYLLABLE BBYAH
          0xBEB5 <= code && code <= 0xBECF || // Lo  [27] HANGUL SYLLABLE BBYAEG..HANGUL SYLLABLE BBYAEH
          0xBED1 <= code && code <= 0xBEEB || // Lo  [27] HANGUL SYLLABLE BBEOG..HANGUL SYLLABLE BBEOH
          0xBEED <= code && code <= 0xBF07 || // Lo  [27] HANGUL SYLLABLE BBEG..HANGUL SYLLABLE BBEH
          0xBF09 <= code && code <= 0xBF23 || // Lo  [27] HANGUL SYLLABLE BBYEOG..HANGUL SYLLABLE BBYEOH
          0xBF25 <= code && code <= 0xBF3F || // Lo  [27] HANGUL SYLLABLE BBYEG..HANGUL SYLLABLE BBYEH
          0xBF41 <= code && code <= 0xBF5B || // Lo  [27] HANGUL SYLLABLE BBOG..HANGUL SYLLABLE BBOH
          0xBF5D <= code && code <= 0xBF77 || // Lo  [27] HANGUL SYLLABLE BBWAG..HANGUL SYLLABLE BBWAH
          0xBF79 <= code && code <= 0xBF93 || // Lo  [27] HANGUL SYLLABLE BBWAEG..HANGUL SYLLABLE BBWAEH
          0xBF95 <= code && code <= 0xBFAF || // Lo  [27] HANGUL SYLLABLE BBOEG..HANGUL SYLLABLE BBOEH
          0xBFB1 <= code && code <= 0xBFCB || // Lo  [27] HANGUL SYLLABLE BBYOG..HANGUL SYLLABLE BBYOH
          0xBFCD <= code && code <= 0xBFE7 || // Lo  [27] HANGUL SYLLABLE BBUG..HANGUL SYLLABLE BBUH
          0xBFE9 <= code && code <= 0xC003 || // Lo  [27] HANGUL SYLLABLE BBWEOG..HANGUL SYLLABLE BBWEOH
          0xC005 <= code && code <= 0xC01F || // Lo  [27] HANGUL SYLLABLE BBWEG..HANGUL SYLLABLE BBWEH
          0xC021 <= code && code <= 0xC03B || // Lo  [27] HANGUL SYLLABLE BBWIG..HANGUL SYLLABLE BBWIH
          0xC03D <= code && code <= 0xC057 || // Lo  [27] HANGUL SYLLABLE BBYUG..HANGUL SYLLABLE BBYUH
          0xC059 <= code && code <= 0xC073 || // Lo  [27] HANGUL SYLLABLE BBEUG..HANGUL SYLLABLE BBEUH
          0xC075 <= code && code <= 0xC08F || // Lo  [27] HANGUL SYLLABLE BBYIG..HANGUL SYLLABLE BBYIH
          0xC091 <= code && code <= 0xC0AB || // Lo  [27] HANGUL SYLLABLE BBIG..HANGUL SYLLABLE BBIH
          0xC0AD <= code && code <= 0xC0C7 || // Lo  [27] HANGUL SYLLABLE SAG..HANGUL SYLLABLE SAH
          0xC0C9 <= code && code <= 0xC0E3 || // Lo  [27] HANGUL SYLLABLE SAEG..HANGUL SYLLABLE SAEH
          0xC0E5 <= code && code <= 0xC0FF || // Lo  [27] HANGUL SYLLABLE SYAG..HANGUL SYLLABLE SYAH
          0xC101 <= code && code <= 0xC11B || // Lo  [27] HANGUL SYLLABLE SYAEG..HANGUL SYLLABLE SYAEH
          0xC11D <= code && code <= 0xC137 || // Lo  [27] HANGUL SYLLABLE SEOG..HANGUL SYLLABLE SEOH
          0xC139 <= code && code <= 0xC153 || // Lo  [27] HANGUL SYLLABLE SEG..HANGUL SYLLABLE SEH
          0xC155 <= code && code <= 0xC16F || // Lo  [27] HANGUL SYLLABLE SYEOG..HANGUL SYLLABLE SYEOH
          0xC171 <= code && code <= 0xC18B || // Lo  [27] HANGUL SYLLABLE SYEG..HANGUL SYLLABLE SYEH
          0xC18D <= code && code <= 0xC1A7 || // Lo  [27] HANGUL SYLLABLE SOG..HANGUL SYLLABLE SOH
          0xC1A9 <= code && code <= 0xC1C3 || // Lo  [27] HANGUL SYLLABLE SWAG..HANGUL SYLLABLE SWAH
          0xC1C5 <= code && code <= 0xC1DF || // Lo  [27] HANGUL SYLLABLE SWAEG..HANGUL SYLLABLE SWAEH
          0xC1E1 <= code && code <= 0xC1FB || // Lo  [27] HANGUL SYLLABLE SOEG..HANGUL SYLLABLE SOEH
          0xC1FD <= code && code <= 0xC217 || // Lo  [27] HANGUL SYLLABLE SYOG..HANGUL SYLLABLE SYOH
          0xC219 <= code && code <= 0xC233 || // Lo  [27] HANGUL SYLLABLE SUG..HANGUL SYLLABLE SUH
          0xC235 <= code && code <= 0xC24F || // Lo  [27] HANGUL SYLLABLE SWEOG..HANGUL SYLLABLE SWEOH
          0xC251 <= code && code <= 0xC26B || // Lo  [27] HANGUL SYLLABLE SWEG..HANGUL SYLLABLE SWEH
          0xC26D <= code && code <= 0xC287 || // Lo  [27] HANGUL SYLLABLE SWIG..HANGUL SYLLABLE SWIH
          0xC289 <= code && code <= 0xC2A3 || // Lo  [27] HANGUL SYLLABLE SYUG..HANGUL SYLLABLE SYUH
          0xC2A5 <= code && code <= 0xC2BF || // Lo  [27] HANGUL SYLLABLE SEUG..HANGUL SYLLABLE SEUH
          0xC2C1 <= code && code <= 0xC2DB || // Lo  [27] HANGUL SYLLABLE SYIG..HANGUL SYLLABLE SYIH
          0xC2DD <= code && code <= 0xC2F7 || // Lo  [27] HANGUL SYLLABLE SIG..HANGUL SYLLABLE SIH
          0xC2F9 <= code && code <= 0xC313 || // Lo  [27] HANGUL SYLLABLE SSAG..HANGUL SYLLABLE SSAH
          0xC315 <= code && code <= 0xC32F || // Lo  [27] HANGUL SYLLABLE SSAEG..HANGUL SYLLABLE SSAEH
          0xC331 <= code && code <= 0xC34B || // Lo  [27] HANGUL SYLLABLE SSYAG..HANGUL SYLLABLE SSYAH
          0xC34D <= code && code <= 0xC367 || // Lo  [27] HANGUL SYLLABLE SSYAEG..HANGUL SYLLABLE SSYAEH
          0xC369 <= code && code <= 0xC383 || // Lo  [27] HANGUL SYLLABLE SSEOG..HANGUL SYLLABLE SSEOH
          0xC385 <= code && code <= 0xC39F || // Lo  [27] HANGUL SYLLABLE SSEG..HANGUL SYLLABLE SSEH
          0xC3A1 <= code && code <= 0xC3BB || // Lo  [27] HANGUL SYLLABLE SSYEOG..HANGUL SYLLABLE SSYEOH
          0xC3BD <= code && code <= 0xC3D7 || // Lo  [27] HANGUL SYLLABLE SSYEG..HANGUL SYLLABLE SSYEH
          0xC3D9 <= code && code <= 0xC3F3 || // Lo  [27] HANGUL SYLLABLE SSOG..HANGUL SYLLABLE SSOH
          0xC3F5 <= code && code <= 0xC40F || // Lo  [27] HANGUL SYLLABLE SSWAG..HANGUL SYLLABLE SSWAH
          0xC411 <= code && code <= 0xC42B || // Lo  [27] HANGUL SYLLABLE SSWAEG..HANGUL SYLLABLE SSWAEH
          0xC42D <= code && code <= 0xC447 || // Lo  [27] HANGUL SYLLABLE SSOEG..HANGUL SYLLABLE SSOEH
          0xC449 <= code && code <= 0xC463 || // Lo  [27] HANGUL SYLLABLE SSYOG..HANGUL SYLLABLE SSYOH
          0xC465 <= code && code <= 0xC47F || // Lo  [27] HANGUL SYLLABLE SSUG..HANGUL SYLLABLE SSUH
          0xC481 <= code && code <= 0xC49B || // Lo  [27] HANGUL SYLLABLE SSWEOG..HANGUL SYLLABLE SSWEOH
          0xC49D <= code && code <= 0xC4B7 || // Lo  [27] HANGUL SYLLABLE SSWEG..HANGUL SYLLABLE SSWEH
          0xC4B9 <= code && code <= 0xC4D3 || // Lo  [27] HANGUL SYLLABLE SSWIG..HANGUL SYLLABLE SSWIH
          0xC4D5 <= code && code <= 0xC4EF || // Lo  [27] HANGUL SYLLABLE SSYUG..HANGUL SYLLABLE SSYUH
          0xC4F1 <= code && code <= 0xC50B || // Lo  [27] HANGUL SYLLABLE SSEUG..HANGUL SYLLABLE SSEUH
          0xC50D <= code && code <= 0xC527 || // Lo  [27] HANGUL SYLLABLE SSYIG..HANGUL SYLLABLE SSYIH
          0xC529 <= code && code <= 0xC543 || // Lo  [27] HANGUL SYLLABLE SSIG..HANGUL SYLLABLE SSIH
          0xC545 <= code && code <= 0xC55F || // Lo  [27] HANGUL SYLLABLE AG..HANGUL SYLLABLE AH
          0xC561 <= code && code <= 0xC57B || // Lo  [27] HANGUL SYLLABLE AEG..HANGUL SYLLABLE AEH
          0xC57D <= code && code <= 0xC597 || // Lo  [27] HANGUL SYLLABLE YAG..HANGUL SYLLABLE YAH
          0xC599 <= code && code <= 0xC5B3 || // Lo  [27] HANGUL SYLLABLE YAEG..HANGUL SYLLABLE YAEH
          0xC5B5 <= code && code <= 0xC5CF || // Lo  [27] HANGUL SYLLABLE EOG..HANGUL SYLLABLE EOH
          0xC5D1 <= code && code <= 0xC5EB || // Lo  [27] HANGUL SYLLABLE EG..HANGUL SYLLABLE EH
          0xC5ED <= code && code <= 0xC607 || // Lo  [27] HANGUL SYLLABLE YEOG..HANGUL SYLLABLE YEOH
          0xC609 <= code && code <= 0xC623 || // Lo  [27] HANGUL SYLLABLE YEG..HANGUL SYLLABLE YEH
          0xC625 <= code && code <= 0xC63F || // Lo  [27] HANGUL SYLLABLE OG..HANGUL SYLLABLE OH
          0xC641 <= code && code <= 0xC65B || // Lo  [27] HANGUL SYLLABLE WAG..HANGUL SYLLABLE WAH
          0xC65D <= code && code <= 0xC677 || // Lo  [27] HANGUL SYLLABLE WAEG..HANGUL SYLLABLE WAEH
          0xC679 <= code && code <= 0xC693 || // Lo  [27] HANGUL SYLLABLE OEG..HANGUL SYLLABLE OEH
          0xC695 <= code && code <= 0xC6AF || // Lo  [27] HANGUL SYLLABLE YOG..HANGUL SYLLABLE YOH
          0xC6B1 <= code && code <= 0xC6CB || // Lo  [27] HANGUL SYLLABLE UG..HANGUL SYLLABLE UH
          0xC6CD <= code && code <= 0xC6E7 || // Lo  [27] HANGUL SYLLABLE WEOG..HANGUL SYLLABLE WEOH
          0xC6E9 <= code && code <= 0xC703 || // Lo  [27] HANGUL SYLLABLE WEG..HANGUL SYLLABLE WEH
          0xC705 <= code && code <= 0xC71F || // Lo  [27] HANGUL SYLLABLE WIG..HANGUL SYLLABLE WIH
          0xC721 <= code && code <= 0xC73B || // Lo  [27] HANGUL SYLLABLE YUG..HANGUL SYLLABLE YUH
          0xC73D <= code && code <= 0xC757 || // Lo  [27] HANGUL SYLLABLE EUG..HANGUL SYLLABLE EUH
          0xC759 <= code && code <= 0xC773 || // Lo  [27] HANGUL SYLLABLE YIG..HANGUL SYLLABLE YIH
          0xC775 <= code && code <= 0xC78F || // Lo  [27] HANGUL SYLLABLE IG..HANGUL SYLLABLE IH
          0xC791 <= code && code <= 0xC7AB || // Lo  [27] HANGUL SYLLABLE JAG..HANGUL SYLLABLE JAH
          0xC7AD <= code && code <= 0xC7C7 || // Lo  [27] HANGUL SYLLABLE JAEG..HANGUL SYLLABLE JAEH
          0xC7C9 <= code && code <= 0xC7E3 || // Lo  [27] HANGUL SYLLABLE JYAG..HANGUL SYLLABLE JYAH
          0xC7E5 <= code && code <= 0xC7FF || // Lo  [27] HANGUL SYLLABLE JYAEG..HANGUL SYLLABLE JYAEH
          0xC801 <= code && code <= 0xC81B || // Lo  [27] HANGUL SYLLABLE JEOG..HANGUL SYLLABLE JEOH
          0xC81D <= code && code <= 0xC837 || // Lo  [27] HANGUL SYLLABLE JEG..HANGUL SYLLABLE JEH
          0xC839 <= code && code <= 0xC853 || // Lo  [27] HANGUL SYLLABLE JYEOG..HANGUL SYLLABLE JYEOH
          0xC855 <= code && code <= 0xC86F || // Lo  [27] HANGUL SYLLABLE JYEG..HANGUL SYLLABLE JYEH
          0xC871 <= code && code <= 0xC88B || // Lo  [27] HANGUL SYLLABLE JOG..HANGUL SYLLABLE JOH
          0xC88D <= code && code <= 0xC8A7 || // Lo  [27] HANGUL SYLLABLE JWAG..HANGUL SYLLABLE JWAH
          0xC8A9 <= code && code <= 0xC8C3 || // Lo  [27] HANGUL SYLLABLE JWAEG..HANGUL SYLLABLE JWAEH
          0xC8C5 <= code && code <= 0xC8DF || // Lo  [27] HANGUL SYLLABLE JOEG..HANGUL SYLLABLE JOEH
          0xC8E1 <= code && code <= 0xC8FB || // Lo  [27] HANGUL SYLLABLE JYOG..HANGUL SYLLABLE JYOH
          0xC8FD <= code && code <= 0xC917 || // Lo  [27] HANGUL SYLLABLE JUG..HANGUL SYLLABLE JUH
          0xC919 <= code && code <= 0xC933 || // Lo  [27] HANGUL SYLLABLE JWEOG..HANGUL SYLLABLE JWEOH
          0xC935 <= code && code <= 0xC94F || // Lo  [27] HANGUL SYLLABLE JWEG..HANGUL SYLLABLE JWEH
          0xC951 <= code && code <= 0xC96B || // Lo  [27] HANGUL SYLLABLE JWIG..HANGUL SYLLABLE JWIH
          0xC96D <= code && code <= 0xC987 || // Lo  [27] HANGUL SYLLABLE JYUG..HANGUL SYLLABLE JYUH
          0xC989 <= code && code <= 0xC9A3 || // Lo  [27] HANGUL SYLLABLE JEUG..HANGUL SYLLABLE JEUH
          0xC9A5 <= code && code <= 0xC9BF || // Lo  [27] HANGUL SYLLABLE JYIG..HANGUL SYLLABLE JYIH
          0xC9C1 <= code && code <= 0xC9DB || // Lo  [27] HANGUL SYLLABLE JIG..HANGUL SYLLABLE JIH
          0xC9DD <= code && code <= 0xC9F7 || // Lo  [27] HANGUL SYLLABLE JJAG..HANGUL SYLLABLE JJAH
          0xC9F9 <= code && code <= 0xCA13 || // Lo  [27] HANGUL SYLLABLE JJAEG..HANGUL SYLLABLE JJAEH
          0xCA15 <= code && code <= 0xCA2F || // Lo  [27] HANGUL SYLLABLE JJYAG..HANGUL SYLLABLE JJYAH
          0xCA31 <= code && code <= 0xCA4B || // Lo  [27] HANGUL SYLLABLE JJYAEG..HANGUL SYLLABLE JJYAEH
          0xCA4D <= code && code <= 0xCA67 || // Lo  [27] HANGUL SYLLABLE JJEOG..HANGUL SYLLABLE JJEOH
          0xCA69 <= code && code <= 0xCA83 || // Lo  [27] HANGUL SYLLABLE JJEG..HANGUL SYLLABLE JJEH
          0xCA85 <= code && code <= 0xCA9F || // Lo  [27] HANGUL SYLLABLE JJYEOG..HANGUL SYLLABLE JJYEOH
          0xCAA1 <= code && code <= 0xCABB || // Lo  [27] HANGUL SYLLABLE JJYEG..HANGUL SYLLABLE JJYEH
          0xCABD <= code && code <= 0xCAD7 || // Lo  [27] HANGUL SYLLABLE JJOG..HANGUL SYLLABLE JJOH
          0xCAD9 <= code && code <= 0xCAF3 || // Lo  [27] HANGUL SYLLABLE JJWAG..HANGUL SYLLABLE JJWAH
          0xCAF5 <= code && code <= 0xCB0F || // Lo  [27] HANGUL SYLLABLE JJWAEG..HANGUL SYLLABLE JJWAEH
          0xCB11 <= code && code <= 0xCB2B || // Lo  [27] HANGUL SYLLABLE JJOEG..HANGUL SYLLABLE JJOEH
          0xCB2D <= code && code <= 0xCB47 || // Lo  [27] HANGUL SYLLABLE JJYOG..HANGUL SYLLABLE JJYOH
          0xCB49 <= code && code <= 0xCB63 || // Lo  [27] HANGUL SYLLABLE JJUG..HANGUL SYLLABLE JJUH
          0xCB65 <= code && code <= 0xCB7F || // Lo  [27] HANGUL SYLLABLE JJWEOG..HANGUL SYLLABLE JJWEOH
          0xCB81 <= code && code <= 0xCB9B || // Lo  [27] HANGUL SYLLABLE JJWEG..HANGUL SYLLABLE JJWEH
          0xCB9D <= code && code <= 0xCBB7 || // Lo  [27] HANGUL SYLLABLE JJWIG..HANGUL SYLLABLE JJWIH
          0xCBB9 <= code && code <= 0xCBD3 || // Lo  [27] HANGUL SYLLABLE JJYUG..HANGUL SYLLABLE JJYUH
          0xCBD5 <= code && code <= 0xCBEF || // Lo  [27] HANGUL SYLLABLE JJEUG..HANGUL SYLLABLE JJEUH
          0xCBF1 <= code && code <= 0xCC0B || // Lo  [27] HANGUL SYLLABLE JJYIG..HANGUL SYLLABLE JJYIH
          0xCC0D <= code && code <= 0xCC27 || // Lo  [27] HANGUL SYLLABLE JJIG..HANGUL SYLLABLE JJIH
          0xCC29 <= code && code <= 0xCC43 || // Lo  [27] HANGUL SYLLABLE CAG..HANGUL SYLLABLE CAH
          0xCC45 <= code && code <= 0xCC5F || // Lo  [27] HANGUL SYLLABLE CAEG..HANGUL SYLLABLE CAEH
          0xCC61 <= code && code <= 0xCC7B || // Lo  [27] HANGUL SYLLABLE CYAG..HANGUL SYLLABLE CYAH
          0xCC7D <= code && code <= 0xCC97 || // Lo  [27] HANGUL SYLLABLE CYAEG..HANGUL SYLLABLE CYAEH
          0xCC99 <= code && code <= 0xCCB3 || // Lo  [27] HANGUL SYLLABLE CEOG..HANGUL SYLLABLE CEOH
          0xCCB5 <= code && code <= 0xCCCF || // Lo  [27] HANGUL SYLLABLE CEG..HANGUL SYLLABLE CEH
          0xCCD1 <= code && code <= 0xCCEB || // Lo  [27] HANGUL SYLLABLE CYEOG..HANGUL SYLLABLE CYEOH
          0xCCED <= code && code <= 0xCD07 || // Lo  [27] HANGUL SYLLABLE CYEG..HANGUL SYLLABLE CYEH
          0xCD09 <= code && code <= 0xCD23 || // Lo  [27] HANGUL SYLLABLE COG..HANGUL SYLLABLE COH
          0xCD25 <= code && code <= 0xCD3F || // Lo  [27] HANGUL SYLLABLE CWAG..HANGUL SYLLABLE CWAH
          0xCD41 <= code && code <= 0xCD5B || // Lo  [27] HANGUL SYLLABLE CWAEG..HANGUL SYLLABLE CWAEH
          0xCD5D <= code && code <= 0xCD77 || // Lo  [27] HANGUL SYLLABLE COEG..HANGUL SYLLABLE COEH
          0xCD79 <= code && code <= 0xCD93 || // Lo  [27] HANGUL SYLLABLE CYOG..HANGUL SYLLABLE CYOH
          0xCD95 <= code && code <= 0xCDAF || // Lo  [27] HANGUL SYLLABLE CUG..HANGUL SYLLABLE CUH
          0xCDB1 <= code && code <= 0xCDCB || // Lo  [27] HANGUL SYLLABLE CWEOG..HANGUL SYLLABLE CWEOH
          0xCDCD <= code && code <= 0xCDE7 || // Lo  [27] HANGUL SYLLABLE CWEG..HANGUL SYLLABLE CWEH
          0xCDE9 <= code && code <= 0xCE03 || // Lo  [27] HANGUL SYLLABLE CWIG..HANGUL SYLLABLE CWIH
          0xCE05 <= code && code <= 0xCE1F || // Lo  [27] HANGUL SYLLABLE CYUG..HANGUL SYLLABLE CYUH
          0xCE21 <= code && code <= 0xCE3B || // Lo  [27] HANGUL SYLLABLE CEUG..HANGUL SYLLABLE CEUH
          0xCE3D <= code && code <= 0xCE57 || // Lo  [27] HANGUL SYLLABLE CYIG..HANGUL SYLLABLE CYIH
          0xCE59 <= code && code <= 0xCE73 || // Lo  [27] HANGUL SYLLABLE CIG..HANGUL SYLLABLE CIH
          0xCE75 <= code && code <= 0xCE8F || // Lo  [27] HANGUL SYLLABLE KAG..HANGUL SYLLABLE KAH
          0xCE91 <= code && code <= 0xCEAB || // Lo  [27] HANGUL SYLLABLE KAEG..HANGUL SYLLABLE KAEH
          0xCEAD <= code && code <= 0xCEC7 || // Lo  [27] HANGUL SYLLABLE KYAG..HANGUL SYLLABLE KYAH
          0xCEC9 <= code && code <= 0xCEE3 || // Lo  [27] HANGUL SYLLABLE KYAEG..HANGUL SYLLABLE KYAEH
          0xCEE5 <= code && code <= 0xCEFF || // Lo  [27] HANGUL SYLLABLE KEOG..HANGUL SYLLABLE KEOH
          0xCF01 <= code && code <= 0xCF1B || // Lo  [27] HANGUL SYLLABLE KEG..HANGUL SYLLABLE KEH
          0xCF1D <= code && code <= 0xCF37 || // Lo  [27] HANGUL SYLLABLE KYEOG..HANGUL SYLLABLE KYEOH
          0xCF39 <= code && code <= 0xCF53 || // Lo  [27] HANGUL SYLLABLE KYEG..HANGUL SYLLABLE KYEH
          0xCF55 <= code && code <= 0xCF6F || // Lo  [27] HANGUL SYLLABLE KOG..HANGUL SYLLABLE KOH
          0xCF71 <= code && code <= 0xCF8B || // Lo  [27] HANGUL SYLLABLE KWAG..HANGUL SYLLABLE KWAH
          0xCF8D <= code && code <= 0xCFA7 || // Lo  [27] HANGUL SYLLABLE KWAEG..HANGUL SYLLABLE KWAEH
          0xCFA9 <= code && code <= 0xCFC3 || // Lo  [27] HANGUL SYLLABLE KOEG..HANGUL SYLLABLE KOEH
          0xCFC5 <= code && code <= 0xCFDF || // Lo  [27] HANGUL SYLLABLE KYOG..HANGUL SYLLABLE KYOH
          0xCFE1 <= code && code <= 0xCFFB || // Lo  [27] HANGUL SYLLABLE KUG..HANGUL SYLLABLE KUH
          0xCFFD <= code && code <= 0xD017 || // Lo  [27] HANGUL SYLLABLE KWEOG..HANGUL SYLLABLE KWEOH
          0xD019 <= code && code <= 0xD033 || // Lo  [27] HANGUL SYLLABLE KWEG..HANGUL SYLLABLE KWEH
          0xD035 <= code && code <= 0xD04F || // Lo  [27] HANGUL SYLLABLE KWIG..HANGUL SYLLABLE KWIH
          0xD051 <= code && code <= 0xD06B || // Lo  [27] HANGUL SYLLABLE KYUG..HANGUL SYLLABLE KYUH
          0xD06D <= code && code <= 0xD087 || // Lo  [27] HANGUL SYLLABLE KEUG..HANGUL SYLLABLE KEUH
          0xD089 <= code && code <= 0xD0A3 || // Lo  [27] HANGUL SYLLABLE KYIG..HANGUL SYLLABLE KYIH
          0xD0A5 <= code && code <= 0xD0BF || // Lo  [27] HANGUL SYLLABLE KIG..HANGUL SYLLABLE KIH
          0xD0C1 <= code && code <= 0xD0DB || // Lo  [27] HANGUL SYLLABLE TAG..HANGUL SYLLABLE TAH
          0xD0DD <= code && code <= 0xD0F7 || // Lo  [27] HANGUL SYLLABLE TAEG..HANGUL SYLLABLE TAEH
          0xD0F9 <= code && code <= 0xD113 || // Lo  [27] HANGUL SYLLABLE TYAG..HANGUL SYLLABLE TYAH
          0xD115 <= code && code <= 0xD12F || // Lo  [27] HANGUL SYLLABLE TYAEG..HANGUL SYLLABLE TYAEH
          0xD131 <= code && code <= 0xD14B || // Lo  [27] HANGUL SYLLABLE TEOG..HANGUL SYLLABLE TEOH
          0xD14D <= code && code <= 0xD167 || // Lo  [27] HANGUL SYLLABLE TEG..HANGUL SYLLABLE TEH
          0xD169 <= code && code <= 0xD183 || // Lo  [27] HANGUL SYLLABLE TYEOG..HANGUL SYLLABLE TYEOH
          0xD185 <= code && code <= 0xD19F || // Lo  [27] HANGUL SYLLABLE TYEG..HANGUL SYLLABLE TYEH
          0xD1A1 <= code && code <= 0xD1BB || // Lo  [27] HANGUL SYLLABLE TOG..HANGUL SYLLABLE TOH
          0xD1BD <= code && code <= 0xD1D7 || // Lo  [27] HANGUL SYLLABLE TWAG..HANGUL SYLLABLE TWAH
          0xD1D9 <= code && code <= 0xD1F3 || // Lo  [27] HANGUL SYLLABLE TWAEG..HANGUL SYLLABLE TWAEH
          0xD1F5 <= code && code <= 0xD20F || // Lo  [27] HANGUL SYLLABLE TOEG..HANGUL SYLLABLE TOEH
          0xD211 <= code && code <= 0xD22B || // Lo  [27] HANGUL SYLLABLE TYOG..HANGUL SYLLABLE TYOH
          0xD22D <= code && code <= 0xD247 || // Lo  [27] HANGUL SYLLABLE TUG..HANGUL SYLLABLE TUH
          0xD249 <= code && code <= 0xD263 || // Lo  [27] HANGUL SYLLABLE TWEOG..HANGUL SYLLABLE TWEOH
          0xD265 <= code && code <= 0xD27F || // Lo  [27] HANGUL SYLLABLE TWEG..HANGUL SYLLABLE TWEH
          0xD281 <= code && code <= 0xD29B || // Lo  [27] HANGUL SYLLABLE TWIG..HANGUL SYLLABLE TWIH
          0xD29D <= code && code <= 0xD2B7 || // Lo  [27] HANGUL SYLLABLE TYUG..HANGUL SYLLABLE TYUH
          0xD2B9 <= code && code <= 0xD2D3 || // Lo  [27] HANGUL SYLLABLE TEUG..HANGUL SYLLABLE TEUH
          0xD2D5 <= code && code <= 0xD2EF || // Lo  [27] HANGUL SYLLABLE TYIG..HANGUL SYLLABLE TYIH
          0xD2F1 <= code && code <= 0xD30B || // Lo  [27] HANGUL SYLLABLE TIG..HANGUL SYLLABLE TIH
          0xD30D <= code && code <= 0xD327 || // Lo  [27] HANGUL SYLLABLE PAG..HANGUL SYLLABLE PAH
          0xD329 <= code && code <= 0xD343 || // Lo  [27] HANGUL SYLLABLE PAEG..HANGUL SYLLABLE PAEH
          0xD345 <= code && code <= 0xD35F || // Lo  [27] HANGUL SYLLABLE PYAG..HANGUL SYLLABLE PYAH
          0xD361 <= code && code <= 0xD37B || // Lo  [27] HANGUL SYLLABLE PYAEG..HANGUL SYLLABLE PYAEH
          0xD37D <= code && code <= 0xD397 || // Lo  [27] HANGUL SYLLABLE PEOG..HANGUL SYLLABLE PEOH
          0xD399 <= code && code <= 0xD3B3 || // Lo  [27] HANGUL SYLLABLE PEG..HANGUL SYLLABLE PEH
          0xD3B5 <= code && code <= 0xD3CF || // Lo  [27] HANGUL SYLLABLE PYEOG..HANGUL SYLLABLE PYEOH
          0xD3D1 <= code && code <= 0xD3EB || // Lo  [27] HANGUL SYLLABLE PYEG..HANGUL SYLLABLE PYEH
          0xD3ED <= code && code <= 0xD407 || // Lo  [27] HANGUL SYLLABLE POG..HANGUL SYLLABLE POH
          0xD409 <= code && code <= 0xD423 || // Lo  [27] HANGUL SYLLABLE PWAG..HANGUL SYLLABLE PWAH
          0xD425 <= code && code <= 0xD43F || // Lo  [27] HANGUL SYLLABLE PWAEG..HANGUL SYLLABLE PWAEH
          0xD441 <= code && code <= 0xD45B || // Lo  [27] HANGUL SYLLABLE POEG..HANGUL SYLLABLE POEH
          0xD45D <= code && code <= 0xD477 || // Lo  [27] HANGUL SYLLABLE PYOG..HANGUL SYLLABLE PYOH
          0xD479 <= code && code <= 0xD493 || // Lo  [27] HANGUL SYLLABLE PUG..HANGUL SYLLABLE PUH
          0xD495 <= code && code <= 0xD4AF || // Lo  [27] HANGUL SYLLABLE PWEOG..HANGUL SYLLABLE PWEOH
          0xD4B1 <= code && code <= 0xD4CB || // Lo  [27] HANGUL SYLLABLE PWEG..HANGUL SYLLABLE PWEH
          0xD4CD <= code && code <= 0xD4E7 || // Lo  [27] HANGUL SYLLABLE PWIG..HANGUL SYLLABLE PWIH
          0xD4E9 <= code && code <= 0xD503 || // Lo  [27] HANGUL SYLLABLE PYUG..HANGUL SYLLABLE PYUH
          0xD505 <= code && code <= 0xD51F || // Lo  [27] HANGUL SYLLABLE PEUG..HANGUL SYLLABLE PEUH
          0xD521 <= code && code <= 0xD53B || // Lo  [27] HANGUL SYLLABLE PYIG..HANGUL SYLLABLE PYIH
          0xD53D <= code && code <= 0xD557 || // Lo  [27] HANGUL SYLLABLE PIG..HANGUL SYLLABLE PIH
          0xD559 <= code && code <= 0xD573 || // Lo  [27] HANGUL SYLLABLE HAG..HANGUL SYLLABLE HAH
          0xD575 <= code && code <= 0xD58F || // Lo  [27] HANGUL SYLLABLE HAEG..HANGUL SYLLABLE HAEH
          0xD591 <= code && code <= 0xD5AB || // Lo  [27] HANGUL SYLLABLE HYAG..HANGUL SYLLABLE HYAH
          0xD5AD <= code && code <= 0xD5C7 || // Lo  [27] HANGUL SYLLABLE HYAEG..HANGUL SYLLABLE HYAEH
          0xD5C9 <= code && code <= 0xD5E3 || // Lo  [27] HANGUL SYLLABLE HEOG..HANGUL SYLLABLE HEOH
          0xD5E5 <= code && code <= 0xD5FF || // Lo  [27] HANGUL SYLLABLE HEG..HANGUL SYLLABLE HEH
          0xD601 <= code && code <= 0xD61B || // Lo  [27] HANGUL SYLLABLE HYEOG..HANGUL SYLLABLE HYEOH
          0xD61D <= code && code <= 0xD637 || // Lo  [27] HANGUL SYLLABLE HYEG..HANGUL SYLLABLE HYEH
          0xD639 <= code && code <= 0xD653 || // Lo  [27] HANGUL SYLLABLE HOG..HANGUL SYLLABLE HOH
          0xD655 <= code && code <= 0xD66F || // Lo  [27] HANGUL SYLLABLE HWAG..HANGUL SYLLABLE HWAH
          0xD671 <= code && code <= 0xD68B || // Lo  [27] HANGUL SYLLABLE HWAEG..HANGUL SYLLABLE HWAEH
          0xD68D <= code && code <= 0xD6A7 || // Lo  [27] HANGUL SYLLABLE HOEG..HANGUL SYLLABLE HOEH
          0xD6A9 <= code && code <= 0xD6C3 || // Lo  [27] HANGUL SYLLABLE HYOG..HANGUL SYLLABLE HYOH
          0xD6C5 <= code && code <= 0xD6DF || // Lo  [27] HANGUL SYLLABLE HUG..HANGUL SYLLABLE HUH
          0xD6E1 <= code && code <= 0xD6FB || // Lo  [27] HANGUL SYLLABLE HWEOG..HANGUL SYLLABLE HWEOH
          0xD6FD <= code && code <= 0xD717 || // Lo  [27] HANGUL SYLLABLE HWEG..HANGUL SYLLABLE HWEH
          0xD719 <= code && code <= 0xD733 || // Lo  [27] HANGUL SYLLABLE HWIG..HANGUL SYLLABLE HWIH
          0xD735 <= code && code <= 0xD74F || // Lo  [27] HANGUL SYLLABLE HYUG..HANGUL SYLLABLE HYUH
          0xD751 <= code && code <= 0xD76B || // Lo  [27] HANGUL SYLLABLE HEUG..HANGUL SYLLABLE HEUH
          0xD76D <= code && code <= 0xD787 || // Lo  [27] HANGUL SYLLABLE HYIG..HANGUL SYLLABLE HYIH
          0xD789 <= code && code <= 0xD7A3 // Lo  [27] HANGUL SYLLABLE HIG..HANGUL SYLLABLE HIH
          ) {
              return LVT;
            }

          if (0x261D == code || // So       WHITE UP POINTING INDEX
          0x26F9 == code || // So       PERSON WITH BALL
          0x270A <= code && code <= 0x270D || // So   [4] RAISED FIST..WRITING HAND
          0x1F385 == code || // So       FATHER CHRISTMAS
          0x1F3C2 <= code && code <= 0x1F3C4 || // So   [3] SNOWBOARDER..SURFER
          0x1F3C7 == code || // So       HORSE RACING
          0x1F3CA <= code && code <= 0x1F3CC || // So   [3] SWIMMER..GOLFER
          0x1F442 <= code && code <= 0x1F443 || // So   [2] EAR..NOSE
          0x1F446 <= code && code <= 0x1F450 || // So  [11] WHITE UP POINTING BACKHAND INDEX..OPEN HANDS SIGN
          0x1F46E == code || // So       POLICE OFFICER
          0x1F470 <= code && code <= 0x1F478 || // So   [9] BRIDE WITH VEIL..PRINCESS
          0x1F47C == code || // So       BABY ANGEL
          0x1F481 <= code && code <= 0x1F483 || // So   [3] INFORMATION DESK PERSON..DANCER
          0x1F485 <= code && code <= 0x1F487 || // So   [3] NAIL POLISH..HAIRCUT
          0x1F4AA == code || // So       FLEXED BICEPS
          0x1F574 <= code && code <= 0x1F575 || // So   [2] MAN IN BUSINESS SUIT LEVITATING..SLEUTH OR SPY
          0x1F57A == code || // So       MAN DANCING
          0x1F590 == code || // So       RAISED HAND WITH FINGERS SPLAYED
          0x1F595 <= code && code <= 0x1F596 || // So   [2] REVERSED HAND WITH MIDDLE FINGER EXTENDED..RAISED HAND WITH PART BETWEEN MIDDLE AND RING FINGERS
          0x1F645 <= code && code <= 0x1F647 || // So   [3] FACE WITH NO GOOD GESTURE..PERSON BOWING DEEPLY
          0x1F64B <= code && code <= 0x1F64F || // So   [5] HAPPY PERSON RAISING ONE HAND..PERSON WITH FOLDED HANDS
          0x1F6A3 == code || // So       ROWBOAT
          0x1F6B4 <= code && code <= 0x1F6B6 || // So   [3] BICYCLIST..PEDESTRIAN
          0x1F6C0 == code || // So       BATH
          0x1F6CC == code || // So       SLEEPING ACCOMMODATION
          0x1F918 <= code && code <= 0x1F91C || // So   [5] SIGN OF THE HORNS..RIGHT-FACING FIST
          0x1F91E <= code && code <= 0x1F91F || // So   [2] HAND WITH INDEX AND MIDDLE FINGERS CROSSED..I LOVE YOU HAND SIGN
          0x1F926 == code || // So       FACE PALM
          0x1F930 <= code && code <= 0x1F939 || // So  [10] PREGNANT WOMAN..JUGGLING
          0x1F93D <= code && code <= 0x1F93E || // So   [2] WATER POLO..HANDBALL
          0x1F9D1 <= code && code <= 0x1F9DD // So  [13] ADULT..ELF
          ) {
              return E_Base;
            }

          if (0x1F3FB <= code && code <= 0x1F3FF) // Sk   [5] EMOJI MODIFIER FITZPATRICK TYPE-1-2..EMOJI MODIFIER FITZPATRICK TYPE-6
            {
              return E_Modifier;
            }

          if (0x200D == code // Cf       ZERO WIDTH JOINER
          ) {
              return ZWJ;
            }

          if (0x2640 == code || // So       FEMALE SIGN
          0x2642 == code || // So       MALE SIGN
          0x2695 <= code && code <= 0x2696 || // So   [2] STAFF OF AESCULAPIUS..SCALES
          0x2708 == code || // So       AIRPLANE
          0x2764 == code || // So       HEAVY BLACK HEART
          0x1F308 == code || // So       RAINBOW
          0x1F33E == code || // So       EAR OF RICE
          0x1F373 == code || // So       COOKING
          0x1F393 == code || // So       GRADUATION CAP
          0x1F3A4 == code || // So       MICROPHONE
          0x1F3A8 == code || // So       ARTIST PALETTE
          0x1F3EB == code || // So       SCHOOL
          0x1F3ED == code || // So       FACTORY
          0x1F48B == code || // So       KISS MARK
          0x1F4BB <= code && code <= 0x1F4BC || // So   [2] PERSONAL COMPUTER..BRIEFCASE
          0x1F527 == code || // So       WRENCH
          0x1F52C == code || // So       MICROSCOPE
          0x1F5E8 == code || // So       LEFT SPEECH BUBBLE
          0x1F680 == code || // So       ROCKET
          0x1F692 == code // So       FIRE ENGINE
          ) {
              return Glue_After_Zwj;
            }

          if (0x1F466 <= code && code <= 0x1F469) // So   [4] BOY..WOMAN
            {
              return E_Base_GAZ;
            } //all unlisted characters have a grapheme break property of "Other"


          return Other;
        }

        return this;
      }

      if (typeof module != 'undefined' && module.exports) {
        module.exports = GraphemeSplitter;
      }
    }, {}],
    19: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.AudioType = exports.PlayerInfo = exports.PlayerState = exports.StateManager = void 0;

      var TitleScene_1 = require("./scene/TitleScene/TitleScene");

      var MainGameScene_1 = require("./scene/MainGameScene/MainGameScene");

      var MessageEventType_1 = require("./types/MessageEventType");

      var UserTouchState_1 = require("./types/UserTouchState");

      var Snake_1 = require("./entity/Snake");

      var defaultParameter_1 = require("./config/defaultParameter");

      var ResultScene_1 = require("./scene/ResultScene/ResultScene");

      var audioUtils_1 = require("./utils/audioUtils");

      var StateRoleChecker_1 = require("./utils/StateRoleChecker");

      var utils_1 = require("./commonUtils/utils");

      var lottery_1 = require("./commonUtils/lottery");
      /**
       * ゲーム全体の状態を管理するクラス
       */


      var StateManager =
      /** @class */
      function () {
        function StateManager(param) {
          this.sessionParameter = param.sessionParameter;
          this.broadcaster = param.broadcaster;
          this.isBroadcaster = param.broadcaster.id === g.game.selfId;
          this.audioAssets = {};
          this.userNameLabels = {};
          this.topPlayerList = [];
          this.foodList = [];
          this.waitingFoodList = [];
          this.maxFoodListLength = 25;
          this.isGameOver = false;
          this.createResource();
        }

        StateManager.prototype.createResource = function () {
          var foodCharsAsset = g.game.assets.foodAvailableChars;
          var foodString = JSON.parse(foodCharsAsset.data).foodAvailableChars.join("");
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: g.FontFamily.SansSerif,
            size: 72,
            fontWeight: g.FontWeight.Bold,
            hint: {
              presetChars: foodString
            }
          });
          this.resource = {
            font: font
          };
        };

        StateManager.prototype.changeTitleScene = function () {
          var scene = TitleScene_1.createTitleScene(this);
          g.game.pushScene(scene);
        };

        StateManager.prototype.changeMainGameScene = function () {
          var scene = MainGameScene_1.createMainGameScene(this);
          g.game.pushScene(scene);
        };

        StateManager.prototype.changeResultScene = function () {
          var scene = ResultScene_1.createResultScene(this);
          g.game.pushScene(scene);
        };

        StateManager.prototype.setPlayerList = function (playerList) {
          var _this = this;

          this.playerList = {};
          Object.keys(playerList).forEach(function (playerId) {
            _this.playerList[playerId] = new PlayerInfo({
              player: playerList[playerId].player,
              user: playerList[playerId].user,
              isBroadcaster: playerId === _this.broadcaster.id,
              snakeType: playerList[playerId].snakeType
            });
          });
        };
        /**
         * サーバインスタンスのみ実行
         * ゲーム参加者の募集を開始する
         */


        StateManager.prototype.startRecruitment = function (broadcasterData) {
          this.broadcasterData = broadcasterData;
          this.applicantList = [];
          this.startTime = g.game.age;
          var message = {
            messageType: MessageEventType_1.MessageEventType.waitRecruitment,
            messageData: {
              startTime: this.startTime
            }
          };
          g.game.raiseEvent(new g.MessageEvent(message));
        };
        /**
         * サーバインスタンスのみ実行
         * 参加プレイヤーリクエストを受け付ける
         * リクエストに対する挙動は抽選の有無などによる
         */


        StateManager.prototype.receiveJoinRequest = function (player, user) {
          if (g.game.age - this.startTime > this.sessionParameter.entrySec * g.game.fps) return;

          if (this.applicantList.some(function (p) {
            return p.player.id === player.id;
          })) {
            return;
          }

          this.applicantList.push({
            player: player,
            user: user
          });
        };
        /**
         * サーバインスタンスのみ実行
         * 抽選を開始する。
         */


        StateManager.prototype.startLottery = function () {
          var _this = this;

          var seed = +this.broadcaster.id;
          this.applicantList.forEach(function (applicant, i) {
            seed += +applicant.player.id + i;
          });
          if (!!this.sessionParameter.config.debug && this.sessionParameter.config.debug.skipLottery) seed = 2525;
          this.randomGenerator = new g.XorshiftRandomGenerator(seed); // サーバインスタンスだけg.game.randomの状態が変わってしまうのを避ける

          var winners = lottery_1.weightedLottery(this.applicantList, Math.min(this.applicantList.length, this.sessionParameter.numPlayers), this.sessionParameter.premiumWeight, this.randomGenerator, function (userData) {
            return userData.user.isPremium;
          });
          var playerList = {};
          playerList[this.broadcaster.id] = new PlayerInfo({
            player: this.broadcaster,
            user: this.broadcasterData,
            isBroadcaster: true,
            snakeType: "ABCDEFGHI".charAt(Math.floor(this.randomGenerator.generate() * 9))
          });
          winners.forEach(function (winner) {
            playerList[winner.player.id] = new PlayerInfo({
              player: winner.player,
              user: winner.user,
              isBroadcaster: false,
              snakeType: "ABCDEFGHI".charAt(Math.floor(_this.randomGenerator.generate() * 9))
            });
          });

          this._currentSetTimeout(function () {
            // 「集計中...」表示のためのバッファ
            var numPlayers = Object.keys(playerList).length;
            var message = {
              messageType: MessageEventType_1.MessageEventType.lotteryResult,
              messageData: {
                playerList: playerList,
                numPlayers: numPlayers
              }
            };
            g.game.raiseEvent(new g.MessageEvent(message));

            if (numPlayers > 1) {
              _this.startGame();
            } else {
              _this.restartRequruitment();
            }
          }, 3000);
        };
        /**
         * ゲームを開始する
         */


        StateManager.prototype.startGame = function () {
          this._currentSetTimeout(function () {
            //　抽選結果表示のためのバッファ
            g.game.raiseEvent(new g.MessageEvent({
              messageType: MessageEventType_1.MessageEventType.startGame
            }));
          }, 3000);
        };
        /**
         * 参加者が集まらなかったので抽選をやり直す
         */


        StateManager.prototype.restartRequruitment = function () {
          this._currentSetTimeout(function () {
            g.game.raiseEvent(new g.MessageEvent({
              messageType: MessageEventType_1.MessageEventType.restartRecruitment
            }));
          }, 3000);
        };
        /**
         * サーバインスタンスのみ実行
         * プレイヤーの初期位置を生成する
         */


        StateManager.prototype.setupInitLayout = function () {
          var playerInitLayoutList = this._generateInitLayout();

          var message = {
            messageType: MessageEventType_1.MessageEventType.initMainGame,
            messageData: {
              playerInitLayoutList: playerInitLayoutList
            }
          };
          g.game.raiseEvent(new g.MessageEvent(message));
          this.endInvincibleTime(MessageEventType_1.ScopeType.All);
        };
        /**
         * 全てのインスタンスで実行
         * 各プレイヤーインスタンスのカメラとSnakeを設定する
         */


        StateManager.prototype.setCameraAndSnake = function (playerId, snake) {
          this.playerList[playerId].snake = snake;
          this.playerList[playerId].camera = new g.Camera2D({});
          if (playerId === g.game.selfId) g.game.focusingCamera = this.playerList[playerId].camera; // 最初は無敵状態なので透過させる

          this.playerList[playerId].snake.modifyOpacity(0.5);
        };
        /**
         * 全てのインスタンスで実行
         * 受け取ったプレイヤー操作を状態に反映する
         */


        StateManager.prototype.applyTouchState = function (playerId, state, direction) {
          if (!this.playerList[playerId]) return;
          this.playerList[playerId].uiState.state = state;
          if (direction != null) this.playerList[playerId].uiState.direction = direction;

          if (!!this.playerList[playerId].snake && state === UserTouchState_1.UserTouchState.onPoint && direction != null) {
            var snake = this.playerList[playerId].snake;
            var radianFineness = this.sessionParameter.config.userInput.radianFineness;
            var deg = (this.playerList[playerId].uiState.direction / radianFineness * 360 + 90) % 360;
            snake.head.angle = deg;

            if (this.playerList[playerId].snake.rotateState !== Snake_1.SnakeRotateState.noRotate) {
              var rad = deg / 180 * Math.PI;
              var check = snake.head.x * -Math.cos(rad) - snake.head.y * Math.sin(rad);
              if (check > 0) snake.rotateState = Snake_1.SnakeRotateState.onClockwise;else snake.rotateState = Snake_1.SnakeRotateState.onCounterClockwise;
            }
          }

          if (!!this.playerList[playerId].snake) this.playerList[playerId].snake.dashing(state);
        };
        /**
         * サーバインスタンスのみ実行
         * 無敵状態解除シーケンスを開始する
         */


        StateManager.prototype.endInvincibleTime = function (scope, playerId) {
          var animationMessageData;
          var setPlayingMessageData;

          switch (scope) {
            case MessageEventType_1.ScopeType.All:
              animationMessageData = {
                animationType: MessageEventType_1.AnimationType.Blinking,
                scope: MessageEventType_1.ScopeType.All
              };
              setPlayingMessageData = {
                scope: MessageEventType_1.ScopeType.All
              };
              break;

            case MessageEventType_1.ScopeType.One:
              animationMessageData = {
                animationType: MessageEventType_1.AnimationType.Blinking,
                scope: MessageEventType_1.ScopeType.One,
                playerId: playerId
              };
              setPlayingMessageData = {
                scope: MessageEventType_1.ScopeType.One,
                playerId: playerId
              };
              break;

            default: // do nothing

          } // 点滅アニメーション


          this._currentSetTimeout(function () {
            var message = {
              messageType: MessageEventType_1.MessageEventType.animation,
              messageData: animationMessageData
            };
            g.game.raiseEvent(new g.MessageEvent(message));
          }, this.sessionParameter.config.snake.invincibleTime * 0.75);

          if (scope === MessageEventType_1.ScopeType.All) this.setCountDown(); // 無敵状態解除通知

          this._currentSetTimeout(function () {
            var message = {
              messageType: MessageEventType_1.MessageEventType.setPlaying,
              messageData: setPlayingMessageData
            };
            g.game.raiseEvent(new g.MessageEvent(message));
          }, this.sessionParameter.config.snake.invincibleTime);
        };
        /**
         * サーバーインスタンスのみ実行
         * カウントダウン表示を行う
         */


        StateManager.prototype.setCountDown = function () {
          var _loop_1 = function _loop_1(count) {
            var countDownType;

            switch (count) {
              case 4:
                countDownType = MessageEventType_1.CountDownType.Three;
                break;

              case 3:
                countDownType = MessageEventType_1.CountDownType.Two;
                break;

              case 2:
                countDownType = MessageEventType_1.CountDownType.One;
                break;

              case 1:
                countDownType = MessageEventType_1.CountDownType.Start;
                break;

              default: // do nothing

            }

            this_1._currentSetTimeout(function () {
              var message = {
                messageType: MessageEventType_1.MessageEventType.countDown,
                messageData: {
                  countDownType: countDownType
                }
              };
              g.game.raiseEvent(new g.MessageEvent(message));
            }, this_1.sessionParameter.config.snake.invincibleTime - count * 1000);
          };

          var this_1 = this;

          for (var count = 4; count > 0; --count) {
            _loop_1(count);
          }
        };
        /**
         * 全てのインスタンスで実行
         * 各スネークの無敵状態を解除し、ゲームを開始する
         */


        StateManager.prototype.applyPlayingStateForAllSnakes = function () {
          var _this = this;

          Object.keys(this.playerList).forEach(function (playerId) {
            if (!_this.playerList[playerId].snake) return;

            _this.setPlayerState(playerId, PlayerState.playing);

            _this.playerList[playerId].snake.removeTween(MessageEventType_1.AnimationType.Blinking);

            _this.playerList[playerId].snake.modifyOpacity(1.0);
          });
        };
        /**
         * 全てのインスタンスで実行
         * 特定のスネークの無敵状態を解除し、リスポーンする
         */


        StateManager.prototype.applyPlayingStateForOneSnake = function (playerId) {
          if (!this.playerList[playerId].snake) return;
          this.setPlayerState(playerId, PlayerState.playing);
          this.playerList[playerId].snake.removeTween(MessageEventType_1.AnimationType.Blinking);
          this.playerList[playerId].snake.modifyOpacity(1.0);
        };
        /**
         * 指定PlayerのPlayerStateをセットする
         */


        StateManager.prototype.setPlayerState = function (playerId, state) {
          this.playerList[playerId].state = state;
        };
        /**
         * 全てのインスタンスで実行
         * 全スネークのアニメーション処理
         */


        StateManager.prototype.animateAllSnakes = function (animationType) {
          var _this = this;

          Object.keys(this.playerList).forEach(function (playerId) {
            if (!_this.playerList[playerId].snake) return;
            var snake = _this.playerList[playerId].snake;

            switch (animationType) {
              case MessageEventType_1.AnimationType.Blinking:
                snake.blinking();
                break;

              default: // do nothing

            }
          });
        };
        /**
         * 全てのインスタンスで実行
         * 特定のスネークのアニメーション処理
         */


        StateManager.prototype.animateOneSnake = function (animationType, playerId) {
          if (!this.playerList[playerId].snake) return;
          var snake = this.playerList[playerId].snake;

          switch (animationType) {
            case MessageEventType_1.AnimationType.Blinking:
              snake.blinking();
              break;

            case MessageEventType_1.AnimationType.ToBroadcasterView:
              snake.modifyOpacity(0.0);

              if (playerId === g.game.selfId) {
                snake.parent.scene.showBroadcasterDisplayViewing();
              }

              break;

            default: // do nothing

          }
        };
        /**
         * 参加プレイヤーの初期配置を生成する
         */


        StateManager.prototype._generateInitLayout = function () {
          var _this = this;

          var playerList = {};
          var playerCountRank = this.dividePlayerCountIntoTiers();
          var fieldRadius = this.sessionParameter.config.field.radius[playerCountRank] - 50;
          var lengthOfSquareInField = Math.floor(fieldRadius / Math.sqrt(2)) * 2;
          Object.keys(this.playerList).forEach(function (playerId) {
            playerList[playerId] = {
              direction: _this.randomGenerator.get(0, _this.sessionParameter.config.userInput.radianFineness - 1),
              state: UserTouchState_1.UserTouchState.noPoint,
              position: {
                x: _this.randomGenerator.generate() * lengthOfSquareInField - lengthOfSquareInField / 2,
                y: _this.randomGenerator.generate() * lengthOfSquareInField - lengthOfSquareInField / 2
              },
              name: _this.playerList[playerId].user.name
            };
          });
          return playerList;
        };
        /**
         * サーバーインスタンスのみ実行
         * スネークの衝突判定をチェックする
         */


        StateManager.prototype.checkSnakeCollision = function () {
          var _this = this;

          if (this.isGameOver) return;
          var playersInConflict = [];
          Object.keys(this.playerList).forEach(function (playerId) {
            Object.keys(_this.playerList).forEach(function (enemyId) {
              var playerState = _this.playerList[playerId].state;
              var enemyState = _this.playerList[enemyId].state;

              if (enemyId !== playerId && StateRoleChecker_1.checkStateRole(playerState, StateRoleChecker_1.StateRoleType.CanCollideType) && StateRoleChecker_1.checkStateRole(enemyState, StateRoleChecker_1.StateRoleType.CanCollideType)) {
                if (_this._isSnakeSegmentCollision(playerId, enemyId)) {
                  // 衝突後の処理
                  playersInConflict.push({
                    deadPlayerId: playerId,
                    killerPlayerId: enemyId
                  });
                }
              }
            });
          });

          if (playersInConflict.length) {
            var message = {
              messageType: MessageEventType_1.MessageEventType.sendPlayersInConflict,
              messageData: {
                playersInConflict: playersInConflict
              }
            };
            g.game.raiseEvent(new g.MessageEvent(message));
          }
        };

        StateManager.prototype._isSnakeSegmentCollision = function (playerId, enemyId) {
          var collided = false;
          var playerSnake = this.playerList[playerId].snake;
          var enemySnake = this.playerList[enemyId].snake;
          if (!playerSnake || !enemySnake) return false;
          var playerHeadArea = commonAreaFromSprite(playerSnake.head.body);
          /** スネークの頭同士の判定 */

          var enemyHeadArea = commonAreaFromSprite(enemySnake.head.body);
          collided = collided || g.Collision.withinAreas(playerHeadArea, enemyHeadArea, playerSnake.head.body.width / 2);
          /** あるスネークと敵スネーク節の当たり判定 */

          enemySnake.segments.forEach(function (seg) {
            if (seg.type === Snake_1.SnakeSegmentType.Jewel) return;
            var enemyBodyArea = commonAreaFromSprite(seg.body);
            collided = collided || g.Collision.withinAreas(playerHeadArea, enemyBodyArea, (seg.body.width + playerSnake.head.body.width) / 2);
          });
          return collided;
        };
        /**
         * サーバーインスタンスのみ実行
         * 食べられたエサをチェックする
         */


        StateManager.prototype.checkEatenFoods = function (fieldRadius) {
          var _this = this;

          if (this.isGameOver) return;
          var noEatenFoodIndexList = [];
          var eatenFoodInfo = [];
          this.foodList.forEach(function (shownFood, foodIndex) {
            var isEaten = false;
            Object.keys(_this.playerList).forEach(function (playerId) {
              if (isEaten) return;
              var playerSnake = _this.playerList[playerId].snake;
              if (!shownFood || !playerSnake || !StateRoleChecker_1.checkStateRole(_this.playerList[playerId].state, StateRoleChecker_1.StateRoleType.CanDropType)) return;
              var foodArea = {
                width: shownFood.food.width,
                height: shownFood.food.height,
                x: shownFood.food.x - shownFood.food.width / 2,
                y: shownFood.food.y - shownFood.food.height / 2
              };
              var playerHeadArea = commonAreaFromSprite(playerSnake.head.body);

              if (!isEaten && g.Collision.withinAreas(foodArea, playerHeadArea, (foodArea.width + playerSnake.head.body.width) / 2)) {
                isEaten = true;
                eatenFoodInfo.push({
                  eaterId: playerId,
                  eatenIndex: foodIndex
                });
                return;
              }
            });
            if (!isEaten) noEatenFoodIndexList.push(foodIndex);
          });

          if (this.waitingFoodList.length !== 0 || eatenFoodInfo.length !== 0) {
            var message = {
              messageType: MessageEventType_1.MessageEventType.eatenFoods,
              messageData: {
                eatenFoodInfo: eatenFoodInfo,
                noEatenFoodIndexList: noEatenFoodIndexList,
                fieldRadius: fieldRadius
              }
            };
            g.game.raiseEvent(new g.MessageEvent(message));
          }
        };
        /**
         * サーバーインスタンスでのみ実行
         * ランキング情報を更新する
         */


        StateManager.prototype.updateRanking = function () {
          var _this = this;

          var rankingList = [];
          Object.keys(this.playerList).forEach(function (playerId) {
            var playerState = _this.playerList[playerId].state;
            if (!_this.playerList[playerId].snake || playerState !== PlayerState.playing) return;
            rankingList.push(_this.playerList[playerId]);
          });
          rankingList.sort(function (left, right) {
            return left.snake.words.length > right.snake.words.length ? -1 : 1;
          });
          var isSame = rankingList.length === this.topPlayerList.length;
          this.topPlayerList.forEach(function (player, i) {
            if (!isSame || !player) return;
            if (player.player.id !== rankingList[i].player.id) isSame = false;
          }); // 変更があった場合のみ通知する

          if (!isSame || this.topPlayerList.length === 0) {
            this.topPlayerList = rankingList;
            var topPlayerAccountDataList_1 = [];
            this.topPlayerList.forEach(function (player) {
              var playerState = _this.playerList[player.player.id].state;
              if (!_this.playerList[player.player.id].snake || playerState !== PlayerState.playing) return;
              topPlayerAccountDataList_1.push({
                id: player.player.id,
                name: player.user.name,
                isPremium: player.user.isPremium
              });
            });
            var message = {
              messageType: MessageEventType_1.MessageEventType.rankingAccountData,
              messageData: {
                rankingAccountData: topPlayerAccountDataList_1
              }
            };
            g.game.raiseEvent(new g.MessageEvent(message));
          }
        };
        /**
         * 全てのインスタンスで実行
         * 食べられたエサの情報を反映する
         */


        StateManager.prototype.applyEatenFoods = function (eatenFoodInfo, noEatenFoodIndexList, fieldRadius) {
          var _this = this;

          eatenFoodInfo.forEach(function (info) {
            if (!_this.foodList[info.eatenIndex].root.destroyed()) _this.foodList[info.eatenIndex].destroy();
            if (!_this.playerList[info.eaterId].snake) return;

            _this.playerList[info.eaterId].snake.eatFood(_this.foodList[info.eatenIndex]);
          });
          var newFoodList = [];
          noEatenFoodIndexList.forEach(function (noEatenIndex) {
            var food = _this.foodList[noEatenIndex].food;

            if (Math.pow(food.x, 2) + Math.pow(food.y, 2) <= Math.pow(fieldRadius + 100, 2)) {
              newFoodList.push(_this.foodList[noEatenIndex]);
            } else {
              if (!_this.foodList[noEatenIndex].root.destroyed()) _this.foodList[noEatenIndex].destroy();
            }
          });
          this.waitingFoodList.forEach(function (food) {
            return newFoodList.push(food);
          });
          this.waitingFoodList = [];
          this.foodList = newFoodList;
        };
        /**
         * サーバーインスタンスのみ実行
         * 食べられたお宝をチェックする
         */


        StateManager.prototype.checkEatenJewel = function () {
          var _this = this;

          if (this.isGameOver) return;
          var nowOwnerId = this.jewelData.ownerId;
          var jewelArea;

          if (nowOwnerId != null) {
            // お宝所有者がいる場合
            if (!StateRoleChecker_1.checkStateRole(this.playerList[nowOwnerId].state, StateRoleChecker_1.StateRoleType.CanDropType)) return;
            var segments = this.playerList[nowOwnerId].snake.segments;
            var jewel = segments[segments.length - 1];
            if (!jewel || jewel.type !== Snake_1.SnakeSegmentType.Jewel) return;
            jewelArea = {
              width: jewel.body.width,
              height: jewel.body.height,
              x: jewel.x + jewel.body.x,
              y: jewel.y + jewel.body.y
            };
          } else {
            jewelArea = {
              width: this.jewelData.jewel.jewel.width,
              height: this.jewelData.jewel.jewel.height,
              x: this.jewelData.jewel.jewel.x - this.jewelData.jewel.jewel.width / 2,
              y: this.jewelData.jewel.jewel.y - this.jewelData.jewel.jewel.height / 2
            };
          }

          Object.keys(this.playerList).forEach(function (playerId) {
            var playerSnake = _this.playerList[playerId].snake;
            if (!playerSnake || playerId === nowOwnerId || !StateRoleChecker_1.checkStateRole(_this.playerList[playerId].state, StateRoleChecker_1.StateRoleType.CanDropType)) return;
            var playerHeadArea = commonAreaFromSprite(playerSnake.head.body);

            if (g.Collision.withinAreas(jewelArea, playerHeadArea, (jewelArea.width + playerHeadArea.height) / 2)) {
              // お宝をゲットした最初の一人をオーナーとする
              nowOwnerId = playerId;
              return;
            }
          });

          if (nowOwnerId !== this.jewelData.ownerId) {
            var message = {
              messageType: MessageEventType_1.MessageEventType.updateJewelOwner,
              messageData: {
                ownerId: nowOwnerId
              }
            };
            g.game.raiseEvent(new g.MessageEvent(message));
          }
        };
        /**
         * サーバーインスタンスでのみ実行
         * フィールド上のお宝がフィールド外に存在するか判定する
         */


        StateManager.prototype.checkJewelOutsideField = function (fieldRadius) {
          if (this.jewelData.ownerId != null) return;
          var jewel = this.jewelData.jewel.jewel;

          if (Math.pow(jewel.x, 2) + Math.pow(jewel.y, 2) > Math.pow(fieldRadius, 2)) {
            var playerCountRank = this.dividePlayerCountIntoTiers();
            var fieldRadius_1 = this.sessionParameter.config.field.radius[playerCountRank] - 50;
            var lengthOfSquareInField = Math.floor(fieldRadius_1 / Math.sqrt(2)) * 2;
            var message = {
              messageType: MessageEventType_1.MessageEventType.respawnJewel,
              messageData: {
                position: {
                  x: this.randomGenerator.generate() * lengthOfSquareInField - lengthOfSquareInField / 2,
                  y: this.randomGenerator.generate() * lengthOfSquareInField - lengthOfSquareInField / 2
                }
              }
            };
            g.game.raiseEvent(new g.MessageEvent(message));
          }
        };
        /**
         * 全インスタンスで実行
         * お宝をリスポーンさせる
         */


        StateManager.prototype.setRespawnJewel = function (position) {
          if (this.jewelData.ownerId != null) return;
          this.jewelData.jewel.respawn(position);
        };
        /**
         * 全てのインスタンスで実行
         * お宝の更新情報を反映する
         */


        StateManager.prototype.applyEatenJewel = function (ownerId) {
          if (!this.playerList[ownerId].snake) return;
          var stolenPlayerId = this.jewelData.ownerId; // お宝を盗まれたプレイヤーのid

          if (stolenPlayerId != null) this.playerList[stolenPlayerId].snake.removeJewel();
          this.playerList[ownerId].snake.eatJewel();

          if (stolenPlayerId == null && !this.jewelData.jewel.root.destroyed()) {
            this.jewelData.jewel.destroy();
          }

          this.jewelData.ownerId = ownerId;
        };
        /**
         * 全てのインスタンスで実行
         * リスポーンしたSnakeを設定する
         */


        StateManager.prototype.setRespawnSnake = function (playerId, snakeLayer, nowRadius) {
          --this.playerList[playerId].respawnTimes;

          var _a = this._generateNewSnakeLayout(playerId, snakeLayer, true, nowRadius),
              snake = _a[0],
              direction = _a[1];

          this.playerList[playerId].snake = snake;
          this.playerList[playerId].uiState = {
            direction: direction,
            state: UserTouchState_1.UserTouchState.noPoint
          };
          this.setPlayerState(playerId, PlayerState.invincible);
          this.playerList[playerId].snake.modifyOpacity(0.5);
          this.userNameLabels[playerId].show();
        };
        /**
         * 全てのインスタンスで実行
         * 放送者の天使スネークを設定する
         */


        StateManager.prototype.setBroadcasterAngelSnake = function (snakeLayer, nowRadius) {
          var _a = this._generateNewSnakeLayout(this.broadcaster.id, snakeLayer, false, nowRadius),
              snake = _a[0],
              direction = _a[1];

          this.playerList[this.broadcaster.id].snake = snake;
          this.playerList[this.broadcaster.id].uiState = {
            direction: direction,
            state: UserTouchState_1.UserTouchState.noPoint
          };
          this.setPlayerState(this.broadcaster.id, PlayerState.ghost);
          this.userNameLabels[this.broadcaster.id].show();
        };
        /**
         * 全てのインスタンスで実行
         * PreventTypeを適用する
         */


        StateManager.prototype.applyPreventUserTouch = function (playerId, preventType) {
          this.playerList[playerId].preventType = preventType;
        };
        /**
         * サーバーインスタンスでのみ実行
         * フィールド上のスネークをカウントし、ゲームを終了するか判定する
         */


        StateManager.prototype.checkGameEnd = function () {
          var _this = this;

          if (this.isGameOver || !!this.sessionParameter.config.debug && (this.sessionParameter.config.debug.skipLottery || this.sessionParameter.config.debug.banEndingGameByNumberOfPlayers)) return;
          var playingSnakes = Object.keys(this.playerList).filter(function (playerId) {
            return StateRoleChecker_1.checkStateRole(_this.playerList[playerId].state, StateRoleChecker_1.StateRoleType.CanCountType);
          });
          playingSnakes.forEach(function (playerId) {
            _this.playerList[playerId].lengthCount = _this.playerList[playerId].snake.words.length;
          });

          if (playingSnakes.length <= 0) {
            this.gameEndProcedure();
          }
        };
        /**
         * サーバーインスタンスでのみ実行
         * ゲームを終了手続きを行う
         */


        StateManager.prototype.gameEndProcedure = function () {
          if (this.isGameOver) return;
          var message = {
            messageType: MessageEventType_1.MessageEventType.finishGame
          };
          g.game.raiseEvent(new g.MessageEvent(message));

          this._currentSetTimeout(function () {
            var message = {
              messageType: MessageEventType_1.MessageEventType.startResult
            };
            g.game.raiseEvent(new g.MessageEvent(message));
          }, 5000);
        };
        /**
         * オーディオをセッションパラメータで指定されたボリュームで再生する
         */


        StateManager.prototype.playAudioAtParamVolume = function (audioType) {
          var audioPlayer = this.audioAssets[audioType].play();
          audioUtils_1.changeAudioMasterVolume(audioPlayer, this.sessionParameter.config);
        };
        /**
         * サーバインスタンスのみ実行
         * リザルト画面で表示するランキングの準備をする
         */


        StateManager.prototype.setupResultRanking = function () {
          var _this = this;

          var rankingList = [];
          Object.keys(this.playerList).forEach(function (playerId) {
            rankingList.push(_this.playerList[playerId]);
          });
          var lengthRankingList = rankingList.slice();
          var killRankingList = rankingList.slice();
          lengthRankingList.sort(function (left, right) {
            return left.lengthCount > right.lengthCount ? -1 : 1;
          });
          killRankingList.sort(function (left, right) {
            return left.killCount > right.killCount ? -1 : 1;
          }); // そのままRankingListを送れないので、最低限のデータだけ送る

          var lengthRankingPlayerIdList = [];
          var killRankingPlayerIdList = [];
          lengthRankingList.forEach(function (p) {
            return lengthRankingPlayerIdList.push({
              playerId: p.player.id,
              count: _this.playerList[p.player.id].lengthCount
            });
          });
          killRankingList.forEach(function (p) {
            return killRankingPlayerIdList.push({
              playerId: p.player.id,
              count: _this.playerList[p.player.id].killCount
            });
          });
          var message = {
            messageType: MessageEventType_1.MessageEventType.initResult,
            messageData: {
              lengthRankingPlayerIdList: lengthRankingPlayerIdList,
              killRankingPlayerIdList: killRankingPlayerIdList,
              jewelOwnerId: this.jewelData.ownerId
            }
          };
          g.game.raiseEvent(new g.MessageEvent(message));
        };
        /**
         * プレイヤー人数をランク分けする
         */


        StateManager.prototype.dividePlayerCountIntoTiers = function () {
          var _this = this;

          var playerCount = 0;
          Object.keys(this.playerList).forEach(function (playerId) {
            var playerState = _this.playerList[playerId].state;
            if (StateRoleChecker_1.checkStateRole(playerState, StateRoleChecker_1.StateRoleType.CanCountType)) ++playerCount;
          });

          if (playerCount <= 10) {
            return 4;
          } else if (playerCount <= 30) {
            return 3;
          } else if (playerCount <= 50) {
            return 2;
          } else if (playerCount <= 70) {
            return 1;
          } else {
            return 0;
          }
        };

        StateManager.prototype._generateNewSnakeLayout = function (playerId, snakeLayer, rebornEffect, nowRadius) {
          var snakeConfig = this.sessionParameter.config.snake;
          var maxLength = nowRadius - snakeConfig.baseSpeed * snakeConfig.maxNameLength * Math.round(90 / snakeConfig.baseSpeed) * 2; // speed * segments * historyDistanceInterval

          var direction = Math.ceil(g.game.random.get(0, 1) * (this.sessionParameter.config.userInput.radianFineness - 1) / 2); // 左右の2択

          var position = {
            x: (g.game.random.generate() - 0.5) * maxLength,
            y: (g.game.random.generate() - 0.5) * maxLength
          };
          var name = this.playerList[playerId].user.name;
          var words = utils_1.stringToArray(name).slice(0, Math.min(name.length, this.sessionParameter.config.snake.maxNameLength));

          if (words.length < this.sessionParameter.config.snake.maxNameLength) {
            var blankCount = this.sessionParameter.config.snake.maxNameLength - words.length;

            for (var i = 0; i < blankCount; ++i) {
              words.push("　");
            }
          }

          var snake = new Snake_1.Snake({
            parent: snakeLayer,
            x: position.x,
            y: position.y,
            angle: direction / this.sessionParameter.config.userInput.radianFineness * 360,
            words: words,
            snakeBaseSpeed: this.sessionParameter.config.snake.baseSpeed,
            snakeMaxSpeedScale: this.sessionParameter.config.snake.maxSpeedScale,
            snakeMaxKnotLength: this.sessionParameter.config.snake.maxKnotLength,
            font: this.resource.font,
            snakeType: this.playerList[playerId].snakeType,
            rebornEffect: rebornEffect,
            onEndRebornEffect: function onEndRebornEffect() {
              if (!g.game.isActiveInstance()) return;
              var preventTouchMessage = {
                messageType: MessageEventType_1.MessageEventType.preventUsertouch,
                messageData: {
                  playerId: playerId,
                  preventType: MessageEventType_1.PreventType.None
                }
              };
              g.game.raiseEvent(new g.MessageEvent(preventTouchMessage));
            }
          });
          return [snake, direction];
        };

        StateManager.prototype._currentSetTimeout = function (handler, milliseconds) {
          var scene = g.game.scene();

          if (scene) {
            scene.setTimeout(handler, milliseconds);
          }
        };

        return StateManager;
      }();

      exports.StateManager = StateManager;
      var PlayerState;

      (function (PlayerState) {
        /**
         * 不可視な天使（ゴースト）として参加している
         */
        PlayerState["ghost"] = "ghost";
        /**
         * 盤面に影響を持つスネークを操作している
         */

        PlayerState["playing"] = "playing";
        /**
         * join済みだがゴーストもスネークも操作していない
         */

        PlayerState["dead"] = "dead";
        /**
         * 無敵状態（当たり判定なし）
         * ゲーム開始・リスポン直後に即死するのを避けるための状態で、ghostとは区別される
         * 生きているプレイヤーとしてカウントされる
         */

        PlayerState["invincible"] = "invincible";
        /**
         * 演出中の状態（当たり判定なし）
         * キルされた時などに演出を行うための状態
         * 生きているプレイヤーとしてカウントされる
         */

        PlayerState["staging"] = "staging";
        /**
         * joinを押してないプレイヤーはPlayerStateが生成されないため、これを表現する種別はない
         */
      })(PlayerState = exports.PlayerState || (exports.PlayerState = {}));

      var PlayerInfo =
      /** @class */
      function () {
        function PlayerInfo(param) {
          this.player = param.player;
          this.user = param.user;
          this.snakeType = param.snakeType;
          this.state = PlayerState.invincible;
          this.respawnTimes = param.user.isPremium || param.isBroadcaster ? defaultParameter_1.sessionParameter.config.snake.premiumRespawnTimes : defaultParameter_1.sessionParameter.config.snake.respawnTimes;
          this.killCount = 0;
          this.preventType = MessageEventType_1.PreventType.None;
          this.lengthCount = 0;
          this.lastWords = "";
        }

        PlayerInfo.prototype.destroySnake = function () {
          this.lastWords = this.getsLastWords();
          this.snake.destroy();
          this.snake = null;
          this.state = PlayerState.dead;
        };

        PlayerInfo.prototype.getsLastWords = function () {
          return this.snake.words.reduce(function (str, ch) {
            return str + ch;
          }, "");
        };

        return PlayerInfo;
      }();

      exports.PlayerInfo = PlayerInfo;
      var AudioType;

      (function (AudioType) {
        // ----------
        // ゲーム画面のオーディオ
        // ----------

        /**
         * ゲーム画面BGM
         */
        AudioType["GameBGM"] = "GameBGM";
        /**
         * ３２１カウントダウン時のSE
         */

        AudioType["Count"] = "Count";
        /**
         * ゲーム開始時のSE
         */

        AudioType["Start"] = "Start";
        /**
         * ゲーム終了時のSE
         */

        AudioType["Finish"] = "Finish";
        /**
         * 衝突時のSE
         */

        AudioType["Collision"] = "Collision";
        /**
         * ダッシュ時のSE
         */

        AudioType["Dash"] = "Dash";
        /**
         * お宝ゲット時のSE
         */

        AudioType["Jewel"] = "Jewel";
        /**
         * 選択時のSE
         */

        AudioType["Select"] = "Select"; // ----------
        // リザルト画面のオーディオ
        // ----------

        /**
         * イントロ
         */

        AudioType["Intro"] = "Intro";
        /**
         * リザルト画面BGM
         */

        AudioType["ResultBGM"] = "ResultBGM";
      })(AudioType = exports.AudioType || (exports.AudioType = {}));

      function commonAreaFromSprite(e) {
        var centerPos = e.localToGlobal({
          x: e.anchorX * e.width,
          y: e.anchorY * e.height
        });
        return {
          x: centerPos.x - e.anchorX * e.width,
          y: centerPos.y - e.anchorY * e.height,
          width: e.width,
          height: e.height
        };
      }
    }, {
      "./commonUtils/lottery": 22,
      "./commonUtils/utils": 23,
      "./config/defaultParameter": 24,
      "./entity/Snake": 34,
      "./scene/MainGameScene/MainGameScene": 43,
      "./scene/ResultScene/ResultScene": 45,
      "./scene/TitleScene/TitleScene": 48,
      "./types/MessageEventType": 49,
      "./types/UserTouchState": 50,
      "./utils/StateRoleChecker": 51,
      "./utils/audioUtils": 52
    }],
    20: [function (require, module, exports) {
      "use strict";

      var main_1 = require("./main");

      module.exports = function (originalParam) {
        var param = {};
        Object.keys(originalParam).forEach(function (key) {
          param[key] = originalParam[key];
        });
        param.sessionParameter = {};
        var sessionParameter;
        var broadcasterPlayer;
        var scene = new g.Scene({
          game: g.game
        });

        function start() {
          param.sessionParameter = sessionParameter;
          g.game.popScene();
          main_1.main(param);
        }

        g.game.onJoin.add(function (event) {
          broadcasterPlayer = event.player;
          param.broadcasterPlayer = broadcasterPlayer;
        });
        scene.onMessage.add(function (message) {
          if (message.data && message.data.type === "start" && message.data.parameters) {
            sessionParameter = message.data.parameters;
          }
        }); // 生主の playerId 確定とセッションパラメータが揃ったらゲーム開始

        scene.onUpdate.add(function () {
          if (broadcasterPlayer && sessionParameter) {
            start();
          }
        });
        g.game.pushScene(scene);
      };
    }, {
      "./main": 40
    }],
    21: [function (require, module, exports) {
      "use strict"; // ----------
      // ゲーム画面のアセットID
      // ----------

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.resultAssetIds = exports.effectAssetIds = exports.audioAssetIds = exports.fontAssetIds = exports.uiAssetIds = exports.snakeAssetIds = void 0;
      exports.snakeAssetIds = ["snake_body_death", "snake_body_gold", "snakeA_head_alive", "snakeA_body", "snakeA_head_death", "snakeA_head_gold", "snakeB_head_alive", "snakeB_body", "snakeB_head_death", "snakeB_head_gold", "snakeC_head_alive", "snakeC_body", "snakeC_head_death", "snakeC_head_gold", "snakeD_head_alive", "snakeD_body", "snakeD_head_death", "snakeD_head_gold", "snakeE_head_alive", "snakeE_body", "snakeE_head_death", "snakeE_head_gold", "snakeF_head_alive", "snakeF_body", "snakeF_head_death", "snakeF_head_gold", "snakeG_head_alive", "snakeG_body", "snakeG_head_death", "snakeG_head_gold", "snakeH_head_alive", "snakeH_body", "snakeH_head_death", "snakeH_head_gold", "snakeI_head_alive", "snakeI_body", "snakeI_head_death", "snakeI_head_gold"];
      exports.uiAssetIds = ["field_base", "field_tiles", "main_feed", "main_jewel_body", "main_rpop_body", "main_rpop_head_jewel", "main_rpop_head_kill", "main_rpop_tail", "main_base_kill", "main_base_length", "main_rank_1", "main_rank_2", "main_rank_3", "main_rank_4", "main_rank_5", "main_rank_base", "main_rank_host", "main_rank_you", "main_btn_rank_off", "main_btn_rank_off_diff", "main_btn_rank_on", "main_btn_rank_on_diff", "main_base_time", "main_btn_spawn_off", "main_btn_spawn_on", "main_btn_spawn_off_angel", "main_btn_spawn_on_angel", "main_btn_spawn_unable", "main_map_base", "main_jewel_pop", "main_count_1", "main_count_2", "main_count_3", "main_count_start", "main_count_finish", "main_dash_base", "main_dash_gauge1", "main_dash_eff", "main_btn_close_on", "main_btn_close_off", "main_deathpop", "red_rpop_body", "red_rpop_head_chance", "red_rpop_tail"];
      exports.fontAssetIds = ["main_num_score", "main_num_score_glyph", "main_num_time_c", "main_num_time_r", "main_num_time_glyph"];
      exports.audioAssetIds = ["snake_bgm", "SE_collision", "SE_count", "SE_dash", "SE_finish", "SE_jewel", "SE_select", "SE_start"];
      exports.effectAssetIds = ["snake_reborn", "snake_reborn_text", "explosion_effect"]; // ----------
      // リザルト画面のアセットID
      // ----------

      exports.resultAssetIds = ["snake_result_intro", "snake_result", "result_base_ranking", "result_base_treasure", "result_btn_back_off", "result_btn_back_on", "result_btn_next_off", "result_btn_next_on", "result_num_b", "result_num_r", "result_title_kill", "result_title_length", "result_unit_i_b", "result_unit_i_r", "result_unit_ji_b", "result_unit_ji_r", "result_num_b", "result_num_r", "result_glyph", "result_btn_back_off_unable", "result_btn_next_off_unable"];
    }, {}],
    22: [function (require, module, exports) {
      "use strict";

      var __spreadArrays = this && this.__spreadArrays || function () {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) {
          s += arguments[i].length;
        }

        for (var r = Array(s), k = 0, i = 0; i < il; i++) {
          for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++) {
            r[k] = a[j];
          }
        }

        return r;
      };

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.weightedLottery = void 0;
      /**
       * 重み付け抽選。
       *
       * 配列からランダムに指定個数の要素を選び、それらを格納した配列を返す。
       *
       * weightedItemCond() が真を返す要素は当選確率が weight だけ重み付けされる。
       * たとえば weight が 2 なら、 weightedItemCond が真を返す要素はそうでない要素
       * と比較して 2 倍の当選確率になる。
       *
       * @param items 抽選される要素の配列。
       * @param numWinners 抽選で選ばれる要素数。
       * @param weight 当選確率の重みづけ。重み付けされない要素の当選確率に対する比。
       * @param rand 乱数生成器。
       * @param weightedItemCond 当選率を重み付けされる要素を与えた時真を返す関数。
       */

      function weightedLottery(items, numWinners, weight, rand, weightedItemCond) {
        items = __spreadArrays(items); // 全て当選とするケース。

        if (numWinners >= items.length) {
          return items;
        } // 当選確率を重み付けされる要素を配列の先頭に集める。


        items = items.sort(function (item1, item2) {
          var n1 = weightedItemCond(item1) ? 0 : 1;
          var n2 = weightedItemCond(item2) ? 0 : 1;
          return n1 - n2;
        }); // 一様乱数を weight などにしたがって非一様乱数に変換する関数。

        var Gi = function Gi(w, a, b, gx) {
          var t = 1 / (a * (w - 1) + b);
          var atw = a * t * w;

          if (gx < atw) {
            return gx / (t * w);
          } else {
            return (b - a) * (gx - atw) / (1 - atw) + a;
          }
        };

        var A = items.filter(function (item) {
          return weightedItemCond(item);
        }).length;
        var B = items.length;
        var winners = [];

        for (var i = 0; i < numWinners; i++) {
          var g_x = rand.generate();
          var x = Gi(weight, A, B, g_x);
          var idx = Math.floor(x);
          if (idx < A) A--;
          B--;
          winners.push(items.splice(idx, 1)[0]);
        }

        return winners;
      }

      exports.weightedLottery = weightedLottery;
    }, {}],
    23: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.stringToArray = exports.clampString = exports.slice = void 0;

      var GraphemeSplitter = require("grapheme-splitter");

      var splitter = new GraphemeSplitter();
      /**
       * サロゲートペア・合成絵文字を考慮して文字列を切り取る
       * powered by grapheme-splitter
       * @param str 文字列
       * @param length 長さ
       */

      function slice(str, length) {
        var array = splitter.splitGraphemes(str);
        var ret = array.slice(0, length);
        return ret.join("");
      }

      exports.slice = slice;
      /**
       * サロゲートペア・合成絵文字を考慮して、指定文字数が超えていたら末尾に指定の文字列を追加して返す
       */

      function clampString(str, length, endLetter) {
        if (endLetter === void 0) {
          endLetter = "";
        }

        var array = splitter.splitGraphemes(str);

        if (length < array.length) {
          return slice(str, length) + endLetter;
        }

        return str;
      }

      exports.clampString = clampString;
      /**
       * 文字列をサロゲートペア・合成絵文字を考慮して配列化する
       * powered by grapheme-splitter
       * @param str 文字列
       */

      function stringToArray(str) {
        return splitter.splitGraphemes(str);
      }

      exports.stringToArray = stringToArray;
    }, {
      "grapheme-splitter": 18
    }],
    24: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.sessionParameter = void 0;
      exports.sessionParameter = {
        entrySec: 21,
        numPlayers: 99,
        howtoMessage: "荷物をひろって トラックを長くしよう！\n" + "ほかのトラックに 頭がぶつかると 死んでしまいます。\n" + "　方向転換 ： クリック、ドラッグ\n" + "　ダッシュ ： ダブルクリック\n" + "　ふっかつボタン ： 全員 10回まで",
        premiumWeight: 2.5,
        config: {
          field: {
            radius: [3000, 2500, 2100, 1800, 1500],
            narrowRadiusPerSec: 0,
            bgOpacity: 1.0
          },
          food: {
            interval: 1700,
            volume: [25, 20, 15, 10, 5]
          },
          snake: {
            dashingTime: 3,
            baseSpeed: 5,
            maxSpeedScale: 4,
            amountDashingGaugeRecoveryPerFrame: 10,
            maxNameLength: 1,
            maxKnotLength: 30,
            respawnTimes: 100,
            premiumRespawnTimes: 100,
            invincibleTime: 10000
          },
          time: {
            isTimeBased: true,
            limit: 120
          },
          userInput: {
            pointMoveDistance: 50,
            doublePointDuration: 0.1,
            radianFineness: 72
          },
          audio: {
            audioVolume: 0.5
          }
        }
      };
    }, {}],
    25: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics3 = function extendStatics(d, b) {
          _extendStatics3 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics3(d, b);
        };

        return function (d, b) {
          _extendStatics3(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.DashingGauge = void 0;

      var DashingGauge =
      /** @class */
      function (_super) {
        __extends(DashingGauge, _super);

        function DashingGauge(param) {
          var _this = _super.call(this, param) || this;

          _this._maxGaugeAmount = param.maxGaugeAmount;
          _this._maxGaugeBaseWidth = 126 - 8;
          _this._gaugeAsset = _this.scene.assets.main_dash_gauge1;
          _this._gaugeBar = new g.Pane({
            scene: _this.scene,
            width: _this._maxGaugeBaseWidth,
            height: _this._gaugeAsset.height,
            x: 4,
            y: 4,
            backgroundImage: _this._gaugeAsset,
            backgroundEffector: new g.NinePatchSurfaceEffector(_this.scene.game, 5)
          });

          _this.append(_this._gaugeBar);

          return _this;
        }

        DashingGauge.prototype.updateGauge = function (gaugeAmount) {
          // ブラウザによって9patchの幅が整数でないと表示がおかしくなるので、整数に丸める
          var gaugeBarWidth = Math.floor(gaugeAmount / this._maxGaugeAmount * this._maxGaugeBaseWidth);
          this._gaugeBar.x = this._maxGaugeBaseWidth - gaugeBarWidth + 4;

          if (gaugeBarWidth < this._gaugeAsset.width) {
            this._gaugeBar.x += (this._gaugeAsset.width - gaugeBarWidth) / 2;
            if (gaugeBarWidth < 3 * this._gaugeAsset.width / 4) this._gaugeBar.hide();else this._gaugeBar.show();
          }

          this._gaugeBar.width = gaugeBarWidth;
          if (this.opacity !== 0) this._gaugeBar.invalidate();
        };

        return DashingGauge;
      }(g.Sprite);

      exports.DashingGauge = DashingGauge;
    }, {}],
    26: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics4 = function extendStatics(d, b) {
          _extendStatics4 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics4(d, b);
        };

        return function (d, b) {
          _extendStatics4(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Field = void 0;

      var akashic_tile_1 = require("@akashic-extension/akashic-tile");

      var Field =
      /** @class */
      function (_super) {
        __extends(Field, _super);

        function Field(param) {
          var _this = _super.call(this, param) || this;

          _this._createBase();

          _this._createTiles();

          return _this;
        }

        Field.prototype._createBase = function () {
          var baseAsset = this.scene.assets.field_base;
          var scale = this.width / baseAsset.width;
          this.base = new g.Sprite({
            scene: this.scene,
            src: baseAsset,
            x: this.width / 2,
            y: this.height / 2,
            scaleX: scale,
            scaleY: scale,
            anchorX: 0.5,
            anchorY: 0.5
          });
          this.append(this.base);
        };

        Field.prototype._createTiles = function () {
          var tileAsset = this.scene.assets.field_tiles;
          var tileLineCount = Math.ceil(this.width / tileAsset.height);
          var tileArray = [];

          for (var i = 0; i < tileLineCount; ++i) {
            tileArray[i] = [];

            for (var j = 0; j < tileLineCount; ++j) {
              tileArray[i].push(g.game.random.get(0, 4));
            }
          }

          var tile = new akashic_tile_1.Tile({
            scene: this.scene,
            src: tileAsset,
            tileWidth: tileAsset.height,
            tileHeight: tileAsset.height,
            tileData: tileArray
          });
          tile.compositeOperation = g.CompositeOperation.ExperimentalSourceIn;
          this.append(tile);
        };

        Field.prototype.narrowArea = function (newWidth) {
          if (newWidth <= 0) return;
          var baseAsset = this.scene.assets.field_base;
          var scale = newWidth / baseAsset.width;
          this.base.scaleX = scale;
          this.base.scaleY = scale; // baseがappendされている親Paneの再描画を間引く

          if (scale === Math.round(scale) || g.game.age % 15 !== 0) return;
          this.base.modified();
        };
        /**
         * フィールドの形状を真円と暗黙に仮定して扱うときのサイズ
         */


        Field.prototype.getNowRadius = function () {
          if (this.nowWidth === this.nowHeight) return this.nowWidth;
          return (this.nowWidth + this.nowHeight) / 2;
        };

        Object.defineProperty(Field.prototype, "nowWidth", {
          get: function get() {
            return this.base.width * this.base.scaleX;
          },
          enumerable: false,
          configurable: true
        });
        Object.defineProperty(Field.prototype, "nowHeight", {
          get: function get() {
            return this.base.height * this.base.scaleY;
          },
          enumerable: false,
          configurable: true
        });
        return Field;
      }(g.Pane);

      exports.Field = Field;
    }, {
      "@akashic-extension/akashic-tile": 10
    }],
    27: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics5 = function extendStatics(d, b) {
          _extendStatics5 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics5(d, b);
        };

        return function (d, b) {
          _extendStatics5(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Food = void 0;

      var akashic_label_1 = require("@akashic-extension/akashic-label");

      var entityUtils_1 = require("../utils/entityUtils");

      var OffsetGroup_1 = require("./OffsetGroup");

      var Food =
      /** @class */
      function (_super) {
        __extends(Food, _super);

        function Food(param) {
          var _this = _super.call(this, param) || this;

          _this.font = param.font;
          _this.word = param.word;
          _this.x = param.x;
          _this.y = param.y;

          _this._init();

          return _this;
        }

        Food.prototype._init = function () {
          var _this = this;

          var foodAsset = this.parent.scene.assets.main_feed;
          this.food = new g.Sprite({
            scene: this.parent.scene,
            x: this.x,
            y: this.y,
            width: foodAsset.width,
            height: foodAsset.height,
            anchorX: 0.5,
            anchorY: 0.5,
            src: foodAsset
          });
          var foodOffset; // Foodは移動しない前提で座標計算を使いまわす

          this.food.render = function (renderer, camera) {
            if (camera) {
              var cam = g.game.focusingCamera;
              var margin = 50;
              if (!foodOffset) foodOffset = entityUtils_1.localToGlobal(_this);

              if (foodOffset.x >= cam.x - margin && foodOffset.x <= cam.x + g.game.width + margin && foodOffset.y >= cam.y - margin && foodOffset.y <= cam.y + g.game.height + margin) {// do nothing
              } else {
                  return; // modifiedフラグはカメラに入るまで保持する
                }
            }

            g.Sprite.prototype.render.call(_this.food, renderer, camera); // ugh
          };

          this.root.append(this.food); // ラベルを作成。本当に作成したらtrueを返す

          var createLabel = function createLabel() {
            var camera = g.game.focusingCamera;
            var margin = 50;

            if (camera) {
              if (_this.x >= camera.x - margin && _this.x <= camera.x + g.game.width + margin && _this.y >= camera.y - margin && _this.y <= camera.y + g.game.height + margin) {
                _this.wordLabel = new akashic_label_1.Label({
                  scene: _this.root.scene,
                  y: (foodAsset.height - 25) / 2,
                  font: _this.font,
                  text: _this.word,
                  width: foodAsset.width,
                  fontSize: 25,
                  textColor: "black",
                  textAlign: "center",
                  trimMarginTop: true,
                  local: true // 生成タイミングが不定になるためentity id採番に影響しないようlocal化

                });

                _this.food.append(_this.wordLabel);

                return true;
              }
            }

            return false;
          };

          this.root.scene.setTimeout(function () {
            if (!_this.root.scene || _this.root.destroyed()) return; // 消費された場合

            _this.root.onUpdate.add(createLabel); // createLabel が true を返して解除

          }, 50 + Math.random() * 500);
        };

        return Food;
      }(OffsetGroup_1.OffsetGroup);

      exports.Food = Food;
    }, {
      "../utils/entityUtils": 53,
      "./OffsetGroup": 30,
      "@akashic-extension/akashic-label": 8
    }],
    28: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics6 = function extendStatics(d, b) {
          _extendStatics6 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics6(d, b);
        };

        return function (d, b) {
          _extendStatics6(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Jewel = void 0;

      var OffsetGroup_1 = require("./OffsetGroup");

      var Jewel =
      /** @class */
      function (_super) {
        __extends(Jewel, _super);

        function Jewel(param) {
          var _this = _super.call(this, param) || this;

          _this._init(param);

          return _this;
        }

        Jewel.prototype.respawn = function (position) {
          this.jewel.x = position.x;
          this.jewel.y = position.y;
          this.jewel.modified();
        };

        Jewel.prototype._init = function (param) {
          var jewelAsset = this.parent.scene.assets.main_jewel_body;
          this.jewel = new g.Sprite({
            scene: this.parent.scene,
            x: param.x,
            y: param.y,
            anchorX: 0.5,
            anchorY: 0.5,
            src: jewelAsset,
            width: jewelAsset.width,
            height: jewelAsset.height
          });
          this.root.append(this.jewel);
        };

        return Jewel;
      }(OffsetGroup_1.OffsetGroup);

      exports.Jewel = Jewel;
    }, {
      "./OffsetGroup": 30
    }],
    29: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics7 = function extendStatics(d, b) {
          _extendStatics7 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics7(d, b);
        };

        return function (d, b) {
          _extendStatics7(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.MiniMap = void 0;
      /**
       * ミニマップ表示
       */

      var MiniMap =
      /** @class */
      function (_super) {
        __extends(MiniMap, _super);

        function MiniMap(param) {
          var _this = _super.call(this, param) || this;

          _this._scale = _this.width / param.field.width;
          _this._yourPosition = new g.FilledRect({
            scene: _this.scene,
            cssColor: "red",
            width: 8,
            height: 8,
            local: true
          });

          _this.append(_this._yourPosition);

          _this._jewelPosition = new g.FilledRect({
            scene: _this.scene,
            cssColor: "yellow",
            width: 8,
            height: 8,
            local: true
          });

          _this.append(_this._jewelPosition);

          _this._foodPosition = [];
          _this._unusedFoodResource = [];
          return _this;
        }
        /**
         * 描画内容の更新
         */


        MiniMap.prototype.updateMap = function (param) {
          this._scale = this.width / param.field.width;

          this._flushFoodsAssign();

          this._updateMapSnake(param);

          this._updateMapFoods(param);

          this._updateMapJewel(param);
        };

        MiniMap.prototype._updateMapSnake = function (param) {
          if (!param.yourPlayerInfo.snake) return;
          var snake = param.yourPlayerInfo.snake;
          this._yourPosition.x = this.width / 2 + snake.head.x * this._scale - this._yourPosition.width / 2;
          this._yourPosition.y = this.height / 2 + snake.head.y * this._scale - this._yourPosition.height / 2;

          this._ThinOutModified(this._yourPosition);
        };

        MiniMap.prototype._updateMapFoods = function (param) {
          var _this = this;

          param.foodList.forEach(function (shownFood) {
            if (_this._unusedFoodResource.length) {
              var food = _this._unusedFoodResource.pop();

              food.x = _this.width / 2 + shownFood.food.x * _this._scale;
              food.y = _this.height / 2 + shownFood.food.y * _this._scale;
              food.opacity = 1;

              _this._foodPosition.push(food);
            } else {
              // 余っているリソースが無ければ新たに作る
              var food = new g.FilledRect({
                scene: _this.scene,
                cssColor: "white",
                width: 2,
                height: 2,
                x: _this.width / 2 + shownFood.food.x * _this._scale,
                y: _this.height / 2 + shownFood.food.y * _this._scale,
                local: true
              });

              _this._foodPosition.push(food);

              _this.append(food);
            }
          });
        };

        MiniMap.prototype._flushFoodsAssign = function () {
          var _this = this;

          this._foodPosition.forEach(function (food) {
            food.opacity = 0;

            _this._ThinOutModified(food);

            _this._unusedFoodResource.push(food);
          });

          this._foodPosition = [];
        };

        MiniMap.prototype._updateMapJewel = function (param) {
          this._jewelPosition.x = this.width / 2 + param.jewelCommonOffset.x * this._scale - this._yourPosition.width / 2;
          this._jewelPosition.y = this.height / 2 + param.jewelCommonOffset.y * this._scale - this._yourPosition.height / 2;

          this._ThinOutModified(this._jewelPosition);
        }; // 親Paneの再描画を間引く


        MiniMap.prototype._ThinOutModified = function (entity) {
          if (g.game.age % 2 !== 0) return;
          entity.modified();
        };

        return MiniMap;
      }(g.Pane);

      exports.MiniMap = MiniMap;
    }, {}],
    30: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.OffsetGroup = void 0;

      var OffsetGroup =
      /** @class */
      function () {
        function OffsetGroup(param) {
          this.parent = param.parent;
          this.root = new g.E({
            scene: this.parent.scene
          });
          this.parent.append(this.root);
        }

        OffsetGroup.prototype.destroy = function () {
          this.root.destroy();
        };

        return OffsetGroup;
      }();

      exports.OffsetGroup = OffsetGroup;
    }, {}],
    31: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics8 = function extendStatics(d, b) {
          _extendStatics8 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics8(d, b);
        };

        return function (d, b) {
          _extendStatics8(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.noticeY = exports.PopupNotice = exports.NoticeType = void 0;

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var akashic_label_1 = require("@akashic-extension/akashic-label");

      var utils_1 = require("../commonUtils/utils");

      var NoticeType;

      (function (NoticeType) {
        /**
         * キル通知
         */
        NoticeType["Kill"] = "Kill";
        /**
         * お宝ゲット通知
         */

        NoticeType["Jewel"] = "Jewel";
        /**
         * お宝チャンス通知
         */

        NoticeType["Chance"] = "Chance";
      })(NoticeType = exports.NoticeType || (exports.NoticeType = {}));

      var PopupNotice =
      /** @class */
      function (_super) {
        __extends(PopupNotice, _super);

        function PopupNotice(param) {
          var _this = _super.call(this, param) || this;

          _this.timeline = new akashic_timeline_1.Timeline(_this.scene);
          _this.font = param.font;
          _this.name = utils_1.clampString(param.name, 10, "…");

          switch (param.noticeType) {
            case NoticeType.Kill:
              _this._createKillNotice();

              break;

            case NoticeType.Jewel:
              _this._createJewelNotice();

              break;

            case NoticeType.Chance:
              _this._createChanceNotice();

              break;

            default: // do nothing

          }

          return _this;
        }

        PopupNotice.prototype.up = function (nextIdx) {
          this.timeline.create(this).moveTo(852, exports.noticeY[nextIdx], 150);
        };

        PopupNotice.prototype.fadeInUp = function () {
          this.timeline.create(this).moveTo(852, 478, 100).con().to({
            opacity: 0.9
          }, 150);
          this.timeline.create(this).wait(5000).fadeOut(150);
        };

        PopupNotice.prototype.fadeOutUp = function () {
          this.timeline.create(this).moveTo(852, 178, 100).con().fadeOut(150);
        };

        PopupNotice.prototype._createKillNotice = function () {
          var killPopSpriteAsset = this.scene.assets.main_rpop_head_kill;
          var killPopSprite = new g.Sprite({
            scene: this.scene,
            src: killPopSpriteAsset,
            width: killPopSpriteAsset.width,
            height: killPopSpriteAsset.height,
            x: this.width - killPopSpriteAsset.width
          });
          this.append(killPopSprite);

          var nameArea = this._fillInBlanks(killPopSprite.x, this.name);

          this._createLabel(nameArea);
        };

        PopupNotice.prototype._createJewelNotice = function () {
          var jewelPopSpriteAsset = this.scene.assets.main_rpop_head_jewel;
          var jewelPopSprite = new g.Sprite({
            scene: this.scene,
            src: jewelPopSpriteAsset,
            width: jewelPopSpriteAsset.width,
            height: jewelPopSpriteAsset.height,
            x: this.width - jewelPopSpriteAsset.width
          });
          this.append(jewelPopSprite);

          var nameArea = this._fillInBlanks(jewelPopSprite.x, this.name);

          this._createLabel(nameArea);
        };

        PopupNotice.prototype._createChanceNotice = function () {
          var chancePopSpriteAsset = this.scene.assets.red_rpop_head_chance;
          var chancePopSprite = new g.Sprite({
            scene: this.scene,
            src: chancePopSpriteAsset,
            width: chancePopSpriteAsset.width,
            height: chancePopSpriteAsset.height,
            x: this.width - chancePopSpriteAsset.width
          });
          this.append(chancePopSprite);

          this._createChanceLabel(chancePopSprite.x, "フィールド上にお宝が落ちています！");
        };

        PopupNotice.prototype._fillInBlanks = function (rightX, name) {
          var popBodyLength = Math.ceil(this.font.measureText(name).width * 18 / (this.font.size * 40));
          var popBodySpriteAsset = this.scene.assets.main_rpop_body;

          for (var i = 1; i <= popBodyLength; i++) {
            var body = new g.Sprite({
              scene: this.scene,
              src: popBodySpriteAsset,
              width: popBodySpriteAsset.width,
              height: popBodySpriteAsset.height,
              x: rightX - popBodySpriteAsset.width * i
            });
            this.append(body);
          }

          var popTailSpriteAsset = this.scene.assets.main_rpop_tail;
          var tail = new g.Sprite({
            scene: this.scene,
            src: popTailSpriteAsset,
            width: popTailSpriteAsset.width,
            height: popTailSpriteAsset.height,
            x: rightX - popBodySpriteAsset.width * popBodyLength - popTailSpriteAsset.width
          });
          this.append(tail);
          return {
            nameAreaX: rightX - popBodySpriteAsset.width * popBodyLength,
            nameAreaWidth: popBodyLength * 40
          };
        };

        PopupNotice.prototype._createLabel = function (param) {
          this.label = new akashic_label_1.Label({
            scene: this.scene,
            text: this.name,
            textColor: "white",
            font: this.font,
            fontSize: 18,
            width: param.nameAreaWidth,
            x: param.nameAreaX,
            y: 12,
            trimMarginTop: true,
            textAlign: "right"
          });
          this.append(this.label);
        };

        PopupNotice.prototype._createChanceLabel = function (rightX, text) {
          var popBodySpriteAsset = this.scene.assets.red_rpop_body;

          for (var i = 1; i <= 4; i++) {
            var body = new g.Sprite({
              scene: this.scene,
              src: popBodySpriteAsset,
              width: popBodySpriteAsset.width,
              height: popBodySpriteAsset.height,
              x: rightX - popBodySpriteAsset.width * i
            });
            this.append(body);
          }

          var popTailSpriteAsset = this.scene.assets.red_rpop_tail;
          var tail = new g.Sprite({
            scene: this.scene,
            src: popTailSpriteAsset,
            width: popTailSpriteAsset.width,
            height: popTailSpriteAsset.height,
            x: rightX - popBodySpriteAsset.width * 4 - popTailSpriteAsset.width
          });
          this.append(tail);
          this.label = new akashic_label_1.Label({
            scene: this.scene,
            text: text,
            textColor: "white",
            font: this.font,
            fontSize: 16,
            width: 8 * 40,
            x: rightX - popBodySpriteAsset.width * 4 - 56,
            y: 12,
            trimMarginTop: true,
            textAlign: "right"
          });
          this.append(this.label);
        };

        return PopupNotice;
      }(g.E);

      exports.PopupNotice = PopupNotice;
      exports.noticeY = [478, 428, 378, 328, 278, 228];
    }, {
      "../commonUtils/utils": 23,
      "@akashic-extension/akashic-label": 8,
      "@akashic-extension/akashic-timeline": 15
    }],
    32: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics9 = function extendStatics(d, b) {
          _extendStatics9 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics9(d, b);
        };

        return function (d, b) {
          _extendStatics9(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.ScrollSpeedType = exports.RankingLabel = void 0;

      var akashic_label_1 = require("@akashic-extension/akashic-label");

      var utils_1 = require("../../commonUtils/utils");

      var RankingLabel =
      /** @class */
      function (_super) {
        __extends(RankingLabel, _super);

        function RankingLabel(param) {
          var _this = _super.call(this, param) || this;

          _this._resultNumFont = param.resultNumFont;
          _this._resultNumRedFont = param.resultNumRedFont;
          _this._rankingPlayerIdList = param.rankingPlayerIdList;
          _this._scrollTimeUnit = 30;
          _this._scrollTween = null;

          _this._init();

          return _this;
        }

        RankingLabel.prototype.scroll = function (speedType) {
          var _this = this;

          if (speedType === void 0) {
            speedType = ScrollSpeedType.Normal;
          }

          switch (speedType) {
            case ScrollSpeedType.Normal:
              this._scrollTimeUnit = 30;
              break;

            case ScrollSpeedType.High:
              this._scrollTimeUnit = 3;
              break;

            default: // do nothing

          }

          var createScrollTween = function createScrollTween() {
            var moveDistance = 53 * _this._rankingPlayerIdList.length + 137 - 50;
            _this._scrollTween = _this.scene.timeline.create(_this._root, {
              loop: true
            }).wait(200 * _this._scrollTimeUnit).moveTo(0, -moveDistance, (moveDistance + _this._root.y) * _this._scrollTimeUnit).call(function () {
              _this._root.y = 470;

              _this._root.modified();
            }).moveTo(0, 0, (437 - 137) * _this._scrollTimeUnit);
          };

          if (this._scrollTween != null) {
            this.scene.timeline.remove(this._scrollTween);
            this._scrollTween = null;

            if (this._root.y > 0 && this._root.y <= 470) {
              // 一通り表示が終わり、下から名前が上がってきている間に速度変更した場合
              this._scrollTween = this.scene.timeline.create(this._root).moveTo(0, 0, 300 * this._root.y / 470 * this._scrollTimeUnit).call(function () {
                _this.scene.timeline.remove(_this._scrollTween);

                _this._scrollTween = null;
                createScrollTween();
              });
            } else {
              // ランキングスクロール中に速度変更した場合
              var moveDistance = 53 * this._rankingPlayerIdList.length + 137 - 50;
              this._scrollTween = this.scene.timeline.create(this._root).moveTo(0, -moveDistance, (moveDistance + this._root.y) * this._scrollTimeUnit).call(function () {
                _this._root.y = 470;

                _this._root.modified();
              }).moveTo(0, 0, (437 - 137) * this._scrollTimeUnit).call(function () {
                _this.scene.timeline.remove(_this._scrollTween);

                _this._scrollTween = null;
                createScrollTween();
              });
            }
          } else {
            createScrollTween();
          }
        };

        RankingLabel.prototype.setInitialPosition = function () {
          this._root.x = 0;
          this._root.y = 0;

          this._root.modified();

          if (this._scrollTween != null) {
            this.scene.timeline.remove(this._scrollTween);
            this._scrollTween = null;
          }
        };

        RankingLabel.prototype._init = function () {
          this._createRoot();

          this._createRankLabels();

          this._createRankingNames();

          this._createCountLabels();
        };

        RankingLabel.prototype._createRoot = function () {
          this._root = new g.E({
            scene: this.scene
          });
          this.append(this._root);
        };

        RankingLabel.prototype._createRankLabels = function () {
          var _this = this;

          this._rankingPlayerIdList.forEach(function (_, rank) {
            var rankLabel = new akashic_label_1.Label({
              scene: _this.scene,
              text: "" + (rank + 1),
              font: rank === 0 ? _this._resultNumRedFont : _this._resultNumFont,
              fontSize: 36,
              width: _this._resultNumFont.defaultGlyphWidth * 3,
              x: 40,
              y: 137 - 50 + 53 * rank,
              textAlign: "right"
            });

            _this._root.append(rankLabel);

            var unitLabelAsset = _this.scene.assets.result_unit_i_b;
            var unitRedLabelAsset = _this.scene.assets.result_unit_i_r;
            var unitLabel = new g.Sprite({
              scene: _this.scene,
              src: rank === 0 ? unitRedLabelAsset : unitLabelAsset,
              x: 278 - 151,
              y: 143 - 50 + 53 * rank
            });

            _this._root.append(unitLabel);
          });
        };

        RankingLabel.prototype._createRankingNames = function () {
          var _this = this;

          this._rankingPlayerIdList.forEach(function (data, rank) {
            var name = utils_1.clampString(_this.scene.stateManager.playerList[data.playerId].user.name, 14, "…");
            var rankingName = new akashic_label_1.Label({
              scene: _this.scene,
              text: "" + name,
              textColor: "white",
              font: _this.scene.stateManager.resource.font,
              fontSize: 34,
              width: 978,
              x: 359 - 151,
              y: 137 - 52 + 53 * rank // デザイン仕様

            });

            _this._root.append(rankingName);
          });
        };

        RankingLabel.prototype._createCountLabels = function () {
          var _this = this;

          this._rankingPlayerIdList.forEach(function (data, rank) {
            var countLabel = new akashic_label_1.Label({
              scene: _this.scene,
              text: "" + data.count,
              font: rank === 0 ? _this._resultNumRedFont : _this._resultNumFont,
              fontSize: 36,
              width: _this._resultNumFont.defaultGlyphWidth * 3,
              x: 955 - 151,
              y: 137 - 50 + 53 * rank,
              textAlign: "right"
            });

            _this._root.append(countLabel);
          });
        };

        return RankingLabel;
      }(g.Pane);

      exports.RankingLabel = RankingLabel;
      var ScrollSpeedType;

      (function (ScrollSpeedType) {
        ScrollSpeedType["Normal"] = "Normal";
        ScrollSpeedType["High"] = "High";
      })(ScrollSpeedType = exports.ScrollSpeedType || (exports.ScrollSpeedType = {}));
    }, {
      "../../commonUtils/utils": 23,
      "@akashic-extension/akashic-label": 8
    }],
    33: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics10 = function extendStatics(d, b) {
          _extendStatics10 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics10(d, b);
        };

        return function (d, b) {
          _extendStatics10(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.ScorePanel = void 0;

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var akashic_label_1 = require("@akashic-extension/akashic-label");

      var ScorePanel =
      /** @class */
      function (_super) {
        __extends(ScorePanel, _super);

        function ScorePanel(param) {
          var _this = _super.call(this, param) || this;

          _this.timeline = new akashic_timeline_1.Timeline(_this.scene);
          _this.scoreUpTween = null;
          _this.bg = new g.Sprite({
            scene: param.scene,
            src: param.backgroundImage
          });

          _this.append(_this.bg);

          _this._createLabel(param.score);

          return _this;
        }

        ScorePanel.prototype.updateScore = function (score) {
          this.label.text = "" + score;
          this.label.invalidate();
        };

        ScorePanel.prototype.swell = function () {
          var _this = this;

          if (this.scoreUpTween != null) return;
          this.scoreUpTween = this.timeline.create(this).to({
            scaleY: 0.9
          }, 200).to({
            scaleY: 1.25
          }, 400, akashic_timeline_1.Easing.easeOutCubic).to({
            scaleY: 1.0
          }, 200, akashic_timeline_1.Easing.easeInExpo).call(function () {
            _this.timeline.remove(_this.scoreUpTween);

            _this.scoreUpTween = null;
          });
        };

        ScorePanel.prototype._createLabel = function (score) {
          var scoreFontGlyph = JSON.parse(this.scene.assets.main_num_score_glyph.data);
          this.scoreFont = new g.BitmapFont({
            src: this.scene.assets.main_num_score,
            map: scoreFontGlyph,
            defaultGlyphWidth: 16,
            defaultGlyphHeight: 28
          });
          this.label = new akashic_label_1.Label({
            scene: this.scene,
            text: "" + score,
            font: this.scoreFont,
            fontSize: 28,
            width: 16 * 3,
            x: 121,
            y: 21,
            textAlign: "center"
          });
          this.append(this.label);
        };

        return ScorePanel;
      }(g.E);

      exports.ScorePanel = ScorePanel;
    }, {
      "@akashic-extension/akashic-label": 8,
      "@akashic-extension/akashic-timeline": 15
    }],
    34: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics11 = function extendStatics(d, b) {
          _extendStatics11 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics11(d, b);
        };

        return function (d, b) {
          _extendStatics11(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.SnakeSegmentType = exports.SnakeRotateState = exports.SnakeSegment = exports.Snake = void 0;

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var OffsetGroup_1 = require("./OffsetGroup");

      var UserTouchState_1 = require("../types/UserTouchState");

      var MessageEventType_1 = require("../types/MessageEventType");

      var entityUtils_1 = require("../utils/entityUtils");
      /**
       * Snakeクラス
       */


      var Snake =
      /** @class */
      function (_super) {
        __extends(Snake, _super);

        function Snake(param) {
          var _this = _super.call(this, param) || this;

          _this.timeline = new akashic_timeline_1.Timeline(_this.parent.scene);
          _this.snakeType = param.snakeType;
          _this.segments = [];
          _this.angle = param.angle;
          _this._internalVecBaseScale = param.snakeBaseSpeed;
          _this._internalVecMaxScaleByBase = param.snakeMaxSpeedScale;
          _this._vecScale = 1;
          _this._snakeMaxKnotLength = param.snakeMaxKnotLength;
          _this.historyDistanceInterval = Math.round(90 / param.snakeBaseSpeed);
          _this.rotateState = SnakeRotateState.noRotate;
          _this.words = param.words;
          _this.haveJewel = false;
          _this.tweens = {};
          if (param.rebornEffect) _this._initEffectLayer();

          _this._initLayer();

          _this._initFromParam(param);

          _this._initHead(param);

          _this._initBodySegments(param);

          _this._applySegmentPositions();

          if (param.rebornEffect) _this._initRebornEffect(param);
          return _this;
        }

        Snake.prototype.update = function (param) {
          this._evolutionPositionHistory(param);

          this._applySegmentPositions();

          this._adjustHeadDirection(param.angle);
        };
        /**
         * エサを食べる
         */


        Snake.prototype.eatFood = function (food) {
          this._addKnot(food);
        };
        /**
         * お宝を食べる
         */


        Snake.prototype.eatJewel = function () {
          this.haveJewel = true;

          this._addJewel();
        };
        /**
         * お宝を消す
         */


        Snake.prototype.removeJewel = function () {
          if (!this.haveJewel) return;
          this.haveJewel = false;
          var jewel = this.segments.pop();
          if (!jewel.destroyed()) jewel.destroy();
        };
        /**
         * スネークの透過度を指定値に変更する
         */


        Snake.prototype.modifyOpacity = function (opacity) {
          this.head.opacity = opacity;
          this.head.modified();
          this.segments.forEach(function (seg) {
            seg.opacity = opacity;
            seg.modified();
          });
        };
        /**
         * 点滅アニメーション
         */


        Snake.prototype.blinking = function () {
          var _this = this;

          if (this.tweens[MessageEventType_1.AnimationType.Blinking] != null) return;
          this.tweens[MessageEventType_1.AnimationType.Blinking] = this.timeline.create(this, {
            loop: true
          }).wait(100).call(function () {
            return _this.modifyOpacity(1.0);
          }).wait(100).call(function () {
            return _this.modifyOpacity(0.5);
          });
        };
        /**
         * ダッシュエフェクト
         */


        Snake.prototype.dashing = function (state) {
          if (state === UserTouchState_1.UserTouchState.onDoubleTap) {
            if (this.head.dashEffect.visible()) return;
            this.head.dashEffect.show();
          } else {
            if (!this.head.dashEffect.visible()) return;
            this.head.dashEffect.hide();
          }
        };
        /**
         * 爆破エフェクト
         */


        Snake.prototype.explosion = function () {
          var _this = this;

          var explosionAsset = this.parent.scene.assets.explosion_effect;

          var createEffect = function createEffect(x, y) {
            var camera = g.game.focusingCamera;
            if (!camera) return;
            var margin = 50;
            if (x < camera.x - margin || x > camera.x + g.game.width + margin || y < camera.y - margin || y > camera.y + g.game.height + margin) return; // 画面外はエフェクトを作らない

            var effect = new g.FrameSprite({
              scene: _this.parent.scene,
              src: explosionAsset,
              frames: [0, 1, 2, 3, 4, 5, 6, 7],
              width: 140,
              height: 140,
              srcWidth: 140,
              srcHeight: 140,
              loop: false,
              interval: 100,
              x: x,
              y: y,
              anchorX: 0.5,
              anchorY: 0.5,
              local: true //  生成タイミングが不定になるためentity id採番に影響しないようlocal化

            });
            effect.onFinish.add(function () {
              _this.knotLayer.remove(effect);

              if (effect.destroyed()) effect.destroy();
            });
            effect.start();

            _this.knotLayer.append(effect);
          };

          var deathHeadAsset = this.parent.scene.assets["snake" + this.snakeType + "_head_death"];
          this.head.body._surface = g.SurfaceUtil.asSurface(deathHeadAsset);
          this.head.body.invalidate();
          createEffect(this.head.x + this.head.body.x + this.head.body.width / 2, this.head.y + this.head.body.y + this.head.body.height / 2);
          this.segments.forEach(function (seg, i) {
            if (seg.type === SnakeSegmentType.Jewel) {
              seg.body.hide();
              return;
            }

            _this.root.scene.setTimeout(function () {
              seg.body.hide();
              if (seg.wordLabel != null) seg.wordLabel.hide();
              createEffect(seg.x + seg.body.x + seg.body.width / 2, seg.y + seg.body.y + seg.body.height / 2);
            }, 100 * i + 100, _this);
          });
        };
        /**
         * Tween削除
         */


        Snake.prototype.removeTween = function (animationType) {
          if (this.tweens[animationType] == null) return;
          this.timeline.remove(this.tweens[animationType]);
          this.tweens[animationType] = null;
        };

        Snake.prototype._initEffectLayer = function () {
          this.effectPaneLayer = new g.E({
            scene: this.parent.scene
          });
          this.root.append(this.effectPaneLayer);
          this.effectPaneBackground = new g.E({
            scene: this.parent.scene
          });
          this.effectPaneLayer.append(this.effectPaneBackground);
          this.effectPane = new g.Pane({
            scene: this.parent.scene,
            width: 0,
            height: 200
          });
          this.effectPaneLayer.append(this.effectPane);
          this.effectPaneBack = new g.E({
            scene: this.parent.scene
          });
          this.effectPane.append(this.effectPaneBack);
        };

        Snake.prototype._clearEffectPane = function () {
          this.effectPane.width = 0;
          this.effectPane.height = 0;
          this.effectPane.destroy();
        };
        /**
         * Layer初期化
         */


        Snake.prototype._initLayer = function () {
          this.knotLayer = new g.E({
            scene: this.parent.scene
          });
          this.root.append(this.knotLayer);
          this.headLayer = new g.E({
            scene: this.parent.scene
          });
          this.root.append(this.headLayer);
          this.jewelLayer = new g.E({
            scene: this.parent.scene
          });
          this.root.append(this.jewelLayer);
        };
        /**
         * paramからそれらしいhistoryを作る
         */


        Snake.prototype._initFromParam = function (param) {
          var _this = this;

          var isRightVec = param.angle === 0;
          this.positionHistory = []; // あたかも初期化前からheadPositionHistoryが蓄積されていたように振舞わせる
          // SegmentとSegmentの間には historyDistanceInterval フレーム数だけ間隔を設ける

          param.words.forEach(function (_, index) {
            var segmentIndex = index;

            for (var i = 0; i < _this.historyDistanceInterval; i++) {
              var frame = segmentIndex * _this.historyDistanceInterval + i;

              _this.positionHistory.push({
                x: param.x + _this._internalVecBaseScale * frame * (isRightVec ? -1 : 1),
                y: param.y,
                angle: _this.angle
              });
            }
          });
        };

        Snake.prototype._initHead = function (param) {
          this.head = new SnakeSegment({
            scene: this.parent.scene,
            x: param.x,
            y: param.y,
            angle: param.angle,
            assetId: "snake" + this.snakeType + "_head_alive",
            type: SnakeSegmentType.Head
          });
          this.headLayer.append(this.head);
        };

        Snake.prototype._initBodySegments = function (param) {
          var _this = this;

          var revWords = param.words.slice();
          revWords.reverse();
          revWords.forEach(function (word) {
            var segment = new SnakeSegment({
              scene: _this.parent.scene,
              x: 0,
              y: 0,
              angle: param.angle,
              assetId: "snake" + _this.snakeType + "_body",
              word: word,
              font: param.font,
              type: SnakeSegmentType.Knot
            });

            _this.segments.unshift(segment);

            _this.knotLayer.append(segment);
          });
        };

        Snake.prototype._initRebornEffect = function (param) {
          var _this = this;

          var isRightVec = param.angle === 0; // 右向きの初期化かどうか。真右または真左方向のみとりうるangleと仮定して扱う
          // Effect Layerの位置初期化

          if (isRightVec) {
            this.effectPane.x = this.head.x + this.head.body.x + 200;
            this.effectPane.y = this.head.y + this.head.body.y;
          } else {
            this.effectPane.x = this.head.x + this.head.body.x;
            this.effectPane.y = this.head.y + this.head.body.y;
          }

          var prevFrame = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
          var centerFrame = new Array(25).fill(10);
          var postFrame = [11, 12, 13, 14, 15, 16, 17];
          var portalFrames = prevFrame.concat(centerFrame, postFrame); // 演出の初期化

          var portalAsset = param.parent.scene.assets.snake_reborn;
          var portalTextAsset = param.parent.scene.assets.snake_reborn_text;
          var portal = new g.FrameSprite({
            scene: param.parent.scene,
            src: portalAsset,
            frames: portalFrames,
            width: 468,
            height: 370,
            srcWidth: 468,
            srcHeight: 370,
            loop: false,
            interval: 100,
            scaleX: isRightVec ? -1 : 1,
            x: isRightVec ? this.effectPane.x + 380 : this.effectPane.x - 480,
            y: this.effectPane.y - 188
          });
          portal.start();
          this.effectPaneBackground.append(portal);
          var portalText = new g.Sprite({
            scene: param.parent.scene,
            src: portalTextAsset,
            x: isRightVec ? portal.x - 420 : portal.x + 300,
            y: portal.y
          });
          this.effectPaneBackground.append(portalText);

          this._drawOnPaneLayer(); // 描画をPaneに移す


          var updateHandler = function updateHandler() {
            _this._updateEffctPaneLayerPosition(isRightVec);
          };

          portal.onUpdate.add(updateHandler, this);
          param.parent.scene.setTimeout(function () {
            portal.destroy();
            portalText.destroy();

            _this._drawOnNormalLayer();

            _this._clearEffectPane(); // Paneをwipeする


            param.onEndRebornEffect();
          }, portalFrames.length * 100, this);
        };

        Snake.prototype._evolutionPositionHistory = function (param) {
          var currentHeadPositionX = this.head.x;
          var currentHeadPositionY = this.head.y;
          var vecScale = this._internalVecBaseScale;

          if (param.state === UserTouchState_1.UserTouchState.onDoubleTap) {
            vecScale *= this._internalVecMaxScaleByBase;
          }

          var rad = param.angle / 180 * Math.PI;
          this.head.x += Math.sin(rad) * vecScale;
          this.head.y += -Math.cos(rad) * vecScale;
          this.head.angle = param.angle; // フィールド壁判定

          this._checkFieldBoundary(currentHeadPositionX, currentHeadPositionY, rad, param.field.width, vecScale);

          this._appendNewPositionHistory(param);
        };
        /**
         * フィールドの壁判定
         */


        Snake.prototype._checkFieldBoundary = function (currentHeadPositionX, currentHeadPositionY, rad, fieldWidth, vecScale) {
          var limitRadius = fieldWidth / 2;

          if (Math.pow(this.head.x, 2) + Math.pow(this.head.y, 2) >= Math.pow(limitRadius, 2)) {
            var vX = 1;
            var vY = (1 - currentHeadPositionX * vX) / currentHeadPositionY;

            if (this.rotateState === SnakeRotateState.noRotate) {
              // 壁衝突時に外積を求め、回転の向きを定める
              var check = currentHeadPositionX * -Math.cos(rad) - currentHeadPositionY * Math.sin(rad);
              if (check > 0) this.rotateState = SnakeRotateState.onClockwise;else this.rotateState = SnakeRotateState.onCounterClockwise;
            }

            if (this.head.y >= 0 && this.rotateState === SnakeRotateState.onClockwise || this.head.y <= 0 && this.rotateState === SnakeRotateState.onCounterClockwise) {
              vX = -vX;
              vY = -vY;
            }

            if (this.rotateState === SnakeRotateState.onClockwise && (this.head.x > 0 && this.head.y > 0 && vX < 0 && vY < 0 || this.head.x < 0 && this.head.y < 0 && vX > 0 && vY > 0)) {
              vX = -vX;
              vY = -vY;
            }

            var tangentLineNorm = Math.sqrt(Math.abs(Math.pow(vX, 2) + Math.pow(vY, 2)));
            this.head.x = currentHeadPositionX + vX / tangentLineNorm * vecScale;
            this.head.y = currentHeadPositionY + vY / tangentLineNorm * vecScale;
            var norm = Math.sqrt(Math.abs(Math.pow(this.head.x, 2) + Math.pow(this.head.y, 2)));
            this.head.x -= (norm - limitRadius) / norm * this.head.x;
            this.head.y -= (norm - limitRadius) / norm * this.head.y;
            var acos = Math.acos(vX / Math.sqrt(Math.pow(vX, 2) + Math.pow(vY, 2)));
            this.head.angle = ((this.rotateState === SnakeRotateState.onClockwise ? (this.head.x <= 0 ? -acos : acos) * 180 / Math.PI + 90 : (this.head.x >= 0 ? -acos : acos) * 180 / Math.PI + 90) + 360) % 360;
          } else {
            this.rotateState = SnakeRotateState.noRotate;
          }

          this.head.modified();
        };

        Snake.prototype._appendNewPositionHistory = function (param) {
          var currentHeadPositionX = this.head.x;
          var currentHeadPositionY = this.head.y;
          var currentHeadAngle = this.angle; // 先頭に新しい座標をつける

          var appendPositionHistory = []; // ダッシュ中は補完フレームを増やす
          // maxSpeedScaleに応じて増やし、整数倍に限る

          if (param.state === UserTouchState_1.UserTouchState.onDoubleTap && !!this.positionHistory[0] && this._internalVecMaxScaleByBase > 1) {
            var diff = {
              x: (currentHeadPositionX - this.positionHistory[0].x) / this._internalVecMaxScaleByBase,
              y: (currentHeadPositionY - this.positionHistory[0].y) / this._internalVecMaxScaleByBase,
              angle: (currentHeadAngle - this.positionHistory[0].angle) / this._internalVecMaxScaleByBase
            };

            for (var i = 1; i < this._internalVecMaxScaleByBase; i++) {
              // _internalVecMaxScaleByBase - 1回だけ追加する
              var intervalElement = {
                x: this.positionHistory[0].x + diff.x * i,
                y: this.positionHistory[0].y + diff.y * i,
                angle: this.positionHistory[0].angle + diff.angle * i
              };
              appendPositionHistory.push(intervalElement);
            }

            appendPositionHistory = appendPositionHistory.reverse();
          }

          appendPositionHistory = [{
            x: currentHeadPositionX,
            y: currentHeadPositionY,
            angle: currentHeadAngle
          }].concat(appendPositionHistory);
          this.positionHistory = appendPositionHistory.concat(this.positionHistory); // positionHistoryの長さを制限する

          var maxHistoryLenth = this.historyDistanceInterval * (this._snakeMaxKnotLength + 5);
          if (this.positionHistory.length > maxHistoryLenth) this.positionHistory.length = maxHistoryLenth;
        };

        Snake.prototype._updateEffctPaneLayerPosition = function (isRightVec) {
          if (isRightVec) {
            this.effectPane.width += this._internalVecBaseScale;
            this.effectPane.modified();
          } else {
            this.effectPane.x = this.head.x + this.head.body.x - 100;
            this.effectPane.width += this._internalVecBaseScale;
            this.effectPane.modified();
          }

          this.effectPane.y = this.head.y + this.head.body.y - 100;
          this.effectPaneBack.x = -this.effectPane.x;
          this.effectPaneBack.y = -this.effectPane.y;
          this.effectPaneBack.modified();
        };
        /**
         * 現在の状態に応じてSnake全体を前に動かす
         */


        Snake.prototype._applySegmentPositions = function () {
          var _this = this;

          var camera = g.game.focusingCamera;
          var margin = 50; // 各SnakeSegmentに位置を反映する

          this.segments.forEach(function (segment, index) {
            var frame = (index + 1) * _this.historyDistanceInterval;
            var positionBase = _this.positionHistory[frame] ? _this.positionHistory[frame] : _this.head;
            segment.x = positionBase.x;
            segment.y = positionBase.y;
            segment.angle = positionBase.angle;
            segment.modified();

            if (camera) {
              if (segment.x < camera.x - margin || segment.x > camera.x + g.game.width + margin || segment.y < camera.y - margin || segment.y > camera.y + g.game.height + margin) {
                segment.hide();
              } else {
                segment.show();
              }
            }
          });
        };
        /**
         * スネークの顔の向きを調整する
         */


        Snake.prototype._adjustHeadDirection = function (angle) {
          if (angle >= 0 && angle < 180) {
            this.head.scaleX = -1;
          } else {
            this.head.scaleX = 1;
          }

          this.head.modified();
        };
        /**
         * 節の追加
         */


        Snake.prototype._addKnot = function (food) {
          var _this = this;

          this.words.push(food.word);
          var tmpSegments = []; // this.segments の逆順でSnakeSegmentを一時的に保持

          this.segments.forEach(function (seg) {
            if (seg.type !== SnakeSegmentType.Knot) return;

            if (!seg.destroyed()) {
              _this.knotLayer.remove(seg);

              tmpSegments.unshift(seg);
            }
          });

          if (this.haveJewel) {
            this.segments = [this.segments[this.segments.length - 1]];
          } else {
            this.segments = [];
          }

          var segment = new SnakeSegment({
            scene: this.parent.scene,
            x: 0,
            y: 0,
            angle: this.angle,
            assetId: this.haveJewel ? "snake_body_gold" : "snake" + this.snakeType + "_body",
            word: food.word,
            font: food.font,
            type: SnakeSegmentType.Knot
          });
          this.segments.unshift(segment);
          this.knotLayer.append(segment);
          tmpSegments.forEach(function (seg) {
            if (_this.segments.length - (_this.haveJewel ? 1 : 0) >= _this._snakeMaxKnotLength && seg.type === SnakeSegmentType.Knot) return;

            _this.segments.unshift(seg);

            _this.knotLayer.append(seg);
          });
        };
        /**
         * お宝の追加
         */


        Snake.prototype._addJewel = function () {
          var segment = new SnakeSegment({
            scene: this.parent.scene,
            x: 0,
            y: 0,
            angle: this.angle,
            assetId: "main_jewel_body",
            type: SnakeSegmentType.Jewel
          });
          this.segments.push(segment);
          this.jewelLayer.append(segment);
        };

        Snake.prototype._changeDrawLayer = function (layer) {
          this.head.remove();
          this.segments.forEach(function (segment) {
            segment.remove();
          });
          layer.append(this.head);
          this.segments.forEach(function (segment) {
            layer.append(segment);
            segment.modified();
          });
        };

        Snake.prototype._drawOnPaneLayer = function () {
          this._changeDrawLayer(this.effectPaneBack);
        };

        Snake.prototype._drawOnNormalLayer = function () {
          var _this = this;

          this.head.remove();
          this.segments.forEach(function (segment) {
            segment.remove();
          });
          this.headLayer.append(this.head);
          this.segments.forEach(function (segment) {
            _this.knotLayer.append(segment);

            segment.modified();
          });
        };

        return Snake;
      }(OffsetGroup_1.OffsetGroup);

      exports.Snake = Snake;
      /**
       * Snakeの体節単位のクラス
       */

      var SnakeSegment =
      /** @class */
      function (_super) {
        __extends(SnakeSegment, _super);

        function SnakeSegment(param) {
          var _this = _super.call(this, param) || this;

          _this.type = param.type;
          _this.word = param.word != null ? param.word : "";
          _this.wordLabel = null;
          _this.dashEffect = null;

          _this._init(param);

          return _this;
        }

        SnakeSegment.prototype.render = function (renderer, camera) {
          if (camera) {
            var cam = g.game.focusingCamera;
            var margin = 50;
            var globalOffset = entityUtils_1.localToGlobal(this); // 移動するのでキャッシュできない

            if (globalOffset.x >= cam.x - margin && globalOffset.x <= cam.x + g.game.width + margin && globalOffset.y >= cam.y - margin && globalOffset.y <= cam.y + g.game.height + margin) {// do nothing
            } else {
                return; // modifiedフラグはカメラに入るまで保持する
              }
          }

          _super.prototype.render.call(this, renderer, camera);
        };

        SnakeSegment.prototype._init = function (param) {
          var asset = this.scene.assets[param.assetId];
          this.body = new g.Sprite({
            scene: this.scene,
            src: asset,
            width: asset.width,
            height: asset.height,
            anchorX: 0.5,
            anchorY: 0.5,
            x: 0,
            y: 0
          });

          switch (param.type) {
            case SnakeSegmentType.Head:
              this.body.x += 20;
              this.body.angle = 90;
              this.append(this.body);
              var dashEffectAsset = this.scene.assets.main_dash_eff;
              this.dashEffect = new g.Sprite({
                scene: this.scene,
                src: dashEffectAsset,
                width: dashEffectAsset.width,
                height: dashEffectAsset.height,
                x: 5,
                y: 55,
                anchorX: 0.5,
                anchorY: 0.5,
                angle: 90,
                hidden: true
              });
              this.append(this.dashEffect);
              break;

            case SnakeSegmentType.Knot:
              this.wordLabel = new g.Label({
                scene: this.scene,
                font: param.font,
                text: param.word,
                fontSize: 50,
                textColor: "white",
                anchorX: 0.5,
                anchorY: 0.5,
                angle: -this.angle
              });
              this.append(this.body);
              this.append(this.wordLabel);
              break;

            case SnakeSegmentType.Jewel:
              this.body.angle -= this.angle;
              this.append(this.body);
              break;

            default: // do nothing

          }
        };

        return SnakeSegment;
      }(g.E);

      exports.SnakeSegment = SnakeSegment;
      /**
       * スネークが壁伝いに進む方向
       */

      var SnakeRotateState;

      (function (SnakeRotateState) {
        /**
         * 時計回り
         */
        SnakeRotateState["onClockwise"] = "onClockwise";
        /**
         * 反時計回り
         */

        SnakeRotateState["onCounterClockwise"] = "onCounterClockwise";
        /**
         * 壁に接触していない
         */

        SnakeRotateState["noRotate"] = "noRotate";
      })(SnakeRotateState = exports.SnakeRotateState || (exports.SnakeRotateState = {}));
      /**
       * SnakeSegmentの種類
       */


      var SnakeSegmentType;

      (function (SnakeSegmentType) {
        /**
         * 頭
         */
        SnakeSegmentType["Head"] = "Head";
        /**
         * 節
         */

        SnakeSegmentType["Knot"] = "Knot";
        /**
         * お宝
         */

        SnakeSegmentType["Jewel"] = "Jewel";
      })(SnakeSegmentType = exports.SnakeSegmentType || (exports.SnakeSegmentType = {}));
    }, {
      "../types/MessageEventType": 49,
      "../types/UserTouchState": 50,
      "../utils/entityUtils": 53,
      "./OffsetGroup": 30,
      "@akashic-extension/akashic-timeline": 15
    }],
    35: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics12 = function extendStatics(d, b) {
          _extendStatics12 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics12(d, b);
        };

        return function (d, b) {
          _extendStatics12(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.TimePanel = void 0;

      var akashic_label_1 = require("@akashic-extension/akashic-label");

      var TimePanel =
      /** @class */
      function (_super) {
        __extends(TimePanel, _super);

        function TimePanel(param) {
          var _this = _super.call(this, param) || this;

          _this.bg = new g.Sprite({
            scene: param.scene,
            src: param.backgroundImage
          });

          _this.append(_this.bg);

          _this._createLabel(param.remainTime);

          return _this;
        }

        TimePanel.prototype.updateTime = function (remainTime) {
          if (remainTime <= 10) {
            this.label.font = this.timeRedFont;
          }

          this.label.text = "" + remainTime;
          this.label.invalidate();
        };

        TimePanel.prototype._createLabel = function (remainTime) {
          var timeFontGlyph = JSON.parse(this.scene.assets.main_num_time_glyph.data);
          this.timeFont = new g.BitmapFont({
            src: this.scene.assets.main_num_time_c,
            map: timeFontGlyph,
            defaultGlyphWidth: 34,
            defaultGlyphHeight: 58
          });
          this.timeRedFont = new g.BitmapFont({
            src: this.scene.assets.main_num_time_r,
            map: timeFontGlyph,
            defaultGlyphWidth: 34,
            defaultGlyphHeight: 58
          });
          this.label = new akashic_label_1.Label({
            scene: this.scene,
            text: "" + remainTime,
            font: this.timeFont,
            fontSize: 58,
            width: this.width,
            y: 63,
            textAlign: "center"
          });
          this.append(this.label);
        };

        return TimePanel;
      }(g.E);

      exports.TimePanel = TimePanel;
    }, {
      "@akashic-extension/akashic-label": 8
    }],
    36: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics13 = function extendStatics(d, b) {
          _extendStatics13 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics13(d, b);
        };

        return function (d, b) {
          _extendStatics13(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      var __assign = this && this.__assign || function () {
        __assign = Object.assign || function (t) {
          for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];

            for (var p in s) {
              if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
          }

          return t;
        };

        return __assign.apply(this, arguments);
      };

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.BigButton = void 0;
      /**
       * 準備画面仕様の大ボタンq
       */

      var BigButton =
      /** @class */
      function (_super) {
        __extends(BigButton, _super);

        function BigButton(params) {
          var _this = this;

          var width = 720; // レイアウト指示書で定義

          var height = 120; // レイアウト指示書で定義

          _this = _super.call(this, __assign(__assign({}, params), {
            width: width,
            height: height,
            backgroundEffector: new g.NinePatchSurfaceEffector(g.game, {
              top: 55,
              bottom: 55,
              left: 64,
              right: 64
            }),
            backgroundImage: params.scene.assets.btn_frame_join
          })) || this;
          _this._textLabel = new g.Label({
            scene: _this.scene,
            anchorX: 0.5,
            anchorY: 0.5,
            x: width / 2,
            y: height / 2 - 5,
            font: params.font,
            text: params.text,
            fontSize: 70,
            textColor: params.textColor,
            local: params.local
          });

          _this.append(_this._textLabel);

          return _this;
        }
        /**
         * 無効状態の表示に切り替える
         * @param text テキストを変更する場合は指定する
         */


        BigButton.prototype.toDisable = function (text) {
          this.backgroundImage = g.SurfaceUtil.asSurface(this.scene.assets.btn_frame_join_disable);
          this.invalidate();

          if (text) {
            this._textLabel.text = text;

            this._textLabel.invalidate();
          }
        };

        return BigButton;
      }(g.Pane);

      exports.BigButton = BigButton;
    }, {}],
    37: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics14 = function extendStatics(d, b) {
          _extendStatics14 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics14(d, b);
        };

        return function (d, b) {
          _extendStatics14(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      var __assign = this && this.__assign || function () {
        __assign = Object.assign || function (t) {
          for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];

            for (var p in s) {
              if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
          }

          return t;
        };

        return __assign.apply(this, arguments);
      };

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.HowtoText = void 0;

      var akashic_label_1 = require("@akashic-extension/akashic-label"); // ニコニコ生放送フォント定義


      var FontFamily = {
        // ゴシック: Avenir Next DemiBold + ヒラギノ角ゴ Pro W6
        Gothic: [// Avenir Next DemiBold
        "Avenir Next DemiBold", "AvenirNext-DemiBold", "Avenir Next", // for Windows
        "Verdana", // ヒラギノ角ゴ Pro W6
        "ヒラギノ角ゴ Pro W6", "HiraKakuPro-W6", // for Windows
        "meiryo", "sans-serif"],
        Number: [// Avenir Next DemiBold
        "Avenir Next DemiBold", "AvenirNext-DemiBold", "Avenir Next", // for Windows
        "Verdana", "sans-serif"]
      };
      var HOWTO_FONT_SIZE = 34;
      var howtoFont = new g.DynamicFont({
        game: g.game,
        fontFamily: FontFamily.Gothic,
        size: HOWTO_FONT_SIZE,
        fontWeight: g.FontWeight.Bold
      });
      /**
       * あそびかた説明
       */

      var HowtoText =
      /** @class */
      function (_super) {
        __extends(HowtoText, _super);

        function HowtoText(params) {
          var _this = this;

          var width = 1030; // 手調整 (レイアウト指示+30)

          var height = 340; // 手調整 (レイアウト指示+60)

          _this = _super.call(this, __assign(__assign({}, params), {
            width: width,
            height: height,
            anchorX: 0.5,
            anchorY: 0,
            x: g.game.width / 2,
            backgroundEffector: new g.NinePatchSurfaceEffector(g.game, 20),
            backgroundImage: params.scene.assets.frame_howto
          })) || this;
          var title = new g.Label({
            scene: _this.scene,
            x: 64,
            y: 32,
            text: "あそびかた",
            font: howtoFont,
            textColor: "silver",
            fontSize: 34
          });

          _this.append(title);

          var howtoText = new akashic_label_1.Label({
            scene: _this.scene,
            text: params.text,
            font: howtoFont,
            fontSize: HOWTO_FONT_SIZE,
            textColor: "#FFFFFF",
            lineGap: 10,
            x: 64,
            y: 80,
            width: 1000,
            height: 170
          });

          _this.append(howtoText);

          return _this;
        }

        return HowtoText;
      }(g.Pane);

      exports.HowtoText = HowtoText;
    }, {
      "@akashic-extension/akashic-label": 8
    }],
    38: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics15 = function extendStatics(d, b) {
          _extendStatics15 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics15(d, b);
        };

        return function (d, b) {
          _extendStatics15(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      var __assign = this && this.__assign || function () {
        __assign = Object.assign || function (t) {
          for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];

            for (var p in s) {
              if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
          }

          return t;
        };

        return __assign.apply(this, arguments);
      };

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.RecruitmentCountDown = void 0;
      /**
       * タイトルシーンで募集の残り秒数を表示エンティティ
       */

      var RecruitmentCountDown =
      /** @class */
      function (_super) {
        __extends(RecruitmentCountDown, _super);

        function RecruitmentCountDown(params) {
          var _this = this;

          var width = 486;
          var height = 64;
          _this = _super.call(this, __assign(__assign({}, params), {
            width: width,
            height: height,
            x: g.game.width / 2,
            anchorX: 0.5,
            anchorY: 0
          })) || this;
          var leftLabel = new g.Label({
            scene: params.scene,
            text: "参加者受付中 残り",
            font: params.font,
            textColor: "white",
            fontSize: 36,
            x: 0,
            y: height / 2,
            anchorX: 0,
            anchorY: 0.5
          });

          _this.append(leftLabel);

          var rightLabel = new g.Label({
            scene: params.scene,
            text: "秒",
            font: params.font,
            textColor: "white",
            fontSize: 36,
            x: 450,
            y: height / 2,
            anchorX: 0,
            anchorY: 0.5
          });

          _this.append(rightLabel);

          _this._createDigits(params.font);

          return _this;
        }

        RecruitmentCountDown.prototype._createDigits = function (font) {
          var digit1 = new g.Label({
            scene: this.scene,
            text: "1",
            font: font,
            textColor: "white",
            fontSize: 66,
            x: 331,
            y: -8
          });
          this.append(digit1);
          var digit2 = new g.Label({
            scene: this.scene,
            text: "0",
            font: font,
            textColor: "white",
            fontSize: 66,
            x: 381,
            y: -8
          });
          this.append(digit2);
          this.digits = [digit1, digit2];
        };

        RecruitmentCountDown.prototype.setTime = function (value) {
          value = Math.floor(value % 100);
          var strValue = String(value);

          if (value < 10) {
            this.digits[0].text = "0";
            this.digits[1].text = strValue[0];
          } else {
            this.digits[0].text = strValue[0];
            this.digits[1].text = strValue[1];
          }

          this.digits.forEach(function (e) {
            return e.invalidate();
          });
        };

        return RecruitmentCountDown;
      }(g.E);

      exports.RecruitmentCountDown = RecruitmentCountDown;
    }, {}],
    39: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics16 = function extendStatics(d, b) {
          _extendStatics16 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics16(d, b);
        };

        return function (d, b) {
          _extendStatics16(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      var __assign = this && this.__assign || function () {
        __assign = Object.assign || function (t) {
          for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];

            for (var p in s) {
              if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
          }

          return t;
        };

        return __assign.apply(this, arguments);
      };

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.WaitingText = void 0;

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");
      /**
       * タイトルシーンで集計中に表示するテキスト「集計中・・・」
       */


      var WaitingText =
      /** @class */
      function (_super) {
        __extends(WaitingText, _super);

        function WaitingText(params) {
          var _this = _super.call(this, __assign(__assign({}, params), {
            width: g.game.width,
            height: 71
          })) || this;

          var textLabel = new g.Label({
            scene: _this.scene,
            text: "集計中",
            fontSize: 70,
            textColor: "white",
            font: params.font,
            x: 498,
            y: 0
          });

          _this.append(textLabel);

          _this.timeline = new akashic_timeline_1.Timeline(_this.scene);
          var duration = 500;

          _this.timeline.create(_this, {
            loop: true
          }).wait(duration).call(function () {
            textLabel.text = "集計中・";
            textLabel.invalidate();
          }).wait(duration).call(function () {
            textLabel.text = "集計中・・";
            textLabel.invalidate();
          }).wait(duration).call(function () {
            textLabel.text = "集計中・・・";
            textLabel.invalidate();
          }).wait(duration).call(function () {
            textLabel.text = "集計中";
            textLabel.invalidate();
          });

          return _this;
        }

        WaitingText.prototype.destroy = function () {
          this.timeline.destroy();

          _super.prototype.destroy.call(this);
        };

        return WaitingText;
      }(g.E);

      exports.WaitingText = WaitingText;
    }, {
      "@akashic-extension/akashic-timeline": 15
    }],
    40: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.main = void 0;

      var defaultParameter_1 = require("./config/defaultParameter");

      var StateManager_1 = require("./StateManager");

      function main(param) {
        var userSessionParameter = param.sessionParameter;

        if (userSessionParameter) {
          assign(defaultParameter_1.sessionParameter, userSessionParameter);
        }

        var stateManager = new StateManager_1.StateManager({
          sessionParameter: defaultParameter_1.sessionParameter,
          broadcaster: param.broadcasterPlayer
        });

        if (!!stateManager.sessionParameter.config.debug && stateManager.sessionParameter.config.debug.skipLottery) {
          stateManager.playerList = {};
          stateManager.playerList[stateManager.broadcaster.id] = new StateManager_1.PlayerInfo({
            player: stateManager.broadcaster,
            user: {
              name: "debug",
              id: "000000000",
              isPremium: false
            },
            isBroadcaster: true,
            snakeType: "A"
          });
          stateManager.randomGenerator = new g.XorshiftRandomGenerator(2525);
          stateManager.changeMainGameScene();
        } else {
          stateManager.changeTitleScene();
        }
      }

      exports.main = main;

      function assign(target, _) {
        var to = Object(target);

        for (var index = 1; index < arguments.length; index++) {
          var nextSource = arguments[index];

          if (nextSource != null) {
            for (var nextKey in nextSource) {
              if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
                if (nextSource[nextKey] != null && _typeof(nextSource[nextKey]) === "object") {
                  to[nextKey] = assign(to[nextKey], nextSource[nextKey]);
                } else {
                  to[nextKey] = nextSource[nextKey];
                }
              }
            }
          }
        }

        return to;
      }
    }, {
      "./StateManager": 19,
      "./config/defaultParameter": 24
    }],
    41: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Behavior = void 0;

      var Behavior =
      /** @class */
      function () {
        function Behavior(param) {
          this.scene = param.scene;
          this.stateManager = param.stateManager;
        }

        return Behavior;
      }();

      exports.Behavior = Behavior;
    }, {}],
    42: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics17 = function extendStatics(d, b) {
          _extendStatics17 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics17(d, b);
        };

        return function (d, b) {
          _extendStatics17(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.MainGameBehavior = void 0;

      var StateManager_1 = require("../../StateManager");

      var Behavior_1 = require("../Behavior");

      var MessageEventType_1 = require("../../types/MessageEventType");

      var UserTouchState_1 = require("../../types/UserTouchState");

      var StateRoleChecker_1 = require("../../utils/StateRoleChecker");

      var MainGameBehavior =
      /** @class */
      function (_super) {
        __extends(MainGameBehavior, _super);

        function MainGameBehavior(param) {
          return _super.call(this, param) || this;
        }

        MainGameBehavior.prototype.onMessageEvent = function (event) {
          this._onAllInstanceEvent(event);

          if (g.game.isActiveInstance()) this._onActiveInstanceEvent(event);
        };
        /**
         * 全てのインスタンスで拾うイベント
         */


        MainGameBehavior.prototype._onAllInstanceEvent = function (event) {
          var _this = this;

          var data = event.data;
          var messageType = data.messageType;

          switch (messageType) {
            case MessageEventType_1.MessageEventType.initMainGame:
              this.scene.init(data.messageData.playerInitLayoutList);
              break;

            case MessageEventType_1.MessageEventType.setPlaying:
              switch (data.messageData.scope) {
                case MessageEventType_1.ScopeType.All:
                  this.stateManager.applyPlayingStateForAllSnakes();
                  break;

                case MessageEventType_1.ScopeType.One:
                  if (!data.messageData.playerId) break;
                  this.stateManager.applyPlayingStateForOneSnake(data.messageData.playerId);
                  break;

                default: // do nothing

              }

              break;

            case MessageEventType_1.MessageEventType.changeUserTouchState:
              var playerId = data.messageData.id;
              this.stateManager.applyTouchState(playerId ? playerId : event.player.id, data.messageData.newState, data.messageData.newDirection);
              var canPlaySE = data.messageData.canPlaySE;

              if ((canPlaySE == null || !!canPlaySE && canPlaySE) && playerId === this.stateManager.broadcaster.id && this.scene._isAudience(g.game.selfId)) {
                if (data.messageData.newState === UserTouchState_1.UserTouchState.onDoubleTap) {
                  this.stateManager.playAudioAtParamVolume(StateManager_1.AudioType.Dash);
                } else {
                  this.stateManager.audioAssets[StateManager_1.AudioType.Dash].stop();
                }
              }

              break;

            case MessageEventType_1.MessageEventType.sendPlayersInConflict:
              this.scene.receivePlayersInConflict(data.messageData.playersInConflict);
              break;

            case MessageEventType_1.MessageEventType.respawnSnake:
              if (this.stateManager.playerList[event.player.id].state !== StateManager_1.PlayerState.dead) break; // 重複リスポーンを防ぐ

              this.stateManager.setRespawnSnake(event.player.id, this.scene.snakeLayer, this.scene.stage.getNowRadius());

              if (event.player.id === g.game.selfId) {
                this.scene.localParameter.respawnButton.destroy();
                this.scene.localParameter.respawnButton = null;
                this.scene.localParameter.broadcasterDisplayViewing.hide();
                this.scene.localParameter.dashingGauge = this.stateManager.sessionParameter.config.snake.dashingTime * g.game.fps;
                this.scene.localParameter.dashingGaugeBar.updateGauge(this.stateManager.sessionParameter.config.snake.dashingTime);
                this.scene.localParameter.dashingGaugeBar.opacity = 0.0;
                this.scene.localParameter.dashingGaugeBar.show();
              }

              break;

            case MessageEventType_1.MessageEventType.respawnBroadcasterAngelSnake:
              if (this.stateManager.playerList[this.stateManager.broadcaster.id].state !== StateManager_1.PlayerState.dead) break; // 重複リスポーンを防ぐ

              this.stateManager.setBroadcasterAngelSnake(this.scene.snakeLayer, this.scene.stage.getNowRadius());
              this.scene.modifyBroadcasterAngelSnake();

              if (event.player.id === g.game.selfId) {
                this.scene.localParameter.respawnButton.destroy();
                this.scene.localParameter.respawnButton = null;
                this.scene.localParameter.broadcasterDisplayViewing.hide();
                this.scene.localParameter.dashingGauge = this.stateManager.sessionParameter.config.snake.dashingTime * g.game.fps;
                this.scene.localParameter.dashingGaugeBar.updateGauge(this.stateManager.sessionParameter.config.snake.dashingTime);
                this.scene.localParameter.dashingGaugeBar.opacity = 0.0;
                this.scene.localParameter.dashingGaugeBar.show();
              }

              break;

            case MessageEventType_1.MessageEventType.respawnJewel:
              this.stateManager.setRespawnJewel(data.messageData.position);
              break;

            case MessageEventType_1.MessageEventType.eatenFoods:
              this.stateManager.applyEatenFoods(data.messageData.eatenFoodInfo, data.messageData.noEatenFoodIndexList, data.messageData.fieldRadius);
              break;

            case MessageEventType_1.MessageEventType.updateJewelOwner:
              var stolenPlayerId = this.stateManager.jewelData.ownerId; // お宝を盗まれたプレイヤーのid（applyEatenJewelで更新）

              this.stateManager.applyEatenJewel(data.messageData.ownerId);
              this.scene.switchGoldenSnake(data.messageData.ownerId, stolenPlayerId);
              break;

            case MessageEventType_1.MessageEventType.rankingAccountData:
              this.scene.rewriteRanking(data.messageData.rankingAccountData);
              break;

            case MessageEventType_1.MessageEventType.updateRemainTime:
              this.scene.rewriteTime(data.messageData.remainTime);
              break;

            case MessageEventType_1.MessageEventType.animation:
              switch (data.messageData.scope) {
                case MessageEventType_1.ScopeType.All:
                  this.stateManager.animateAllSnakes(data.messageData.animationType);
                  break;

                case MessageEventType_1.ScopeType.One:
                  if (!data.messageData.playerId) break;
                  this.stateManager.animateOneSnake(data.messageData.animationType, data.messageData.playerId);
                  break;

                default: // do nothing

              }

              break;

            case MessageEventType_1.MessageEventType.countDown:
              this.scene.showCountDown(data.messageData.countDownType);
              break;

            case MessageEventType_1.MessageEventType.preventUsertouch:
              this.stateManager.applyPreventUserTouch(data.messageData.playerId, data.messageData.preventType);
              break;

            case MessageEventType_1.MessageEventType.destroySnake:
              this.scene.snakeDestructionProcedure(data.messageData.deadPlayerId);
              break;

            case MessageEventType_1.MessageEventType.finishGame:
              this.scene.assets.snake_bgm.stop();
              this.stateManager.isGameOver = true;
              Object.keys(this.stateManager.playerList).forEach(function (playerId) {
                if (StateRoleChecker_1.checkStateRole(_this.stateManager.playerList[playerId].state, StateRoleChecker_1.StateRoleType.CanCountType)) {
                  _this.stateManager.playerList[playerId].lastWords = _this.stateManager.playerList[playerId].getsLastWords();
                }
              });
              this.scene.showFinishView();
              break;

            case MessageEventType_1.MessageEventType.startResult:
              this.scene._stopAllAudio();

              this.stateManager.changeResultScene();
              break;

            default: // do nothing

          }
        };
        /**
         * サーバーインスタンスでのみ拾うイベント
         */


        MainGameBehavior.prototype._onActiveInstanceEvent = function (event) {
          var data = event.data;
          var messageType = data.messageType;

          switch (messageType) {
            case MessageEventType_1.MessageEventType.setPlaying:
              switch (data.messageData.scope) {
                case MessageEventType_1.ScopeType.All:
                  // タイマー起動
                  this.scene.setCountDownIntervalInActiveInstance();
                  break;

                default: // do nothing

              }

              break;

            case MessageEventType_1.MessageEventType.sendPlayersInConflict:
              this.scene.manageSnakeDestructionInActiveInstance(data.messageData.playersInConflict);
              break;

            case MessageEventType_1.MessageEventType.respawnSnake:
              this.stateManager.endInvincibleTime(MessageEventType_1.ScopeType.One, event.player.id);
              break;

            case MessageEventType_1.MessageEventType.finishGame:
              if (this.scene.localParameter.remainGameTimer != null) {
                this.scene.clearInterval(this.scene.localParameter.remainGameTimer);
                this.scene.localParameter.remainGameTimer = null;
              }

              break;

            default: // do nothing

          }
        };

        return MainGameBehavior;
      }(Behavior_1.Behavior);

      exports.MainGameBehavior = MainGameBehavior;
    }, {
      "../../StateManager": 19,
      "../../types/MessageEventType": 49,
      "../../types/UserTouchState": 50,
      "../../utils/StateRoleChecker": 51,
      "../Behavior": 41
    }],
    43: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics18 = function extendStatics(d, b) {
          _extendStatics18 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics18(d, b);
        };

        return function (d, b) {
          _extendStatics18(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.ButtonState = exports.MainGameScene = exports.createMainGameScene = void 0;

      var akashic_label_1 = require("@akashic-extension/akashic-label");

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var SceneBase_1 = require("../SceneBase");

      var StateManager_1 = require("../../StateManager");

      var MainGameBehavior_1 = require("./MainGameBehavior");

      var UserTouchState_1 = require("../../types/UserTouchState");

      var MessageEventType_1 = require("../../types/MessageEventType");

      var Field_1 = require("../../entity/Field");

      var Snake_1 = require("../../entity/Snake");

      var assetIds_1 = require("../../assetIds");

      var Food_1 = require("../../entity/Food");

      var Jewel_1 = require("../../entity/Jewel");

      var utils_1 = require("../../commonUtils/utils");

      var PopupNotice_1 = require("../../entity/PopupNotice");

      var ScorePanel_1 = require("../../entity/ScorePanel");

      var TimePanel_1 = require("../../entity/TimePanel");

      var MiniMap_1 = require("../../entity/MiniMap");

      var DashingGauge_1 = require("../../entity/DashingGauge");

      var StateRoleChecker_1 = require("../../utils/StateRoleChecker");

      function createMainGameScene(stateManager) {
        var foodCharsAsset = g.game.assets.foodAvailableChars;
        var foodChars = JSON.parse(foodCharsAsset.data).foodAvailableChars;
        var assetIds = [];
        assetIds.push.apply(assetIds, assetIds_1.snakeAssetIds);
        assetIds.push.apply(assetIds, assetIds_1.uiAssetIds);
        assetIds.push.apply(assetIds, assetIds_1.fontAssetIds);
        assetIds.push.apply(assetIds, assetIds_1.audioAssetIds);
        assetIds.push.apply(assetIds, assetIds_1.effectAssetIds);
        var mainGameScene = new MainGameScene({
          game: g.game,
          stateManager: stateManager,
          assetIds: assetIds,
          foodChars: foodChars
        });
        return mainGameScene;
      }

      exports.createMainGameScene = createMainGameScene;

      var MainGameScene =
      /** @class */
      function (_super) {
        __extends(MainGameScene, _super);

        function MainGameScene(param) {
          var _this = _super.call(this, param) || this;

          _this.stateManager = param.stateManager;
          _this.timeline = new akashic_timeline_1.Timeline(_this);
          _this.foodChars = param.foodChars;
          _this.localParameter = {
            noticeList: [],
            remainGameTimer: null,
            remainTime: _this.stateManager.sessionParameter.config.time.limit,
            timePanel: null,
            killCountPanel: null,
            lengthCountPanel: null,
            preKillCount: 0,
            preLengthCount: 0,
            rankingPanel: null,
            topPlayerLabelList: [],
            broadcasterRankLabel: null,
            yourRankLabel: null,
            lastPointUpTime: -_this.stateManager.sessionParameter.config.snake.dashingTime * g.game.fps,
            startDoubleTapTime: -_this.stateManager.sessionParameter.config.snake.dashingTime * g.game.fps,
            dashingGauge: _this.stateManager.sessionParameter.config.snake.dashingTime * g.game.fps,
            dashingGaugeBar: null,
            respawnButton: null,
            broadcasterDisplayViewing: null,
            playerCountRank: 0,
            miniMap: null,
            jewelPop: null,
            pointDownMarker: null
          };
          _this.lastKillNoticeAge = _this.game.age;
          _this.killNoticeCount = 0;
          _this.maxKillNoticeCount = 2;

          _this.onLoad.add(function () {
            _this.setBehavior(new MainGameBehavior_1.MainGameBehavior({
              scene: _this,
              stateManager: _this.stateManager
            }));

            _this.setMessageEventListener();

            if (g.game.isActiveInstance()) _this.stateManager.setupInitLayout();
          });

          _this.onUpdate.add(function () {
            _this._updateScene();

            _this._updateDeadSnakeCamera();

            if (!!g.game.selfId && !!_this.stateManager.playerList[g.game.selfId] && !!_this.stateManager.playerList[g.game.selfId].uiState) {
              _this._updateInPlayer();
            }

            if (g.game.isActiveInstance()) {
              _this._updateInActiveInstance();
            }

            if (!!g.game.selfId && !_this.stateManager.playerList[g.game.selfId]) {
              _this._updateInNonPlayer();
            }
          });

          _this._setInterval();

          return _this;
        }

        MainGameScene.prototype.init = function (playerInitLayoutList) {
          this._applyInitPlayerLayoutData(playerInitLayoutList);

          this._createRoot();

          this._createBackground();

          this._createTouchArea();

          this._createPlayersSnakes(playerInitLayoutList);

          this._createDashGaugeBar();

          this._createUserNameLabels();

          this._createTimeView();

          this._createRankingView();

          this._createScoreView();

          this._createBroadcasterDisplayView();

          this._initJewel();

          this._createMiniMapView();

          this._createPointdownView();

          this._playBGM();

          this._setSE();

          if (!!this.stateManager.sessionParameter.config.debug && this.stateManager.sessionParameter.config.debug.skipLottery) {
            this._createDebugView();
          }
        };

        MainGameScene.prototype.setCountDownIntervalInActiveInstance = function () {
          var _this = this;

          if (this.localParameter.remainGameTimer != null || !this.stateManager.sessionParameter.config.time.isTimeBased) return;
          this.localParameter.remainGameTimer = this.setInterval(function () {
            if (_this.localParameter.remainTime == null) {
              if (_this.localParameter.remainGameTimer != null) {
                _this.clearInterval(_this.localParameter.remainGameTimer);

                _this.localParameter.remainGameTimer = null;
              }

              return;
            }

            if (_this.localParameter.remainTime <= 0) {
              if (_this.localParameter.remainGameTimer != null) {
                _this.clearInterval(_this.localParameter.remainGameTimer);

                _this.localParameter.remainGameTimer = null;
              }

              _this.stateManager.gameEndProcedure();
            }

            var time = --_this.localParameter.remainTime;

            if (time >= 0) {
              var message = {
                messageType: MessageEventType_1.MessageEventType.updateRemainTime,
                messageData: {
                  remainTime: time
                }
              };
              g.game.raiseEvent(new g.MessageEvent(message));
            }
          }, 1000);
        };

        MainGameScene.prototype.receivePlayersInConflict = function (playersInConflict) {
          var _this = this;

          playersInConflict.forEach(function (info) {
            var deadPlayerId = info.deadPlayerId;
            var killerPlayerId = info.killerPlayerId;

            if (!!_this.stateManager.playerList[deadPlayerId] && !!_this.stateManager.playerList[deadPlayerId].snake && _this.stateManager.playerList[deadPlayerId].state === StateManager_1.PlayerState.playing) {
              ++_this.stateManager.playerList[killerPlayerId].killCount; // SE再生

              if (deadPlayerId === g.game.selfId || killerPlayerId === g.game.selfId || _this._isAudience(g.game.selfId) && (deadPlayerId === _this.stateManager.broadcaster.id || killerPlayerId === _this.stateManager.broadcaster.id)) {
                // 頭衝突時に2重にSEが再生されることを防ぐ
                _this.stateManager.audioAssets[StateManager_1.AudioType.Collision].stop();

                _this.stateManager.playAudioAtParamVolume(StateManager_1.AudioType.Collision);
              } // キル通知作成


              if (g.game.age === _this.lastKillNoticeAge) {
                _this.killNoticeCount++;
              } else {
                _this.lastKillNoticeAge = g.game.age;
                _this.killNoticeCount = 0;
              }

              if (_this.killNoticeCount < _this.maxKillNoticeCount) {
                var killNotice = _this._createNotice(PopupNotice_1.NoticeType.Kill, killerPlayerId);

                _this._addNotice(killNotice);
              } // ユーザー名ラベルをhide


              _this.stateManager.userNameLabels[deadPlayerId].hide(); // ポップ、ダッシュゲージをhide


              if (deadPlayerId === g.game.selfId) {
                _this.localParameter.jewelPop.opacity = 0.0;

                _this.localParameter.dashingGaugeBar.hide();
              }

              _this._dropSnakeBody(deadPlayerId);

              _this.stateManager.playerList[deadPlayerId].state = StateManager_1.PlayerState.staging;

              _this.stateManager.playerList[deadPlayerId].snake.explosion();
            }
          });
        };

        MainGameScene.prototype.manageSnakeDestructionInActiveInstance = function (playersInConflict) {
          var _this = this;

          playersInConflict.forEach(function (info) {
            var deadPlayerId = info.deadPlayerId;

            if (!!_this.stateManager.playerList[deadPlayerId] && !!_this.stateManager.playerList[deadPlayerId].snake && _this.stateManager.playerList[deadPlayerId].state === StateManager_1.PlayerState.staging) {
              // キルされた時の演出
              _this.setTimeout(function () {
                _this._snakeDestructionEventFlow(deadPlayerId);
              }, 100 * (_this.stateManager.playerList[deadPlayerId].snake.segments.length + 1) + 800); // 爆破エフェクトが終わるまで待機

            }
          });
        };

        MainGameScene.prototype.snakeDestructionProcedure = function (deadPlayerId) {
          if (!!this.stateManager.playerList[deadPlayerId] && !!this.stateManager.playerList[deadPlayerId].snake && this.stateManager.playerList[deadPlayerId].state === StateManager_1.PlayerState.staging) {
            this.stateManager.playerList[deadPlayerId].destroySnake();
            if (this.stateManager.isGameOver) return; // 「放送者画面視聴中」

            if (deadPlayerId === g.game.selfId) {
              if (this._isAudience(g.game.selfId)) {
                this.localParameter.broadcasterDisplayViewing.show();
              }
            }

            if (deadPlayerId === g.game.selfId) {
              if (this.stateManager.isBroadcaster) {
                // 放送者リスポーンボタン表示
                if (this.stateManager.playerList[deadPlayerId].respawnTimes > 0) this._createRespawnView();else this._createAngelSnakeView();
              } else {
                // 視聴者リスポーンボタン表示
                if (this.stateManager.playerList[deadPlayerId].respawnTimes > 0) this._createRespawnView();else this._createUnableRespawnView();
              }
            }
          }
        };

        MainGameScene.prototype.modifyBroadcasterAngelSnake = function () {
          var _this = this;

          var angelSnake = this.stateManager.playerList[this.stateManager.broadcaster.id].snake;
          angelSnake.head.body._surface = g.SurfaceUtil.asSurface(this.assets["snake" + angelSnake.snakeType + "_head_death"]);
          angelSnake.head.opacity = 0.5;
          angelSnake.head.body.invalidate();
          angelSnake.segments.forEach(function (seg) {
            seg.body._surface = g.SurfaceUtil.asSurface(_this.assets.snake_body_death);
            seg.opacity = 0.5;
            seg.body.invalidate();
          });
        };

        MainGameScene.prototype.switchGoldenSnake = function (ownerId, stolenPlayerId) {
          var _this = this;

          if (!this.stateManager.playerList[ownerId].snake) return;

          if (stolenPlayerId != null) {
            var stolenSnake_1 = this.stateManager.playerList[stolenPlayerId].snake;
            stolenSnake_1.head.body._surface = g.SurfaceUtil.asSurface(this.assets["snake" + stolenSnake_1.snakeType + "_head_alive"]);
            stolenSnake_1.head.body.invalidate();
            stolenSnake_1.segments.forEach(function (seg) {
              if (seg.type === Snake_1.SnakeSegmentType.Jewel) return;
              seg.body._surface = g.SurfaceUtil.asSurface(_this.assets["snake" + stolenSnake_1.snakeType + "_body"]);
              seg.body.invalidate();
            });
          }

          var jewelOwnerSnake = this.stateManager.playerList[ownerId].snake;
          jewelOwnerSnake.head.body._surface = g.SurfaceUtil.asSurface(this.assets["snake" + jewelOwnerSnake.snakeType + "_head_gold"]);
          jewelOwnerSnake.head.body.invalidate();
          jewelOwnerSnake.segments.forEach(function (seg) {
            if (seg.type === Snake_1.SnakeSegmentType.Jewel) return;
            seg.body._surface = g.SurfaceUtil.asSurface(_this.assets.snake_body_gold);
            seg.body.invalidate();
          }); // お宝ゲット通知

          var jewelNotice = this._createNotice(PopupNotice_1.NoticeType.Jewel, ownerId);

          this._addNotice(jewelNotice); // お宝ゲットポップアップ/SE再生


          if (ownerId === g.game.selfId || this._isAudience(g.game.selfId) && ownerId === this.stateManager.broadcaster.id) {
            this.stateManager.playAudioAtParamVolume(StateManager_1.AudioType.Jewel);
            this.timeline.create(this.localParameter.jewelPop).moveBy(0, -120, 200).con().fadeIn(150).wait(1000).moveBy(0, 120, 200).con().fadeOut(150);
          }
        };

        MainGameScene.prototype.rewriteRanking = function (rankingAccountData) {
          var _this = this; // 初期化（5人未満になった場合などにランキングがおかしくなるのを避ける）


          this.localParameter.topPlayerLabelList.forEach(function (label) {
            label.hide();
          });
          var numRanks = Math.min(rankingAccountData.length, 5);

          for (var rank = 0; rank < numRanks; ++rank) {
            var name_1 = utils_1.clampString(rankingAccountData[rank].name, 10, "…");
            var label = this.localParameter.topPlayerLabelList[rank];

            if (label.text !== name_1) {
              label.text = name_1;
              label.invalidate();
            }

            label.show();
          }

          var broadcasterRank = -1;
          rankingAccountData.forEach(function (account, i) {
            if (broadcasterRank !== -1) return;
            if (account.id === _this.stateManager.broadcaster.id) broadcasterRank = i;
          });
          this.localParameter.broadcasterRankLabel.text = broadcasterRank !== -1 ? "" + (broadcasterRank + 1) : "-";
          this.localParameter.broadcasterRankLabel.invalidate();

          if (!this.stateManager.isBroadcaster && !!this.stateManager.playerList[g.game.selfId]) {
            var yourRank_1 = -1;
            rankingAccountData.forEach(function (account, i) {
              if (yourRank_1 !== -1) return;
              if (account.id === g.game.selfId) yourRank_1 = i;
            });
            var yourRankLabel = this.localParameter.yourRankLabel;
            var yourRankText = yourRank_1 !== -1 ? "" + (yourRank_1 + 1) : "-";

            if (yourRankLabel.text !== yourRankText) {
              yourRankLabel.text = yourRankText;
              yourRankLabel.invalidate();
            }
          }
        };

        MainGameScene.prototype.rewriteTime = function (remainTime) {
          if (!this.stateManager.sessionParameter.config.time.isTimeBased) return;
          this.localParameter.remainTime = remainTime;
          this.localParameter.timePanel.updateTime(remainTime);
        };

        MainGameScene.prototype.showCountDown = function (countDownType) {
          var _this = this;

          var countDownAsset;

          switch (countDownType) {
            case MessageEventType_1.CountDownType.Start:
              this.stateManager.playAudioAtParamVolume(StateManager_1.AudioType.Start);
              countDownAsset = this.assets.main_count_start;
              break;

            case MessageEventType_1.CountDownType.Three:
              this.stateManager.playAudioAtParamVolume(StateManager_1.AudioType.Count);
              countDownAsset = this.assets.main_count_3;
              break;

            case MessageEventType_1.CountDownType.Two:
              this.stateManager.playAudioAtParamVolume(StateManager_1.AudioType.Count);
              countDownAsset = this.assets.main_count_2;
              break;

            case MessageEventType_1.CountDownType.One:
              this.stateManager.playAudioAtParamVolume(StateManager_1.AudioType.Count);
              countDownAsset = this.assets.main_count_1;
              break;

            default: // do nothing

          }

          var countDown = new g.Sprite({
            scene: this,
            src: countDownAsset,
            x: g.game.width / 2,
            y: g.game.height / 2,
            anchorX: 0.5,
            anchorY: 0.5,
            opacity: 0.0
          });
          this.userFollowingLayer.append(countDown);
          this.timeline.create(countDown).fadeIn(450, akashic_timeline_1.Easing.easeInExpo).wait(500).call(function () {
            _this.userFollowingLayer.remove(countDown);

            if (!countDown.destroyed()) countDown.destroy();
          });
        };

        MainGameScene.prototype.showFinishView = function () {
          this.stateManager.playAudioAtParamVolume(StateManager_1.AudioType.Finish);
          var countDown = new g.Sprite({
            scene: this,
            src: this.assets.main_count_finish,
            x: g.game.width / 2,
            y: g.game.height / 2,
            anchorX: 0.5,
            anchorY: 0.5,
            opacity: 0.0
          });
          this.userFollowingLayer.append(countDown);
          this.timeline.create(countDown).fadeIn(450, akashic_timeline_1.Easing.easeInExpo); // リスポーンボタンが表示されていたら消す

          if (this.localParameter.respawnButton != null) {
            this.localParameter.respawnButton.destroy();
            this.localParameter.respawnButton = null;
          }
        };

        MainGameScene.prototype.showBroadcasterDisplayViewing = function () {
          var _this = this;

          if (this.stateManager.isBroadcaster || this.stateManager.isGameOver) return;
          var panel = new g.Sprite({
            scene: this,
            src: this.assets.main_deathpop,
            x: g.game.width / 2,
            y: g.game.height / 2,
            anchorX: 0.5,
            anchorY: 0.5,
            opacity: 0.0
          });
          this.userFollowingLayer.append(panel);
          this.timeline.create(panel).fadeIn(450, akashic_timeline_1.Easing.easeInExpo).wait(2000).fadeOut(450).call(function () {
            if (!panel.destroyed()) {
              _this.remove(panel);

              panel.destroy();
            }
          });
        };

        MainGameScene.prototype._updateScene = function () {
          var _this = this;

          Object.keys(this.stateManager.playerList).forEach(function (playerId) {
            if (!_this.stateManager.playerList[playerId] || !_this.stateManager.playerList[playerId].camera || !_this.stateManager.playerList[playerId].snake) return;
            var snake = _this.stateManager.playerList[playerId].snake;
            var state = _this.stateManager.playerList[playerId].uiState.state;

            if (StateRoleChecker_1.checkStateRole(_this.stateManager.playerList[playerId].state, StateRoleChecker_1.StateRoleType.CanMoveType)) {
              // スネークの向き調整　サーバーインスタンスでのみ実行
              _this._manageSnakeHeadOnServerInstance(playerId, snake, state); // スネークの移動


              _this._updateSnake(playerId, snake, state);
            } // カメラの追従


            var playerCamera = _this.stateManager.playerList[playerId].camera;

            if (!playerCamera) {
              console.log("camera not found! id:", playerId);
              return;
            }

            playerCamera.x = snake.head.x - g.game.width / 2;
            playerCamera.y = snake.head.y - g.game.height / 2;
            playerCamera.modified(); // タッチレイヤーの追従

            if (playerId === g.game.selfId) {
              _this.userFollowingLayer.x = playerCamera.x;
              _this.userFollowingLayer.y = playerCamera.y;

              _this.userFollowingLayer.modified();
            }

            if (_this.stateManager.userNameLabels[playerId].visible()) {
              _this.stateManager.userNameLabels[playerId].x = snake.head.x - 150 - _this.userFollowingLayer.x;
              _this.stateManager.userNameLabels[playerId].y = snake.head.y - 100 - _this.userFollowingLayer.y;

              _this.stateManager.userNameLabels[playerId].modified();
            }
          });

          this._updateDashGauge();

          this._updateFieldRadius();
        }; //* * ゲーム参加者でのみ実行するupdateトリガー処理 */


        MainGameScene.prototype._updateInPlayer = function () {
          // ダッシュゲージ処理
          switch (this.stateManager.playerList[g.game.selfId].uiState.state) {
            case UserTouchState_1.UserTouchState.onDoubleTap:
              this._checkStopDashing();

              this.localParameter.dashingGauge = Math.max(0, this.localParameter.dashingGauge - 1);
              break;

            default:
              this.localParameter.dashingGauge = Math.min(this.stateManager.sessionParameter.config.snake.dashingTime * g.game.fps, this.localParameter.dashingGauge + this.stateManager.sessionParameter.config.snake.amountDashingGaugeRecoveryPerFrame);
          } // スコアカウント、ミニマップ処理


          switch (this.stateManager.playerList[g.game.selfId].state) {
            case StateManager_1.PlayerState.playing:
              this._updateKillCount(g.game.selfId);

              this._updateLengthCount(g.game.selfId);

              this._updateMiniMap(g.game.selfId);

              break;

            case StateManager_1.PlayerState.dead:
              this._updateKillCount(this.stateManager.broadcaster.id);

              this._updateLengthCount(this.stateManager.broadcaster.id);

              this._updateMiniMap(this.stateManager.broadcaster.id);

              break;

            case StateManager_1.PlayerState.ghost:
              this._updateKillCount(this.stateManager.broadcaster.id);

              this._updateLengthCount(this.stateManager.broadcaster.id);

              this._updateMiniMap(this.stateManager.broadcaster.id);

              break;

            case StateManager_1.PlayerState.invincible:
              this._updateKillCount(g.game.selfId);

              this._updateLengthCount(g.game.selfId);

              this._updateMiniMap(g.game.selfId);

              break;

            case StateManager_1.PlayerState.staging:
              this._updateKillCount(g.game.selfId);

              this._updateLengthCount(g.game.selfId);

              this._updateMiniMap(g.game.selfId);

              break;

            default: // do nothing

          }
        }; //* * サーバーインスタンスでのみ実行するupdateトリガー処理 */


        MainGameScene.prototype._updateInActiveInstance = function () {
          this.stateManager.checkEatenFoods(this.stage.nowWidth / 2);
          this.stateManager.checkEatenJewel();
          this.stateManager.checkSnakeCollision();
          this.stateManager.checkGameEnd();
          this.stateManager.updateRanking();
          this.stateManager.checkJewelOutsideField(this.stage.nowWidth / 2);
        }; //* * ゲーム不参加者でのみ実行するupdateトリガー処理 */


        MainGameScene.prototype._updateInNonPlayer = function () {
          this._updateNonPlayerCamera();

          this._updateKillCount(this.stateManager.broadcaster.id);

          this._updateLengthCount(this.stateManager.broadcaster.id);

          this._updateMiniMap(this.stateManager.broadcaster.id);
        };

        MainGameScene.prototype._updateSnake = function (playerId, snake, state) {
          var deg = (this.stateManager.playerList[playerId].uiState.direction / this.stateManager.sessionParameter.config.userInput.radianFineness * 360 + 90) % 360;
          var field = {
            width: this.stage.nowWidth,
            height: this.stage.nowHeight
          };
          snake.update({
            angle: deg,
            state: state,
            field: field
          });
        };

        MainGameScene.prototype._updateDeadSnakeCamera = function () {
          var _this = this;

          Object.keys(this.stateManager.playerList).forEach(function (playerId) {
            if (playerId !== _this.stateManager.broadcaster.id && _this.stateManager.playerList[playerId].state === StateManager_1.PlayerState.dead) {
              var playerCamera = _this.stateManager.playerList[playerId].camera;

              if (!playerCamera) {
                console.log("camera not found! id:", playerId);
                return;
              }

              var broadcasterId = _this.stateManager.broadcaster.id;

              if (!!_this.stateManager.playerList[broadcasterId].snake) {
                playerCamera.x = _this.stateManager.playerList[broadcasterId].snake.head.x - g.game.width / 2;
                playerCamera.y = _this.stateManager.playerList[broadcasterId].snake.head.y - g.game.height / 2;
                playerCamera.modified();
              }

              if (playerId === g.game.selfId) {
                _this.userFollowingLayer.x = playerCamera.x;
                _this.userFollowingLayer.y = playerCamera.y;

                _this.userFollowingLayer.modified();
              }
            }
          });
        };

        MainGameScene.prototype._updateNonPlayerCamera = function () {
          var playerCamera = this.stateManager.playerList[this.stateManager.broadcaster.id].camera;
          if (!playerCamera) return;
          this.userFollowingLayer.x = playerCamera.x;
          this.userFollowingLayer.y = playerCamera.y;
          this.userFollowingLayer.modified();
        };

        MainGameScene.prototype._updateKillCount = function (targetPlayerId) {
          var score = this.stateManager.playerList[targetPlayerId].killCount;
          this.localParameter.killCountPanel.updateScore(score);

          if (!this._isAudience(g.game.selfId)) {
            // 放送者画面に遷移した後に、前のキル数 preKillCount が更新されてしまい、リスポーン時に誤って演出が再生されてしまうのを防ぐ PR#195
            if (score > this.localParameter.preKillCount) {
              this.localParameter.killCountPanel.swell();
            }

            this.localParameter.preKillCount = score;
          }
        };

        MainGameScene.prototype._updateLengthCount = function (targetPlayerId) {
          if (!this.stateManager.playerList[targetPlayerId].snake || this.stateManager.playerList[targetPlayerId].state === StateManager_1.PlayerState.dead) return;
          var score = this.stateManager.playerList[targetPlayerId].snake.words.length;
          this.localParameter.lengthCountPanel.updateScore(score);

          if (score > this.localParameter.preLengthCount && (score % 10 === 0 || this.localParameter.preLengthCount % 10 > score % 10) // 新たな score が 10の倍数を飛び越えるケースがあるため
          ) {
              this.localParameter.lengthCountPanel.swell();
            }

          this.localParameter.preLengthCount = score;
        };

        MainGameScene.prototype._updateMiniMap = function (targetPlayerId) {
          var nowOwnerId = this.stateManager.jewelData.ownerId;
          var jewelCommonOffset;

          if (nowOwnerId != null) {
            // お宝所有者がいる場合
            if (!StateRoleChecker_1.checkStateRole(this.stateManager.playerList[nowOwnerId].state, StateRoleChecker_1.StateRoleType.CanDropType)) return;
            var segments = this.stateManager.playerList[nowOwnerId].snake.segments;
            var jewel = segments[segments.length - 1];
            if (!jewel || jewel.type !== Snake_1.SnakeSegmentType.Jewel) return;
            jewelCommonOffset = {
              x: jewel.x + jewel.body.x,
              y: jewel.y + jewel.body.y
            };
          } else {
            jewelCommonOffset = {
              x: this.stateManager.jewelData.jewel.jewel.x,
              y: this.stateManager.jewelData.jewel.jewel.y
            };
          }

          this.localParameter.miniMap.updateMap({
            yourPlayerInfo: this.stateManager.playerList[targetPlayerId],
            field: {
              width: this.stage.nowWidth,
              height: this.stage.nowHeight
            },
            foodList: this.stateManager.foodList,
            jewelCommonOffset: jewelCommonOffset
          });
        };

        MainGameScene.prototype._updateFieldRadius = function () {
          if (!this.stateManager.sessionParameter.config.debug || !this.stateManager.sessionParameter.config.debug.skipLottery) {
            var newPlayerCountRank = this.stateManager.dividePlayerCountIntoTiers();

            if (newPlayerCountRank > this.localParameter.playerCountRank) {
              this.localParameter.playerCountRank = newPlayerCountRank;
            }
          }

          this.stage.narrowArea(Math.max(this.stage.nowWidth - 2 * this.stateManager.sessionParameter.config.field.narrowRadiusPerSec / g.game.fps, 2 * this.stateManager.sessionParameter.config.field.radius[this.localParameter.playerCountRank]));
        };

        MainGameScene.prototype._updateDashGauge = function () {
          if (!this.localParameter.dashingGaugeBar.visible()) return;

          if (this.localParameter.dashingGauge >= this.stateManager.sessionParameter.config.snake.dashingTime * g.game.fps && this.localParameter.dashingGaugeBar.opacity === 1.0) {
            this.timeline.create(this.localParameter.dashingGaugeBar).fadeOut(200);
          } else if (this.localParameter.dashingGauge < this.stateManager.sessionParameter.config.snake.dashingTime * g.game.fps && this.localParameter.dashingGaugeBar.opacity === 1.0) {
            this.timeline.create(this.localParameter.dashingGaugeBar).fadeIn(200);
          }

          this.localParameter.dashingGaugeBar.updateGauge(this.localParameter.dashingGauge / g.game.fps);
        };
        /**
         * 定期的に実行する処理
         */


        MainGameScene.prototype._setInterval = function () {
          var _this = this;

          this.setInterval(function () {
            // Foodを撒く
            if (Object.keys(_this.stateManager.playerList).filter(function (playerId) {
              return StateRoleChecker_1.checkStateRole(_this.stateManager.playerList[playerId].state, StateRoleChecker_1.StateRoleType.CanCountType);
            }).length > 0 && _this.stateManager.foodList.length <= _this.stateManager.maxFoodListLength) {
              // 生き残ってるSnakeがいれば
              for (var i = 0; i < _this.stateManager.sessionParameter.config.food.volume[_this.localParameter.playerCountRank]; i++) {
                var foodAppearanceLength = _this.stateManager.sessionParameter.config.field.radius[_this.localParameter.playerCountRank] / 2;

                var food = _this._createFood({
                  x: g.game.random.generate() * foodAppearanceLength * 2 - foodAppearanceLength,
                  y: g.game.random.generate() * foodAppearanceLength * 2 - foodAppearanceLength,
                  word: _this.foodChars[g.game.random.get(0, _this.foodChars.length - 1)]
                });

                _this.stateManager.waitingFoodList.push(food);
              }
            }
          }, this.stateManager.sessionParameter.config.food.interval);
        };

        MainGameScene.prototype._applyInitPlayerLayoutData = function (playerInitLayoutList) {
          var _this = this;

          Object.keys(playerInitLayoutList).forEach(function (playerId) {
            var layoutData = playerInitLayoutList[playerId];
            _this.stateManager.playerList[playerId].uiState = {
              direction: layoutData.direction,
              state: layoutData.state
            };
          });
        };

        MainGameScene.prototype._createRoot = function () {
          this.root = new g.E({
            scene: this
          });
          this.append(this.root);
          this.bgLayer = new g.E({
            scene: this
          });
          this.root.append(this.bgLayer);
          this.foodLayer = new g.E({
            scene: this
          });
          this.root.append(this.foodLayer);
          this.snakeLayer = new g.E({
            scene: this
          });
          this.root.append(this.snakeLayer);
          this.userFollowingLayer = new g.E({
            scene: this
          });
          this.root.append(this.userFollowingLayer);
          this.noticeLayer = new g.E({
            scene: this
          });
          this.userFollowingLayer.append(this.noticeLayer);
        };

        MainGameScene.prototype._createBackground = function () {
          this.localParameter.playerCountRank = this.stateManager.dividePlayerCountIntoTiers();
          if (!!this.stateManager.sessionParameter.config.debug && this.stateManager.sessionParameter.config.debug.skipLottery) this.localParameter.playerCountRank = 0;
          var fieldRadius = this.stateManager.sessionParameter.config.field.radius[this.localParameter.playerCountRank];
          var bg = new g.FilledRect({
            scene: this,
            cssColor: "#5D99FF",
            x: -fieldRadius * 2,
            y: -fieldRadius * 2,
            width: fieldRadius * 4,
            height: fieldRadius * 4,
            opacity: this.stateManager.sessionParameter.config.field.bgOpacity
          });
          this.bgLayer.append(bg);
          this.stage = new Field_1.Field({
            scene: this,
            width: fieldRadius * 2,
            height: fieldRadius * 2,
            x: -fieldRadius,
            y: -fieldRadius,
            opacity: this.stateManager.sessionParameter.config.field.bgOpacity
          });
          this.bgLayer.append(this.stage);
        };

        MainGameScene.prototype._createTouchArea = function () {
          var _this = this;

          this.touchArea = new g.E({
            scene: this,
            width: g.game.width,
            height: g.game.height,
            local: true,
            touchable: true
          });
          this.userFollowingLayer.append(this.touchArea);
          this.touchArea.onPointDown.add(function (event) {
            if (!_this.stateManager.playerList[g.game.selfId] || _this.stateManager.playerList[g.game.selfId].preventType === MessageEventType_1.PreventType.TouchState || !StateRoleChecker_1.checkStateRole(_this.stateManager.playerList[g.game.selfId].state, StateRoleChecker_1.StateRoleType.CanOperateType)) return;
            var doublePointDuration = _this.stateManager.sessionParameter.config.userInput.doublePointDuration;
            var touchPoint = {
              x: event.point.x - g.game.width / 2,
              y: event.point.y - g.game.height / 2
            };
            var deg = calculateRadFromPoint(touchPoint).deg;
            var userInput = _this.stateManager.sessionParameter.config.userInput;
            var directionUnit = 360 / userInput.radianFineness;
            var direction = Math.floor((deg + 180) / directionUnit);
            var touchState = UserTouchState_1.UserTouchState.onPoint;

            if (g.game.age - _this.localParameter.lastPointUpTime <= doublePointDuration * g.game.fps) {
              _this.localParameter.startDoubleTapTime = g.game.age;
              touchState = UserTouchState_1.UserTouchState.onDoubleTap;

              if (StateRoleChecker_1.checkStateRole(_this.stateManager.playerList[g.game.selfId].state, StateRoleChecker_1.StateRoleType.CanSoundType)) {
                _this.stateManager.playAudioAtParamVolume(StateManager_1.AudioType.Dash);
              }
            }

            var message = {
              messageType: MessageEventType_1.MessageEventType.changeUserTouchState,
              messageData: {
                id: g.game.selfId,
                newDirection: direction,
                newState: touchState
              }
            };
            g.game.raiseEvent(new g.MessageEvent(message));

            if (StateRoleChecker_1.checkStateRole(_this.stateManager.playerList[g.game.selfId].state, StateRoleChecker_1.StateRoleType.CanOperateType)) {
              _this.localParameter.pointDownMarker.x = event.point.x;
              _this.localParameter.pointDownMarker.y = event.point.y;

              _this.localParameter.pointDownMarker.modified();

              _this.localParameter.pointDownMarker.show();
            }
          });
          this.touchArea.onPointMove.add(function (event) {
            if (!_this.stateManager.playerList[g.game.selfId] || _this.stateManager.playerList[g.game.selfId].uiState.state === UserTouchState_1.UserTouchState.onDoubleTap || _this.stateManager.playerList[g.game.selfId].uiState.state === UserTouchState_1.UserTouchState.onHold || !StateRoleChecker_1.checkStateRole(_this.stateManager.playerList[g.game.selfId].state, StateRoleChecker_1.StateRoleType.CanOperateType)) {
              return;
            }

            if (_this.stateManager.playerList[g.game.selfId].preventType === MessageEventType_1.PreventType.TouchState) return;
            var userInput = _this.stateManager.sessionParameter.config.userInput;
            var degAndNorm = calculateRadFromPoint(event.startDelta); // 操作の移動量が大きければ移動入力と解釈する

            if (degAndNorm.norm > userInput.pointMoveDistance) {
              var currentDirection = _this.stateManager.playerList[g.game.selfId].uiState.direction;
              var directionUnit = 360 / userInput.radianFineness;
              var newDirection = Math.floor((degAndNorm.deg + 180) / directionUnit);

              if (currentDirection !== newDirection) {
                var message = {
                  messageType: MessageEventType_1.MessageEventType.changeUserTouchState,
                  messageData: {
                    id: g.game.selfId,
                    newDirection: newDirection,
                    newState: UserTouchState_1.UserTouchState.onPoint
                  }
                };
                g.game.raiseEvent(new g.MessageEvent(message));
              }
            }
          });
          this.touchArea.onPointUp.add(function () {
            if (!_this.stateManager.playerList[g.game.selfId]) return;
            if (_this.stateManager.playerList[g.game.selfId].preventType === MessageEventType_1.PreventType.TouchState) return;

            _this.stateManager.audioAssets[StateManager_1.AudioType.Dash].stop();

            _this.localParameter.lastPointUpTime = g.game.age;
            var message = {
              messageType: MessageEventType_1.MessageEventType.changeUserTouchState,
              messageData: {
                id: g.game.selfId,
                newState: UserTouchState_1.UserTouchState.noPoint
              }
            };
            g.game.raiseEvent(new g.MessageEvent(message));

            _this.localParameter.pointDownMarker.hide();
          });
        };

        MainGameScene.prototype._createDashGaugeBar = function () {
          var dashGaugeBaseAsset = this.assets.main_dash_base;
          this.localParameter.dashingGaugeBar = new DashingGauge_1.DashingGauge({
            scene: this,
            width: dashGaugeBaseAsset.width,
            height: dashGaugeBaseAsset.height,
            src: dashGaugeBaseAsset,
            x: g.game.width / 2,
            y: g.game.height / 2 + 80,
            anchorX: 0.5,
            anchorY: 0.5,
            opacity: 0.0,
            maxGaugeAmount: this.stateManager.sessionParameter.config.snake.dashingTime
          });
          this.userFollowingLayer.append(this.localParameter.dashingGaugeBar);
        };

        MainGameScene.prototype._createUserNameLabels = function () {
          var _this = this;

          Object.keys(this.stateManager.playerList).forEach(function (playerId) {
            _this.stateManager.userNameLabels[playerId] = new akashic_label_1.Label({
              scene: _this,
              text: utils_1.clampString(_this.stateManager.playerList[playerId].user.name, 10, "…"),
              textColor: "white",
              font: _this.stateManager.resource.font,
              fontSize: 20,
              width: 300,
              x: _this.stateManager.playerList[playerId].snake.head.x - 150 - _this.userFollowingLayer.x,
              y: _this.stateManager.playerList[playerId].snake.head.y - 100 - _this.userFollowingLayer.y,
              textAlign: "center"
            });

            _this.userFollowingLayer.append(_this.stateManager.userNameLabels[playerId]);
          });
        };

        MainGameScene.prototype._createTimeView = function () {
          if (!this.stateManager.sessionParameter.config.time.isTimeBased) return;
          var timePanelAsset = this.assets.main_base_time;
          this.localParameter.timePanel = new TimePanel_1.TimePanel({
            scene: this,
            width: timePanelAsset.width,
            height: timePanelAsset.height,
            x: 5,
            y: 5,
            backgroundImage: timePanelAsset,
            remainTime: this.localParameter.remainTime,
            local: true
          });
          this.userFollowingLayer.append(this.localParameter.timePanel);
        };

        MainGameScene.prototype._createRankingView = function () {
          var rankingPanelAsset = this.assets.main_rank_base;
          this.localParameter.rankingPanel = new g.Sprite({
            scene: this,
            hidden: true,
            width: rankingPanelAsset.width,
            height: rankingPanelAsset.height,
            y: 590,
            src: rankingPanelAsset,
            local: true
          });
          this.userFollowingLayer.append(this.localParameter.rankingPanel);

          for (var rank = 1; rank <= 5; ++rank) {
            var rankIconAsset = this.assets["main_rank_" + rank];
            var rankIcon = new g.Sprite({
              scene: this,
              src: rankIconAsset,
              x: 55 + 361 * ((rank - 1) % 3),
              y: 608 - this.localParameter.rankingPanel.y + 53 * Math.floor((rank - 1) / 3),
              local: true
            });
            this.localParameter.rankingPanel.append(rankIcon);
            var ranker = new akashic_label_1.Label({
              scene: this,
              text: "",
              textColor: "white",
              font: this.stateManager.resource.font,
              fontSize: 24,
              width: 24 * 12,
              x: 127 + 361 * ((rank - 1) % 3),
              y: 614 - this.localParameter.rankingPanel.y + 53 * Math.floor((rank - 1) / 3),
              local: true
            });
            this.localParameter.topPlayerLabelList.push(ranker);
            this.localParameter.rankingPanel.append(ranker);
          }

          var rankBroadcasterIconAsset = this.assets.main_rank_host;
          var rankBroadcasterIcon = new g.Sprite({
            scene: this,
            src: rankBroadcasterIconAsset,
            x: 761,
            y: 661 - this.localParameter.rankingPanel.y,
            local: true
          });
          this.localParameter.rankingPanel.append(rankBroadcasterIcon);
          this.localParameter.broadcasterRankLabel = new akashic_label_1.Label({
            scene: this,
            text: "",
            textColor: "white",
            font: this.stateManager.resource.font,
            fontSize: 26,
            width: 26 * 2,
            x: 860,
            y: 667 - this.localParameter.rankingPanel.y,
            textAlign: "center",
            local: true
          });
          this.localParameter.rankingPanel.append(this.localParameter.broadcasterRankLabel);

          if (!this.stateManager.isBroadcaster) {
            var rankYouIconAsset = this.assets.main_rank_you;
            var rankYouIcon = new g.Sprite({
              scene: this,
              src: rankYouIconAsset,
              x: 968,
              y: 661 - this.localParameter.rankingPanel.y,
              local: true
            });
            this.localParameter.rankingPanel.append(rankYouIcon);
            this.localParameter.yourRankLabel = new akashic_label_1.Label({
              scene: this,
              text: "-",
              textColor: "white",
              font: this.stateManager.resource.font,
              fontSize: 26,
              width: 26 * 2,
              x: 1049,
              y: 667 - this.localParameter.rankingPanel.y,
              textAlign: "center",
              local: true
            });
            this.localParameter.rankingPanel.append(this.localParameter.yourRankLabel);
          }

          this._createRankingButton();
        };

        MainGameScene.prototype._createRankingButton = function () {
          var _this = this;

          var rankingButtonOffAsset = this.assets.main_btn_rank_off;
          var rankingButtonOffTappedAsset = this.assets.main_btn_rank_off_diff;
          var rankingButtonOnAsset = this.assets.main_btn_rank_on;
          var rankingButtonOnTappedAsset = this.assets.main_btn_rank_on_diff;
          var rankingButton = new g.Sprite({
            scene: this,
            src: rankingButtonOnAsset,
            x: 1127,
            y: 560,
            touchable: true,
            local: true,
            tag: ButtonState.On
          });
          rankingButton.onPointDown.add(function () {
            _this.stateManager.playAudioAtParamVolume(StateManager_1.AudioType.Select);

            switch (rankingButton.tag) {
              case ButtonState.Off:
                rankingButton._surface = g.SurfaceUtil.asSurface(rankingButtonOffTappedAsset);
                rankingButton.invalidate();
                break;

              case ButtonState.On:
                rankingButton._surface = g.SurfaceUtil.asSurface(rankingButtonOnTappedAsset);
                rankingButton.invalidate();
                break;

              default: // do nothing

            }
          });
          rankingButton.onPointUp.add(function () {
            switch (rankingButton.tag) {
              case ButtonState.Off:
                _this.localParameter.rankingPanel.hide();

                rankingButton.tag = ButtonState.On;
                rankingButton._surface = g.SurfaceUtil.asSurface(rankingButtonOnAsset);
                rankingButton.invalidate();
                break;

              case ButtonState.On:
                _this.localParameter.rankingPanel.show();

                rankingButton.tag = ButtonState.Off;
                rankingButton._surface = g.SurfaceUtil.asSurface(rankingButtonOffAsset);
                rankingButton.invalidate();
                break;

              default: // do nothing

            }
          });
          this.userFollowingLayer.append(rankingButton);
        };

        MainGameScene.prototype._createScoreView = function () {
          var killCountPanelAsset = this.assets.main_base_kill;
          this.localParameter.killCountPanel = new ScorePanel_1.ScorePanel({
            scene: this,
            width: killCountPanelAsset.width,
            height: killCountPanelAsset.height,
            x: 197,
            y: 5,
            backgroundImage: killCountPanelAsset,
            score: 0,
            local: true
          });
          this.userFollowingLayer.append(this.localParameter.killCountPanel);
          var lengthCountPanelAsset = this.assets.main_base_length;
          this.localParameter.lengthCountPanel = new ScorePanel_1.ScorePanel({
            scene: this,
            width: lengthCountPanelAsset.width,
            height: lengthCountPanelAsset.height,
            x: 447,
            y: 5,
            backgroundImage: lengthCountPanelAsset,
            score: 0,
            local: true
          });
          this.userFollowingLayer.append(this.localParameter.lengthCountPanel);
        };

        MainGameScene.prototype._createBroadcasterDisplayView = function () {
          this.localParameter.broadcasterDisplayViewing = new g.Label({
            scene: this,
            font: this.stateManager.resource.font,
            textColor: "white",
            fontSize: 54,
            text: "放送者画面視聴中…",
            textAlign: "center",
            x: g.game.width / 2,
            y: 80,
            anchorX: 0.5,
            anchorY: 0.0,
            hidden: !this._isAudience(g.game.selfId)
          });
          this.userFollowingLayer.append(this.localParameter.broadcasterDisplayViewing);
        };

        MainGameScene.prototype._createMiniMapView = function () {
          var miniMapBaseAsset = this.assets.main_map_base;
          this.localParameter.miniMap = new MiniMap_1.MiniMap({
            scene: this,
            width: miniMapBaseAsset.width,
            height: miniMapBaseAsset.height,
            x: 1063,
            y: 5,
            field: {
              width: this.stage.nowWidth,
              height: this.stage.nowHeight
            },
            backgroundImage: miniMapBaseAsset,
            local: true
          });
          this.userFollowingLayer.append(this.localParameter.miniMap);
        };

        MainGameScene.prototype._createPointdownView = function () {
          var baseAsset = this.assets.field_base;
          this.localParameter.pointDownMarker = new g.Sprite({
            scene: this,
            src: baseAsset,
            opacity: 0.0,
            anchorX: 0.5,
            anchorY: 0.5,
            hidden: true,
            local: true
          });
          this.userFollowingLayer.append(this.localParameter.pointDownMarker);
        };

        MainGameScene.prototype._playBGM = function () {
          // BGM再生
          this.stateManager.audioAssets[StateManager_1.AudioType.GameBGM] = this.assets.snake_bgm;
          this.stateManager.playAudioAtParamVolume(StateManager_1.AudioType.GameBGM);
        };

        MainGameScene.prototype._setSE = function () {
          this.stateManager.audioAssets[StateManager_1.AudioType.Count] = this.assets.SE_count;
          this.stateManager.audioAssets[StateManager_1.AudioType.Start] = this.assets.SE_start;
          this.stateManager.audioAssets[StateManager_1.AudioType.Finish] = this.assets.SE_finish;
          this.stateManager.audioAssets[StateManager_1.AudioType.Collision] = this.assets.SE_collision;
          this.stateManager.audioAssets[StateManager_1.AudioType.Dash] = this.assets.SE_dash;
          this.stateManager.audioAssets[StateManager_1.AudioType.Jewel] = this.assets.SE_jewel;
          this.stateManager.audioAssets[StateManager_1.AudioType.Select] = this.assets.SE_select;
        };

        MainGameScene.prototype._createRespawnView = function () {
          var _this = this;

          var respawnButtonOffAsset = this.assets.main_btn_spawn_off;
          var respawnButtonOnAsset = this.assets.main_btn_spawn_on;
          this.localParameter.respawnButton = new g.Sprite({
            scene: this,
            src: respawnButtonOffAsset,
            width: respawnButtonOffAsset.width,
            height: respawnButtonOffAsset.height,
            x: 30,
            y: 460,
            local: true,
            touchable: true
          });
          this.localParameter.respawnButton.onPointDown.add(function () {
            _this.localParameter.respawnButton._surface = g.SurfaceUtil.asSurface(respawnButtonOnAsset);

            _this.localParameter.respawnButton.invalidate();
          });
          this.localParameter.respawnButton.onPointUp.add(function () {
            _this.localParameter.respawnButton._surface = g.SurfaceUtil.asSurface(respawnButtonOffAsset);
            _this.localParameter.respawnButton.touchable = false; // 二度押し防止

            _this.localParameter.respawnButton.invalidate();

            if (!_this.stateManager.playerList[g.game.selfId].snake) {
              var respawnMessage = {
                messageType: MessageEventType_1.MessageEventType.respawnSnake
              };
              g.game.raiseEvent(new g.MessageEvent(respawnMessage));
              var preventTouchMessage = {
                messageType: MessageEventType_1.MessageEventType.preventUsertouch,
                messageData: {
                  playerId: g.game.selfId,
                  preventType: MessageEventType_1.PreventType.TouchState
                }
              };
              g.game.raiseEvent(new g.MessageEvent(preventTouchMessage));
            }
          });
          this.userFollowingLayer.append(this.localParameter.respawnButton);
        };

        MainGameScene.prototype._createAngelSnakeView = function () {
          var _this = this;

          var respawnButtonOffAsset = this.assets.main_btn_spawn_off_angel;
          var respawnButtonOnAsset = this.assets.main_btn_spawn_on_angel;
          this.localParameter.respawnButton = new g.Sprite({
            scene: this,
            src: respawnButtonOffAsset,
            width: respawnButtonOffAsset.width,
            height: respawnButtonOffAsset.height,
            x: 30,
            y: 460,
            local: true,
            touchable: true
          });
          this.localParameter.respawnButton.onPointDown.add(function () {
            _this.localParameter.respawnButton._surface = g.SurfaceUtil.asSurface(respawnButtonOnAsset);

            _this.localParameter.respawnButton.invalidate();
          });
          this.localParameter.respawnButton.onPointUp.add(function () {
            _this.localParameter.respawnButton._surface = g.SurfaceUtil.asSurface(respawnButtonOffAsset);

            _this.localParameter.respawnButton.invalidate();

            if (!_this.stateManager.playerList[g.game.selfId].snake) {
              var message = {
                messageType: MessageEventType_1.MessageEventType.respawnBroadcasterAngelSnake
              };
              g.game.raiseEvent(new g.MessageEvent(message));
            }
          });
          this.userFollowingLayer.append(this.localParameter.respawnButton);
        };

        MainGameScene.prototype._createUnableRespawnView = function () {
          var unableRespawnButtonAsset = this.assets.main_btn_spawn_unable;
          this.localParameter.respawnButton = new g.Sprite({
            scene: this,
            src: unableRespawnButtonAsset,
            width: unableRespawnButtonAsset.width,
            height: unableRespawnButtonAsset.height,
            x: 30,
            y: 460,
            local: true
          });
          this.userFollowingLayer.append(this.localParameter.respawnButton);
        };

        MainGameScene.prototype._createNotice = function (noticeType, playerId) {
          var notice = new PopupNotice_1.PopupNotice({
            scene: this,
            width: 428,
            height: 40,
            x: 848,
            y: 528,
            opacity: 0,
            noticeType: noticeType,
            font: this.stateManager.resource.font,
            name: noticeType === PopupNotice_1.NoticeType.Chance ? "" : this.stateManager.playerList[playerId].user.name,
            local: true
          });
          this.noticeLayer.append(notice);
          return notice;
        };

        MainGameScene.prototype._addNotice = function (newNotice) {
          // noticeList := [0-> fadeIn] [1] [2] [3] [4] [5] [6-> fadeOut] [7:Wait for it to be destroyed]
          this.localParameter.noticeList.unshift(newNotice);

          if (this.localParameter.noticeList.length === 8) {
            var outdatedNotice = this.localParameter.noticeList.pop();
            this.noticeLayer.remove(outdatedNotice);
            if (!outdatedNotice.destroyed()) outdatedNotice.destroy();
          }

          this.localParameter.noticeList.forEach(function (notice, i) {
            if (i === 0) notice.fadeInUp();else if (i === 6) notice.fadeOutUp();else notice.up(i);
          });
        };

        MainGameScene.prototype._createDebugView = function () {
          var _this = this;

          var label = new akashic_label_1.Label({
            scene: this,
            font: this.stateManager.resource.font,
            text: "デバッグ中...",
            textColor: "red",
            fontSize: 36,
            width: 280
          });
          this.userFollowingLayer.append(label);
          var downPlayerCountRankLabel = new akashic_label_1.Label({
            scene: this,
            font: this.stateManager.resource.font,
            text: "縮小",
            textColor: "white",
            fontSize: 36,
            width: 280,
            y: 70,
            touchable: true
          });
          downPlayerCountRankLabel.onPointUp.add(function () {
            _this.localParameter.playerCountRank = Math.min(4, _this.localParameter.playerCountRank + 1);
          });
          this.userFollowingLayer.append(downPlayerCountRankLabel);
        };

        MainGameScene.prototype._createTmpSnake = function (playerId, layoutData) {
          var words = utils_1.stringToArray(layoutData.name).slice(0, Math.min(layoutData.name.length, this.stateManager.sessionParameter.config.snake.maxNameLength));

          if (words.length < this.stateManager.sessionParameter.config.snake.maxNameLength) {
            var blankCount = this.stateManager.sessionParameter.config.snake.maxNameLength - words.length;

            for (var i = 0; i < blankCount; ++i) {
              words.push("　");
            }
          }

          var snake = new Snake_1.Snake({
            parent: this.snakeLayer,
            x: layoutData.position.x,
            y: layoutData.position.y,
            angle: layoutData.direction / this.stateManager.sessionParameter.config.userInput.radianFineness * 360,
            words: words,
            snakeBaseSpeed: this.stateManager.sessionParameter.config.snake.baseSpeed,
            snakeMaxSpeedScale: this.stateManager.sessionParameter.config.snake.maxSpeedScale,
            snakeMaxKnotLength: this.stateManager.sessionParameter.config.snake.maxKnotLength,
            font: this.stateManager.resource.font,
            snakeType: this.stateManager.playerList[playerId].snakeType,
            rebornEffect: false
          });
          return snake;
        };

        MainGameScene.prototype._createPlayersSnakes = function (playerInitLayoutList) {
          var _this = this;

          Object.keys(playerInitLayoutList).forEach(function (playerId) {
            var tmpSnake = _this._createTmpSnake(playerId, playerInitLayoutList[playerId]);

            _this.stateManager.setCameraAndSnake(playerId, tmpSnake);
          }); // ゲーム不参加者の場合

          if (!!g.game.selfId && !this.stateManager.playerList[g.game.selfId]) {
            g.game.focusingCamera = this.stateManager.playerList[this.stateManager.broadcaster.id].camera;
          }
        };

        MainGameScene.prototype._checkStopDashing = function () {
          var dashingTime = this.stateManager.sessionParameter.config.snake.dashingTime;

          if (this.localParameter.dashingGauge <= 0 || g.game.age - this.localParameter.startDoubleTapTime > dashingTime * g.game.fps) {
            this.stateManager.audioAssets[StateManager_1.AudioType.Dash].stop();
            var message = {
              messageType: MessageEventType_1.MessageEventType.changeUserTouchState,
              messageData: {
                id: g.game.selfId,
                newState: UserTouchState_1.UserTouchState.onHold
              }
            };
            g.game.raiseEvent(new g.MessageEvent(message));
          }
        };

        MainGameScene.prototype._snakeDestructionEventFlow = function (deadPlayerId) {
          if (this.stateManager.isGameOver || deadPlayerId === this.stateManager.broadcaster.id) {
            var message = {
              messageType: MessageEventType_1.MessageEventType.destroySnake,
              messageData: {
                deadPlayerId: deadPlayerId
              }
            };
            g.game.raiseEvent(new g.MessageEvent(message));
          } else {
            // 「放送者画面に切り替わります」表示
            var message = {
              messageType: MessageEventType_1.MessageEventType.animation,
              messageData: {
                animationType: MessageEventType_1.AnimationType.ToBroadcasterView,
                scope: MessageEventType_1.ScopeType.One,
                playerId: deadPlayerId
              }
            };
            g.game.raiseEvent(new g.MessageEvent(message));
            this.setTimeout(function () {
              var message = {
                messageType: MessageEventType_1.MessageEventType.destroySnake,
                messageData: {
                  deadPlayerId: deadPlayerId
                }
              };
              g.game.raiseEvent(new g.MessageEvent(message));
            }, 3000);
          }
        };

        MainGameScene.prototype._manageSnakeHeadOnServerInstance = function (playerId, snake, state) {
          if (g.game.isActiveInstance() && Math.pow(snake.head.x, 2) + Math.pow(snake.head.y, 2) >= Math.pow(this.stage.nowWidth / 2, 2)) {
            // 壁沿い走行時は自動でスネークの顔の向きが変わるため、PlayerList#uiState#directionも更新する
            this._adjustSnakeHeadAlongWall(playerId, snake.head.angle + 90, state);
          }
        };

        MainGameScene.prototype._adjustSnakeHeadAlongWall = function (playerId, angle, state) {
          var radianFineness = this.stateManager.sessionParameter.config.userInput.radianFineness;
          var currentDirection = this.stateManager.playerList[playerId].uiState.direction;
          var directionUnit = 360 / radianFineness;
          var newDirection = Math.floor((angle + 180) / directionUnit) % radianFineness;

          if (currentDirection !== newDirection) {
            var message = {
              messageType: MessageEventType_1.MessageEventType.changeUserTouchState,
              messageData: {
                id: playerId,
                newDirection: newDirection,
                newState: state,
                canPlaySE: false
              }
            };
            g.game.raiseEvent(new g.MessageEvent(message));
          }
        };

        MainGameScene.prototype._createFood = function (foodElement) {
          var food = new Food_1.Food({
            parent: this.foodLayer,
            x: foodElement.x,
            y: foodElement.y,
            font: this.stateManager.resource.font,
            word: foodElement.word
          });
          return food;
        };

        MainGameScene.prototype._initJewel = function () {
          var playerCountRank = this.stateManager.dividePlayerCountIntoTiers();
          var fieldRadius = this.stateManager.sessionParameter.config.field.radius[playerCountRank] - 50;
          var lengthOfSquareInField = Math.floor(fieldRadius / Math.sqrt(2)) * 2;

          var jewel = this._createJewel({
            x: g.game.random.generate() * lengthOfSquareInField - lengthOfSquareInField / 2,
            y: g.game.random.generate() * lengthOfSquareInField - lengthOfSquareInField / 2
          });

          this.stateManager.jewelData = {
            jewel: jewel,
            ownerId: null // 落ちている時は、所有者はいない

          };
          var jewelPopAsset = this.assets.main_jewel_pop;
          this.localParameter.jewelPop = new g.Sprite({
            scene: this,
            src: jewelPopAsset,
            x: g.game.width / 2,
            y: g.game.height / 2,
            anchorX: 0.5,
            anchorY: 0.5,
            opacity: 0.0
          });
          this.userFollowingLayer.append(this.localParameter.jewelPop);
        };

        MainGameScene.prototype._createJewel = function (jewelElement) {
          var jewel = new Jewel_1.Jewel({
            parent: this.snakeLayer,
            x: jewelElement.x,
            y: jewelElement.y
          });
          return jewel;
        };

        MainGameScene.prototype._isAudience = function (playerId) {
          return !!playerId && (!this.stateManager.playerList[playerId] || playerId !== this.stateManager.broadcaster.id && !!this.stateManager.playerList[playerId] && StateRoleChecker_1.checkStateRole(this.stateManager.playerList[playerId].state, StateRoleChecker_1.StateRoleType.IsAudienceType));
        };

        MainGameScene.prototype._stopAllAudio = function () {
          var _this = this;

          Object.keys(this.stateManager.audioAssets).forEach(function (audioType) {
            _this.stateManager.audioAssets[audioType].stop();
          });
        };

        MainGameScene.prototype._dropSnakeBody = function (deadPlayerId) {
          var _this = this;

          if (!!this.stateManager.playerList[deadPlayerId] && !!this.stateManager.playerList[deadPlayerId].snake && StateRoleChecker_1.checkStateRole(this.stateManager.playerList[deadPlayerId].state, StateRoleChecker_1.StateRoleType.CanDropType)) {
            var deadSnake = this.stateManager.playerList[deadPlayerId].snake; // 節をエサとして落とす

            deadSnake.segments.forEach(function (seg) {
              if (seg.type === Snake_1.SnakeSegmentType.Jewel) return;

              var food = _this._createFood({
                x: seg.x + seg.body.x + seg.body.width / 2,
                y: seg.y + seg.body.y + seg.body.height / 2,
                word: seg.word
              });

              _this.stateManager.waitingFoodList.push(food);
            }); // お宝を落とす

            if (deadSnake.haveJewel) {
              var jewel = this._createJewel({
                x: deadSnake.segments[deadSnake.segments.length - 1].x + deadSnake.segments[deadSnake.segments.length - 1].body.x,
                y: deadSnake.segments[deadSnake.segments.length - 1].y + deadSnake.segments[deadSnake.segments.length - 1].body.y
              });

              this.stateManager.jewelData = {
                jewel: jewel,
                ownerId: null // 落ちている時は、所有者はいない

              }; // お宝チャンス通知作成

              var chanceNotice = this._createNotice(PopupNotice_1.NoticeType.Chance);

              this._addNotice(chanceNotice);
            }
          }
        };

        return MainGameScene;
      }(SceneBase_1.SceneBase);

      exports.MainGameScene = MainGameScene;
      var ButtonState;

      (function (ButtonState) {
        ButtonState["On"] = "On";
        ButtonState["Off"] = "Off";
      })(ButtonState = exports.ButtonState || (exports.ButtonState = {}));

      function calculateRadFromPoint(startDelta) {
        var pointNorm = Math.sqrt(Math.abs(Math.pow(startDelta.x, 2) + Math.pow(startDelta.y, 2)));
        var pointDirectionFromCenterNormalized = {
          x: startDelta.x / pointNorm,
          y: startDelta.y / pointNorm
        }; // 3時の方向から時計回りの360度でアングルを得る（x→y↓座標系）

        var deg = Math.atan2(-pointDirectionFromCenterNormalized.y, -pointDirectionFromCenterNormalized.x) * 180 / Math.PI;
        return {
          deg: deg,
          norm: pointNorm
        };
      }
    }, {
      "../../StateManager": 19,
      "../../assetIds": 21,
      "../../commonUtils/utils": 23,
      "../../entity/DashingGauge": 25,
      "../../entity/Field": 26,
      "../../entity/Food": 27,
      "../../entity/Jewel": 28,
      "../../entity/MiniMap": 29,
      "../../entity/PopupNotice": 31,
      "../../entity/ScorePanel": 33,
      "../../entity/Snake": 34,
      "../../entity/TimePanel": 35,
      "../../types/MessageEventType": 49,
      "../../types/UserTouchState": 50,
      "../../utils/StateRoleChecker": 51,
      "../SceneBase": 46,
      "./MainGameBehavior": 42,
      "@akashic-extension/akashic-label": 8,
      "@akashic-extension/akashic-timeline": 15
    }],
    44: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics19 = function extendStatics(d, b) {
          _extendStatics19 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics19(d, b);
        };

        return function (d, b) {
          _extendStatics19(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.ResultBehavior = void 0;

      var Behavior_1 = require("../Behavior");

      var MessageEventType_1 = require("../../types/MessageEventType");

      var ResultBehavior =
      /** @class */
      function (_super) {
        __extends(ResultBehavior, _super);

        function ResultBehavior(param) {
          return _super.call(this, param) || this;
        }

        ResultBehavior.prototype.onMessageEvent = function (event) {
          this._onAllInstanceEvent(event);

          if (g.game.isActiveInstance()) this._onActiveInstanceEvent(event);
        };
        /**
         * 全てのインスタンスで拾うイベント
         */


        ResultBehavior.prototype._onAllInstanceEvent = function (event) {
          var data = event.data;
          var messageType = data.messageType;

          switch (messageType) {
            case MessageEventType_1.MessageEventType.initResult:
              g.game.focusingCamera = new g.Camera2D({});
              this.scene.init(data.messageData.lengthRankingPlayerIdList, data.messageData.killRankingPlayerIdList, data.messageData.jewelOwnerId);
              break;

            case MessageEventType_1.MessageEventType.nextRankingType:
              this.scene.changeShownRankingType(data.messageData.nextRankingType);
              break;

            case MessageEventType_1.MessageEventType.changeScrollSpeed:
              this.scene.changeScrollSpeed(data.messageData.rankingType, data.messageData.speedType);
              break;

            default: // do nothing

          }
        };
        /**
         * サーバーインスタンスでのみ拾うイベント
         */


        ResultBehavior.prototype._onActiveInstanceEvent = function (event) {
          var data = event.data;
          var messageType = data.messageType;

          switch (messageType) {
            default: // do nothing

          }
        };

        return ResultBehavior;
      }(Behavior_1.Behavior);

      exports.ResultBehavior = ResultBehavior;
    }, {
      "../../types/MessageEventType": 49,
      "../Behavior": 41
    }],
    45: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics20 = function extendStatics(d, b) {
          _extendStatics20 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics20(d, b);
        };

        return function (d, b) {
          _extendStatics20(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.RankingType = exports.ResultScene = exports.createResultScene = void 0;

      var akashic_label_1 = require("@akashic-extension/akashic-label");

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var SceneBase_1 = require("../SceneBase");

      var StateManager_1 = require("../../StateManager");

      var ResultBehavior_1 = require("./ResultBehavior");

      var utils_1 = require("../../commonUtils/utils");

      var MessageEventType_1 = require("../../types/MessageEventType");

      var assetIds_1 = require("../../assetIds");

      var RankingLabel_1 = require("../../entity/ResultScene/RankingLabel");

      function createResultScene(stateManager) {
        var assetIds = [];
        assetIds.push.apply(assetIds, assetIds_1.resultAssetIds);
        var resultScene = new ResultScene({
          game: g.game,
          stateManager: stateManager,
          assetIds: assetIds
        });
        return resultScene;
      }

      exports.createResultScene = createResultScene;

      var ResultScene =
      /** @class */
      function (_super) {
        __extends(ResultScene, _super);

        function ResultScene(param) {
          var _this = _super.call(this, param) || this;

          _this.stateManager = param.stateManager;
          _this.timeline = new akashic_timeline_1.Timeline(_this);

          _this.onLoad.add(function () {
            _this.setBehavior(new ResultBehavior_1.ResultBehavior({
              scene: _this,
              stateManager: _this.stateManager
            }));

            _this.setMessageEventListener();

            if (g.game.isActiveInstance()) _this.stateManager.setupResultRanking();
          });

          return _this;
        }

        ResultScene.prototype.init = function (lengthRankingPlayerIdList, killRankingPlayerIdList, jewelOwnerId) {
          this._createFont();

          this._createRoot();

          this._playBGM();

          this._createBaseRanking();

          this._createLengthRanking(lengthRankingPlayerIdList);

          this._createKillRanking(killRankingPlayerIdList);

          this._createJewelOwnerLabel(jewelOwnerId);

          if (this.stateManager.isBroadcaster) {
            this._createNextButton();

            this._createBackButton();
          } else {
            this._createUnableButton();
          } // ログ出力


          if (g.game.isActiveInstance()) {
            try {
              this._sendResultLog(lengthRankingPlayerIdList, killRankingPlayerIdList, jewelOwnerId);
            } catch (e) {
              console.error(e);
            }
          }
        };

        ResultScene.prototype.changeShownRankingType = function (nextRankingType) {
          switch (nextRankingType) {
            case RankingType.Length:
              this.lengthRankingLabel.setInitialPosition();
              this.lengthRankingLabel.scroll();
              this.killRanking.hide();
              this.lengthRanking.show();
              this.showRankingType = RankingType.Length;
              break;

            case RankingType.Kill:
              this.killRankingLabel.setInitialPosition();
              this.killRankingLabel.scroll();
              this.lengthRanking.hide();
              this.killRanking.show();
              this.showRankingType = RankingType.Kill;
              break;

            default: // do nothing

          }
        };

        ResultScene.prototype.changeScrollSpeed = function (rankingType, speedType) {
          switch (rankingType) {
            case RankingType.Length:
              this.lengthRankingLabel.scroll(speedType);
              break;

            case RankingType.Kill:
              this.killRankingLabel.scroll(speedType);
              break;

            default: // do nothing

          }
        };

        ResultScene.prototype._createFont = function () {
          var resultFontGlyph = JSON.parse(this.assets.result_glyph.data);
          this.resultNumFont = new g.BitmapFont({
            src: this.assets.result_num_b,
            map: resultFontGlyph,
            defaultGlyphWidth: 24,
            defaultGlyphHeight: 36
          });
          this.resultNumRedFont = new g.BitmapFont({
            src: this.assets.result_num_r,
            map: resultFontGlyph,
            defaultGlyphWidth: 24,
            defaultGlyphHeight: 36
          });
        };

        ResultScene.prototype._createRoot = function () {
          this.root = new g.E({
            scene: this
          });
          this.append(this.root);
        };

        ResultScene.prototype._playBGM = function () {
          var _this = this;

          this.stateManager.audioAssets[StateManager_1.AudioType.Intro] = this.assets.snake_result_intro;
          this.stateManager.playAudioAtParamVolume(StateManager_1.AudioType.Intro);
          this.setTimeout(function () {
            _this.stateManager.audioAssets[StateManager_1.AudioType.ResultBGM] = _this.assets.snake_result;

            _this.stateManager.playAudioAtParamVolume(StateManager_1.AudioType.ResultBGM);
          }, this.stateManager.audioAssets[StateManager_1.AudioType.Intro].duration);
        };

        ResultScene.prototype._createBaseRanking = function () {
          var baseRankingAsset = this.assets.result_base_ranking;
          this.baseRanking = new g.Sprite({
            scene: this,
            src: baseRankingAsset,
            width: baseRankingAsset.width,
            height: baseRankingAsset.height,
            x: 151,
            y: 50
          });
          this.root.append(this.baseRanking);
        };

        ResultScene.prototype._createLengthRanking = function (lengthRankingPlayerIdList) {
          this.showRankingType = RankingType.Length;
          this.lengthRanking = new g.E({
            scene: this
          });
          this.root.append(this.lengthRanking);
          this.lengthRankingLabel = new RankingLabel_1.RankingLabel({
            scene: this,
            width: 978,
            height: 470 - 14,
            x: 151,
            y: 50,
            touchable: this.stateManager.isBroadcaster,
            resultNumFont: this.resultNumFont,
            resultNumRedFont: this.resultNumRedFont,
            rankingPlayerIdList: lengthRankingPlayerIdList
          });

          if (this.stateManager.isBroadcaster) {
            this.lengthRankingLabel.onPointDown.add(function () {
              var message = {
                messageType: MessageEventType_1.MessageEventType.changeScrollSpeed,
                messageData: {
                  rankingType: RankingType.Length,
                  speedType: RankingLabel_1.ScrollSpeedType.High
                }
              };
              g.game.raiseEvent(new g.MessageEvent(message));
            });
            this.lengthRankingLabel.onPointUp.add(function () {
              var message = {
                messageType: MessageEventType_1.MessageEventType.changeScrollSpeed,
                messageData: {
                  rankingType: RankingType.Length,
                  speedType: RankingLabel_1.ScrollSpeedType.Normal
                }
              };
              g.game.raiseEvent(new g.MessageEvent(message));
            });
          }

          this.lengthRanking.append(this.lengthRankingLabel);
          this.lengthRankingLabel.scroll();
          var lengthRankingTitleAsset = this.assets.result_title_length;
          var lengthRankingTitle = new g.Sprite({
            scene: this,
            src: lengthRankingTitleAsset,
            x: 220,
            y: 5
          });
          this.lengthRanking.append(lengthRankingTitle);
        };

        ResultScene.prototype._createKillRanking = function (killRankingPlayerIdList) {
          this.killRanking = new g.E({
            scene: this,
            hidden: true
          });
          this.root.append(this.killRanking);
          this.killRankingLabel = new RankingLabel_1.RankingLabel({
            scene: this,
            width: 978,
            height: 470 - 14,
            x: 151,
            y: 50,
            touchable: this.stateManager.isBroadcaster,
            resultNumFont: this.resultNumFont,
            resultNumRedFont: this.resultNumRedFont,
            rankingPlayerIdList: killRankingPlayerIdList
          });

          if (this.stateManager.isBroadcaster) {
            this.killRankingLabel.onPointDown.add(function () {
              var message = {
                messageType: MessageEventType_1.MessageEventType.changeScrollSpeed,
                messageData: {
                  rankingType: RankingType.Kill,
                  speedType: RankingLabel_1.ScrollSpeedType.High
                }
              };
              g.game.raiseEvent(new g.MessageEvent(message));
            });
            this.killRankingLabel.onPointUp.add(function () {
              var message = {
                messageType: MessageEventType_1.MessageEventType.changeScrollSpeed,
                messageData: {
                  rankingType: RankingType.Kill,
                  speedType: RankingLabel_1.ScrollSpeedType.Normal
                }
              };
              g.game.raiseEvent(new g.MessageEvent(message));
            });
          }

          this.killRanking.append(this.killRankingLabel);
          var killRankingTitleAsset = this.assets.result_title_kill;
          var killRankingTitle = new g.Sprite({
            scene: this,
            src: killRankingTitleAsset,
            x: 220,
            y: 5
          });
          this.killRanking.append(killRankingTitle);
        };

        ResultScene.prototype._createJewelOwnerLabel = function (ownerId) {
          var ownerBaseAsset = this.assets.result_base_treasure;
          var ownerBase = new g.Sprite({
            scene: this,
            src: ownerBaseAsset,
            x: 281,
            y: 530
          });
          this.root.append(ownerBase);
          var ownerLabelText = "";

          if (ownerId == null) {
            ownerLabelText += "お宝保持者はいませんでした";
          } else {
            ownerLabelText += utils_1.clampString(this.stateManager.playerList[ownerId].user.name, 14, "…");
          }

          var ownerLabel = new akashic_label_1.Label({
            scene: this,
            text: ownerLabelText,
            textColor: "white",
            font: this.stateManager.resource.font,
            fontSize: 34,
            width: ownerBaseAsset.width,
            x: 281,
            y: 612,
            textAlign: "center"
          });
          this.root.append(ownerLabel);
        };

        ResultScene.prototype._createNextButton = function () {
          var _this = this;

          var nextButtonOffAsset = this.assets.result_btn_next_off;
          var nextButtonOnAsset = this.assets.result_btn_next_on;
          var button = new g.Sprite({
            scene: this,
            src: nextButtonOffAsset,
            width: nextButtonOffAsset.width,
            height: nextButtonOffAsset.height,
            x: 1138,
            y: 552,
            touchable: true,
            local: true
          });
          button.onPointDown.add(function () {
            _this.stateManager.playAudioAtParamVolume(StateManager_1.AudioType.Select);

            button._surface = g.SurfaceUtil.asSurface(nextButtonOnAsset);
            button.invalidate();
          });
          button.onPointUp.add(function () {
            button._surface = g.SurfaceUtil.asSurface(nextButtonOffAsset);
            button.invalidate();
            var nextRankingType;

            switch (_this.showRankingType) {
              case RankingType.Length:
                nextRankingType = RankingType.Kill;
                break;

              case RankingType.Kill:
                nextRankingType = RankingType.Length;
                break;

              default: // do nothing

            }

            var message = {
              messageType: MessageEventType_1.MessageEventType.nextRankingType,
              messageData: {
                nextRankingType: nextRankingType
              }
            };
            g.game.raiseEvent(new g.MessageEvent(message));
          });
          this.root.append(button);
        };

        ResultScene.prototype._createBackButton = function () {
          var _this = this;

          var backButtonOffAsset = this.assets.result_btn_back_off;
          var backButtonOnAsset = this.assets.result_btn_back_on;
          var button = new g.Sprite({
            scene: this,
            src: backButtonOffAsset,
            width: backButtonOffAsset.width,
            height: backButtonOffAsset.height,
            x: 1013,
            y: 552,
            touchable: true,
            local: true
          });
          button.onPointDown.add(function () {
            _this.stateManager.playAudioAtParamVolume(StateManager_1.AudioType.Select);

            button._surface = g.SurfaceUtil.asSurface(backButtonOnAsset);
            button.invalidate();
          });
          button.onPointUp.add(function () {
            button._surface = g.SurfaceUtil.asSurface(backButtonOffAsset);
            button.invalidate();
            var nextRankingType;

            switch (_this.showRankingType) {
              case RankingType.Length:
                nextRankingType = RankingType.Kill;
                break;

              case RankingType.Kill:
                nextRankingType = RankingType.Length;
                break;

              default: // do nothing

            }

            var message = {
              messageType: MessageEventType_1.MessageEventType.nextRankingType,
              messageData: {
                nextRankingType: nextRankingType
              }
            };
            g.game.raiseEvent(new g.MessageEvent(message));
          });
          this.root.append(button);
        };

        ResultScene.prototype._createUnableButton = function () {
          var backButtonAsset = this.assets.result_btn_back_off_unable;
          var nextButtonAsset = this.assets.result_btn_next_off_unable;
          var backButton = new g.Sprite({
            scene: this,
            src: backButtonAsset,
            width: backButtonAsset.width,
            height: backButtonAsset.height,
            x: 1013,
            y: 552,
            local: true
          });
          this.root.append(backButton);
          var nextButton = new g.Sprite({
            scene: this,
            src: nextButtonAsset,
            width: nextButtonAsset.width,
            height: nextButtonAsset.height,
            x: 1138,
            y: 552,
            local: true
          });
          this.root.append(nextButton);
        };

        ResultScene.prototype._sendResultLog = function (lengthRankingPlayerIdList, killRankingPlayerIdList, jewelOwnerId) {
          var _this = this;

          var logData = [];
          lengthRankingPlayerIdList.forEach(function (data, rank) {
            var userId = data.playerId;
            var killRankingIndex = killRankingPlayerIdList.findIndex(function (_a) {
              var playerId = _a.playerId;
              return playerId === userId;
            });
            logData.push({
              rank: rank + 1,
              userId: userId,
              score: data.count,
              params: {
                userId: userId,
                userName: _this.stateManager.playerList[userId].user.name,
                isPremium: _this.stateManager.playerList[userId].user.isPremium,
                lengthCount: data.count,
                lengthRank: rank + 1,
                words: _this.stateManager.playerList[userId].lastWords,
                killCount: killRankingPlayerIdList[killRankingIndex].count,
                killRank: killRankingIndex + 1,
                haveJewel: jewelOwnerId != null && userId === jewelOwnerId
              }
            });
          });

          if (g.game.external && g.game.external.send) {
            g.game.external.send({
              type: "multi:result",
              sessionId: g.game.playId,
              data: logData
            });
          }
        };

        return ResultScene;
      }(SceneBase_1.SceneBase);

      exports.ResultScene = ResultScene;
      var RankingType;

      (function (RankingType) {
        RankingType["Length"] = "Length";
        RankingType["Kill"] = "Kill";
      })(RankingType = exports.RankingType || (exports.RankingType = {}));
    }, {
      "../../StateManager": 19,
      "../../assetIds": 21,
      "../../commonUtils/utils": 23,
      "../../entity/ResultScene/RankingLabel": 32,
      "../../types/MessageEventType": 49,
      "../SceneBase": 46,
      "./ResultBehavior": 44,
      "@akashic-extension/akashic-label": 8,
      "@akashic-extension/akashic-timeline": 15
    }],
    46: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics21 = function extendStatics(d, b) {
          _extendStatics21 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics21(d, b);
        };

        return function (d, b) {
          _extendStatics21(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.SceneBase = void 0;

      var SceneBase =
      /** @class */
      function (_super) {
        __extends(SceneBase, _super);

        function SceneBase() {
          return _super !== null && _super.apply(this, arguments) || this;
        }

        SceneBase.prototype.setBehavior = function (_behavior) {
          this.behavior = _behavior;
        };

        SceneBase.prototype.setMessageEventListener = function () {
          var _this = this;

          this.onMessage.add(function (event) {
            _this.behavior.onMessageEvent(event);
          });
        };

        return SceneBase;
      }(g.Scene);

      exports.SceneBase = SceneBase;
    }, {}],
    47: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics22 = function extendStatics(d, b) {
          _extendStatics22 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics22(d, b);
        };

        return function (d, b) {
          _extendStatics22(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.TitleBehavior = void 0;

      var Behavior_1 = require("../Behavior");

      var MessageEventType_1 = require("../../types/MessageEventType");

      var TitleBehavior =
      /** @class */
      function (_super) {
        __extends(TitleBehavior, _super);

        function TitleBehavior(param) {
          return _super.call(this, param) || this;
        }

        TitleBehavior.prototype.onMessageEvent = function (event) {
          this._onAllInstanceEvent(event);

          if (g.game.isActiveInstance()) this._onActiveInstanceEvent(event);
        };
        /**
         * 全てのインスタンスで拾うイベント
         */


        TitleBehavior.prototype._onAllInstanceEvent = function (event) {
          var data = event.data;
          var messageType = data.messageType;

          switch (messageType) {
            case MessageEventType_1.MessageEventType.waitRecruitment:
              this.scene.createJoinButton();
              this.scene.setRecruitmentTimer(data.messageData.startTime);
              break;

            case MessageEventType_1.MessageEventType.lotteryResult:
              var messageData = data.messageData;
              this.stateManager.setPlayerList(messageData.playerList);
              this.scene.showLotteryResult(messageData.numPlayers);
              break;

            case MessageEventType_1.MessageEventType.startGame:
              this.stateManager.changeMainGameScene();
              break;

            case MessageEventType_1.MessageEventType.restartRecruitment:
              this.scene.resetScene();
              break;

            default: // do nothing

          }
        };
        /**
         * サーバーインスタンスでのみ拾うイベント
         */


        TitleBehavior.prototype._onActiveInstanceEvent = function (event) {
          var _this = this;

          var data = event.data;
          var messageType = data.messageType;

          switch (messageType) {
            case MessageEventType_1.MessageEventType.startRecruitment:
              this.stateManager.startRecruitment(data.messageData.broadcasterUser);

              var checkTimeUp_1 = function checkTimeUp_1() {
                if (g.game.age - _this.stateManager.startTime > _this.stateManager.sessionParameter.entrySec * g.game.fps) {
                  _this.stateManager.startLottery();

                  _this.scene.update.remove(checkTimeUp_1);
                }
              };

              this.scene.onUpdate.add(checkTimeUp_1);
              break;

            case MessageEventType_1.MessageEventType.joinRequest:
              this.stateManager.receiveJoinRequest(data.messageData.joinPlayer, data.messageData.joinUser);
              break;

            default: // do nothing

          }
        };

        return TitleBehavior;
      }(Behavior_1.Behavior);

      exports.TitleBehavior = TitleBehavior;
    }, {
      "../../types/MessageEventType": 49,
      "../Behavior": 41
    }],
    48: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics23 = function extendStatics(d, b) {
          _extendStatics23 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics23(d, b);
        };

        return function (d, b) {
          _extendStatics23(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.TitleScene = exports.createTitleScene = void 0;

      var SceneBase_1 = require("../SceneBase");

      var TitleBehavior_1 = require("./TitleBehavior");

      var joinSequence_1 = require("../../utils/joinSequence");

      var BigButton_1 = require("../../entity/TitleScene/BigButton");

      var RecruitmentCountDown_1 = require("../../entity/TitleScene/RecruitmentCountDown");

      var WaitingText_1 = require("../../entity/TitleScene/WaitingText");

      var HowtoText_1 = require("../../entity/TitleScene/HowtoText");

      function createTitleScene(stateManager) {
        var assetIds = ["frame_howto", "btn_frame_join", "btn_frame_join_disable"];
        var titleScene = new TitleScene({
          game: g.game,
          stateManager: stateManager,
          assetIds: assetIds
        });
        return titleScene;
      }

      exports.createTitleScene = createTitleScene;

      var TitleScene =
      /** @class */
      function (_super) {
        __extends(TitleScene, _super);

        function TitleScene(param) {
          var _this = _super.call(this, param) || this;

          _this.stateManager = param.stateManager;
          _this._isApplied = false;

          _this.onLoad.add(function () {
            _this.createRoot();

            _this.createBackground();

            _this.setBehavior(new TitleBehavior_1.TitleBehavior({
              scene: _this,
              stateManager: _this.stateManager
            }));

            _this.setMessageEventListener();

            _this.createHowtoText();

            _this.createStartButton();

            _this.createPreparationText();

            if (_this.stateManager.sessionParameter.config.debug) _this.createDebugButton();
          });

          return _this;
        }

        TitleScene.prototype.createRoot = function () {
          this.root = new g.E({
            scene: this
          });
          this.append(this.root);
        };

        TitleScene.prototype.createBackground = function () {
          var backgroundRect = new g.FilledRect({
            scene: this,
            width: g.game.width,
            height: g.game.height,
            cssColor: "rgba(0,6,43,0.70)" // 色指定はデザイン指示より

          });
          this.root.append(backgroundRect);
        };

        TitleScene.prototype.resetScene = function () {
          if (this.lotteryResultText) {
            this.lotteryResultText.destroy();
          }

          this.createStartButton();
          this.createPreparationText();
        };

        TitleScene.prototype.createHowtoText = function () {
          var howtoText = new HowtoText_1.HowtoText({
            scene: this,
            y: 48,
            text: this.stateManager.sessionParameter.howtoMessage
          });
          this.root.append(howtoText);
        };

        TitleScene.prototype.createStartButton = function () {
          var _this = this;

          if (!this.stateManager.isBroadcaster) return;
          this.startButton = new BigButton_1.BigButton({
            scene: this,
            text: "参加者受付を開始する",
            textColor: "white",
            font: this.stateManager.resource.font,
            x: g.game.width / 2,
            y: 482,
            anchorX: 0.5,
            anchorY: 0.0,
            touchable: true,
            local: true
          });
          this.startButton.onPointUp.add(function () {
            _this.startButton.destroy();

            joinSequence_1.startRecruitmentSequence();
          });
          this.root.append(this.startButton);
        };

        TitleScene.prototype.createPreparationText = function () {
          if (this.stateManager.isBroadcaster) return;
          this.preparationText = this._createBitTextLabel("放送者が準備中です");
        };

        TitleScene.prototype.createJoinButton = function () {
          var _this = this;

          if (this.stateManager.isBroadcaster) {
            if (this.startButton && !this.startButton.destroyed()) {
              this.startButton.destroy();
            }

            return;
          }

          this.preparationText.destroy();
          this.joinButton = new BigButton_1.BigButton({
            scene: this,
            text: "参加する",
            textColor: "white",
            font: this.stateManager.resource.font,
            x: g.game.width / 2,
            y: 440,
            anchorX: 0.5,
            anchorY: 0.0,
            touchable: true,
            local: true
          });
          this.joinButton.pointUp.addOnce(function (event) {
            _this.joinButton.toDisable("参加受付完了");

            _this._isApplied = true; // リロード時は実行されない

            joinSequence_1.joinRequestSequence(event.player);
          });
          this.root.append(this.joinButton);
        };

        TitleScene.prototype.createWaitingText = function () {
          this.waitingText = new WaitingText_1.WaitingText({
            scene: this,
            font: this.stateManager.resource.font,
            y: 510 // 手調整 (レイアウト指示+30)

          });
          this.root.append(this.waitingText);
        };

        TitleScene.prototype.createDebugButton = function () {
          var _this = this;

          var RANDOM_CHARS = "abcdefghijklmnopqrstuvwxyz0123456789";
          var join10Button = new g.Label({
            scene: this,
            font: this.stateManager.resource.font,
            text: "join10bot",
            fontSize: 30,
            textColor: "black",
            touchable: true,
            x: 10,
            y: 10
          });
          join10Button.onPointDown.add(function () {
            join10Button.opacity = 0.5;
            join10Button.textColor = "red";
            join10Button.invalidate();
          });
          join10Button.onPointUp.add(function () {
            join10Button.opacity = 1;
            join10Button.textColor = "black";
            join10Button.invalidate();
            if (!_this.stateManager.applicantList) return; // 参加者受付を開始していない

            for (var i = 0; i < 10; i++) {
              var name_1 = "";
              var nameLength = Math.floor(Math.random() * 15) + 1;

              for (var i_1 = 0; i_1 < nameLength; i_1++) {
                name_1 += RANDOM_CHARS[Math.floor(Math.random() * RANDOM_CHARS.length)];
              }

              joinSequence_1.joinRequestSequence({
                id: Math.round(Math.random() * 1000).toString(),
                name: name_1
              });
            }
          });
          this.root.append(join10Button);
        };

        TitleScene.prototype.setRecruitmentTimer = function (startTime) {
          var _this = this;

          this.countDown = new RecruitmentCountDown_1.RecruitmentCountDown({
            scene: this,
            font: this.stateManager.resource.font,
            y: 594 // 手調整 (レイアウト指示+80)

          });
          var entrySec = this.stateManager.sessionParameter.entrySec;
          this.countDown.setTime(entrySec);
          this.root.append(this.countDown);

          var checkTimeUp = function checkTimeUp() {
            var fpsTime = g.game.age - startTime;

            _this.countDown.setTime(entrySec - fpsTime / g.game.fps);

            if (fpsTime > entrySec * g.game.fps) {
              _this.tallyUp();

              _this.update.remove(checkTimeUp);
            }
          };

          this.onUpdate.add(checkTimeUp);
        };

        TitleScene.prototype.tallyUp = function () {
          if (!this.stateManager.isBroadcaster) {
            this.joinButton.destroy();
          }

          this.countDown.destroy();
          this.createWaitingText();
        };

        TitleScene.prototype.showLotteryResult = function (numPlayers) {
          this.waitingText.destroy(); // 応募者がいない場合 (1人は放送者)

          if (numPlayers <= 1) {
            this.lotteryResultText = this._createBitTextLabel("参加者が集まりませんでした");
            return;
          } // 放送者の場合


          if (this.stateManager.isBroadcaster) {
            this.lotteryResultText = this._createBitTextLabel("参加者が決定しました");
            return;
          } // 当選者の場合


          if (g.game.selfId in this.stateManager.playerList) {
            this.lotteryResultText = this._createBitTextLabel("当選しました");
            return;
          } // 応募したが落選した場合
          // NOTE: タイトルで参加後リロードすると応募していない扱いになる


          if (this._isApplied) {
            this.lotteryResultText = this._createBitTextLabel("落選しました");
            return;
          } // 応募していない場合


          this.lotteryResultText = this._createBitTextLabel("参加者が決定しました");
        };

        TitleScene.prototype._createBitTextLabel = function (text, top) {
          if (top === void 0) {
            top = 510;
          }

          var label = new g.Label({
            scene: this,
            text: text,
            font: this.stateManager.resource.font,
            fontSize: 73,
            textColor: "white",
            textAlign: "center",
            x: g.game.width / 2,
            y: top,
            anchorX: 0.5,
            anchorY: 0,
            local: true
          });
          this.root.append(label);
          return label;
        };

        return TitleScene;
      }(SceneBase_1.SceneBase);

      exports.TitleScene = TitleScene;
    }, {
      "../../entity/TitleScene/BigButton": 36,
      "../../entity/TitleScene/HowtoText": 37,
      "../../entity/TitleScene/RecruitmentCountDown": 38,
      "../../entity/TitleScene/WaitingText": 39,
      "../../utils/joinSequence": 54,
      "../SceneBase": 46,
      "./TitleBehavior": 47
    }],
    49: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.PreventType = exports.CountDownType = exports.AnimationType = exports.ScopeType = exports.MessageEventType = void 0;
      var MessageEventType;

      (function (MessageEventType) {
        // ----------
        // 募集～抽選画面のイベント
        // ----------

        /**
         * 放送者が参加者募集を開始する。
         * startRecruitmentのタイミングは生主のユーザーアクションによって決定される。
         */
        MessageEventType["startRecruitment"] = "startRecruitment";
        /**
         * 参加者募集状態にする。
         */

        MessageEventType["waitRecruitment"] = "waitRecruitment";
        /**
         * 視聴者がゲーム参加を希望する。
         */

        MessageEventType["joinRequest"] = "joinRequest";
        /**
         * 抽選結果を全インスタンスに共有する。
         */

        MessageEventType["lotteryResult"] = "lotteryResult";
        /**
         * 参加者が集まらなかった時に募集をやりなおす
         */

        MessageEventType["restartRecruitment"] = "restartRecruitment";
        /**
         * ゲーム開始を全インスタンスに通知する。
         */

        MessageEventType["startGame"] = "startGame"; // ----------
        // ゲーム画面のイベント
        // ----------

        /**
         * ゲーム画面の初期化を通知する。
         */

        MessageEventType["initMainGame"] = "initMainGame";
        /**
         * 全スネーク・指定したスネークの無敵状態を解除し、PlayerStateをPlayingにセットすることを通知する。
         */

        MessageEventType["setPlaying"] = "setPlaying";
        /**
         * ユーザによって操作状態が変わったことを通知する。
         */

        MessageEventType["changeUserTouchState"] = "changeUserTouchState";
        /**
         * 衝突したプレイヤーを全インスタンスに通知する。
         */

        MessageEventType["sendPlayersInConflict"] = "sendPlayersInConflict";
        /**
         * リスポーンしたプレイヤーのスネークを全インスタンスに通知する。
         */

        MessageEventType["respawnSnake"] = "respawnSnake";
        /**
         * お宝のリスポーンを全インスタンスに通知する。
         */

        MessageEventType["respawnJewel"] = "respawnJewel";
        /**
         * エサが食べられた情報を全インスタンスに通知する。
         */

        MessageEventType["eatenFoods"] = "eatenFoods";
        /**
         * 放送者のスネークが天使スネークになったことを全インスタンスに通知する。
         */

        MessageEventType["respawnBroadcasterAngelSnake"] = "respawnBroadcasterAngelSnake";
        /**
         * お宝所有者の更新情報を全インスタンスに通知する。
         */

        MessageEventType["updateJewelOwner"] = "updateJewelOwner";
        /**
         * ランキング情報を全インスタンスに通知する。
         */

        MessageEventType["rankingAccountData"] = "rankingAccountData";
        /**
         * 残りの制限時間を全インスタンスに通知する。
         */

        MessageEventType["updateRemainTime"] = "updateRemainTime";
        /**
         * アニメーション開始を通知する。
         */

        MessageEventType["animation"] = "animation";
        /**
         * カウントダウン表示を全インスタンスに通知する。
         */

        MessageEventType["countDown"] = "countDown";
        /**
         * ユーザによる操作状態の変更を全インスタンスに通知する。
         */

        MessageEventType["preventUsertouch"] = "preventUsertouch";
        /**
         * あるスネークをdestroyすることを全インスタンスに通知する。
         */

        MessageEventType["destroySnake"] = "destroySnake";
        /**
         * ゲーム終了手続き開始を全インスタンスに通知する。
         */

        MessageEventType["finishGame"] = "finishGame";
        /**
         * リザルト画面遷移を全インスタンスに通知する。
         */

        MessageEventType["startResult"] = "startResult"; // ----------
        // リザルト画面のイベント
        // ----------

        /**
         * リザルト画面の初期化を全インスタンスに通知する。
         */

        MessageEventType["initResult"] = "initResult";
        /**
         * 次に表示するランキングの種類を全インスタンスに通知する。
         */

        MessageEventType["nextRankingType"] = "nextRankingType";
        /**
         * ランキングスクロール速度変更を全インスタンスに通知する。
         */

        MessageEventType["changeScrollSpeed"] = "changeScrollSpeed";
      })(MessageEventType = exports.MessageEventType || (exports.MessageEventType = {}));

      ;
      /**
       * 対象Scopeの種類
       */

      var ScopeType;

      (function (ScopeType) {
        /**
         * 全員対象
         */
        ScopeType["All"] = "All";
        /**
         * ある特定の一人対象
         */

        ScopeType["One"] = "One";
      })(ScopeType = exports.ScopeType || (exports.ScopeType = {}));
      /**
       * Animationの種類
       */


      var AnimationType;

      (function (AnimationType) {
        /**
         * 透過度変更によりスネークを点滅させる
         */
        AnimationType["Blinking"] = "Blinking";
        /**
         * スネークを見えなくして「放送者画面に切り替わります」を表示
         */

        AnimationType["ToBroadcasterView"] = "ToBroadcasterView";
      })(AnimationType = exports.AnimationType || (exports.AnimationType = {}));
      /**
       * カウントダウン表示の種類
       */


      var CountDownType;

      (function (CountDownType) {
        CountDownType["Start"] = "Start";
        CountDownType["Finish"] = "Finish";
        CountDownType["One"] = "One";
        CountDownType["Two"] = "Two";
        CountDownType["Three"] = "Three";
      })(CountDownType = exports.CountDownType || (exports.CountDownType = {}));

      var PreventType;

      (function (PreventType) {
        PreventType["TouchState"] = "TouchState";
        PreventType["None"] = "None";
      })(PreventType = exports.PreventType || (exports.PreventType = {}));
    }, {}],
    50: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.UserTouchState = void 0;
      var UserTouchState;

      (function (UserTouchState) {
        /**
         * そのインスタンスのユーザが移動操作を開始した状態を表す
         */
        UserTouchState["onPoint"] = "onPoint";
        /**
         * 操作していない状態を表す
         * 主にpointUp後の状態
         */

        UserTouchState["noPoint"] = "noPoint";
        /**
         * ダブルタップしている状態
         * ダッシュ可能時間内
         */

        UserTouchState["onDoubleTap"] = "onDoubleTap";
        /**
         * ダッシュ終了後もタップし続けている状態
         */

        UserTouchState["onHold"] = "onHold";
      })(UserTouchState = exports.UserTouchState || (exports.UserTouchState = {}));
    }, {}],
    51: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.checkStateRole = exports.StateRoleType = void 0;

      var StateManager_1 = require("../StateManager");

      var StateRoleType;

      (function (StateRoleType) {
        /**
         * 衝突判定がある PlayerState群
         */
        StateRoleType["CanCollideType"] = "CanCollideType";
        /**
         * 音を鳴らしてよい PlayerState群
         */

        StateRoleType["CanSoundType"] = "CanSoundType";
        /**
         * フィールド上に生存しているスネークとしてカウントする PlayerState群
         */

        StateRoleType["CanCountType"] = "CanCountType";
        /**
         * 操作ハンドラを呼んで良い PlayerState群
         */

        StateRoleType["CanOperateType"] = "CanOperateType";
        /**
         * 移動可能な PlayerState群
         */

        StateRoleType["CanMoveType"] = "CanMoveType";
        /**
         * 節、お宝を落とすことが可能な PlayerState群
         */

        StateRoleType["CanDropType"] = "CanDropType";
        /**
         * ゲーム観戦者になっている時の PlayerState群
         */

        StateRoleType["IsAudienceType"] = "IsAudienceType";
      })(StateRoleType = exports.StateRoleType || (exports.StateRoleType = {}));
      /**
       * PlayerStateの役割を判定する
       */


      function checkStateRole(playerState, roleType) {
        switch (roleType) {
          case StateRoleType.CanCollideType:
            return playerState !== StateManager_1.PlayerState.ghost && playerState !== StateManager_1.PlayerState.invincible && playerState !== StateManager_1.PlayerState.staging;

          case StateRoleType.CanSoundType:
            return playerState === StateManager_1.PlayerState.playing || playerState === StateManager_1.PlayerState.invincible;

          case StateRoleType.CanCountType:
            return playerState === StateManager_1.PlayerState.playing || playerState === StateManager_1.PlayerState.invincible || playerState === StateManager_1.PlayerState.staging;

          case StateRoleType.CanOperateType:
            return playerState !== StateManager_1.PlayerState.staging && playerState !== StateManager_1.PlayerState.dead;

          case StateRoleType.CanMoveType:
            return playerState !== StateManager_1.PlayerState.staging && playerState !== StateManager_1.PlayerState.dead;

          case StateRoleType.CanDropType:
            return playerState === StateManager_1.PlayerState.playing;

          case StateRoleType.IsAudienceType:
            return playerState === StateManager_1.PlayerState.dead || playerState === StateManager_1.PlayerState.staging;

          default:
            // never
            return false;
        }
      }

      exports.checkStateRole = checkStateRole;
    }, {
      "../StateManager": 19
    }],
    52: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.changeAudioMasterVolume = void 0;
      /**
       * 対象のオーディオをパラメータで指定したボリュームに設定する
       * @param audioPlayer : 対象の g.AudioPlayer
       * @param config : セッションパラメータのコンフィグ
       */

      function changeAudioMasterVolume(audioPlayer, config) {
        if (audioPlayer == null) return;

        if (!!config.debug && config.debug.audioVolume) {
          audioPlayer.changeVolume(config.debug.audioVolume);
        } else {
          audioPlayer.changeVolume(config.audio.audioVolume);
        }
      }

      exports.changeAudioMasterVolume = changeAudioMasterVolume;
    }, {}],
    53: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.localToGlobal = void 0;

      function localToGlobal(offset) {
        var point = offset;

        for (var entity = this; entity instanceof g.E; entity = entity.parent) {
          point = entity.getMatrix().multiplyPoint(point);
        }

        return point;
      }

      exports.localToGlobal = localToGlobal;
    }, {}],
    54: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.joinRequestSequence = exports.startRecruitmentSequence = void 0;

      var resolve_player_info_1 = require("@akashic-extension/resolve-player-info");

      var MessageEventType_1 = require("../types/MessageEventType");
      /**
       * 放送者が参加募集を開始するシーケンス
       */


      function startRecruitmentSequence() {
        resolve_player_info_1.resolvePlayerInfo({
          raises: false
        }, function (error, playerInfo) {
          var _a;

          var joinUser;

          if (error || !((_a = playerInfo === null || playerInfo === void 0 ? void 0 : playerInfo.userData) === null || _a === void 0 ? void 0 : _a.accepted)) {
            joinUser = {
              name: "放送者",
              id: "000000000",
              isPremium: false
            };
          } else {
            joinUser = {
              name: playerInfo.name,
              id: "000000000",
              isPremium: !!playerInfo.userData.premium
            };
          }

          var message = {
            messageType: MessageEventType_1.MessageEventType.startRecruitment,
            messageData: {
              broadcasterUser: joinUser
            }
          };
          g.game.raiseEvent(new g.MessageEvent(message));
        });
      }

      exports.startRecruitmentSequence = startRecruitmentSequence;
      /**
       * プレイヤーがゲームに参加リクエストを送るシーケンス
       */

      function joinRequestSequence(player) {
        resolve_player_info_1.resolvePlayerInfo({
          raises: false
        }, function (error, playerInfo) {
          var _a;

          var joinUser;

          if (error || !((_a = playerInfo === null || playerInfo === void 0 ? void 0 : playerInfo.userData) === null || _a === void 0 ? void 0 : _a.accepted)) {
            joinUser = {
              name: !!player.name ? player.name : "ゲスト",
              id: player.id,
              isPremium: false
            };
          } else {
            joinUser = {
              name: playerInfo.name,
              id: player.id,
              isPremium: !!playerInfo.userData.premium
            };
          }

          var message = {
            messageType: MessageEventType_1.MessageEventType.joinRequest,
            messageData: {
              joinPlayer: player,
              joinUser: joinUser
            }
          };
          g.game.raiseEvent(new g.MessageEvent(message));
        });
      }

      exports.joinRequestSequence = joinRequestSequence;
    }, {
      "../types/MessageEventType": 49,
      "@akashic-extension/resolve-player-info": 17
    }]
  }, {}, [20])(20);
});